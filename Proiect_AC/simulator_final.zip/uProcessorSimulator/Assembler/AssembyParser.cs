﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assembler
{
    #region State Enums
    enum SegState
    {
        Stack = 0,
        Data = 1,
        Code = 2,
        err
    }

    enum DataState
    {
        ParseDataType_State = 0,
        ParseDataName_State = 1,
        WriteData_State = 2,
        err
    }

    enum CodeState
    {
        DecodeInstr_Sate = 0,
        TwoOpInstr_State = 1,
        OneOpInstr_State = 2,
        BranchInstr_State = 3,
        CpuInstr_State = 4,
        Label_State = 5,
        err
    }

    enum OperandState
    {
        DstOp_State = 0,
        SrcOP_State = 1,
        err
    }

    enum DataType
    {
        ByteType = 0,
        WordType = 1,
        err
    }

    #endregion

    /// <summary>
    /// Parses assembly code for uProcessorSimulator from an assembly file(.asm)
    /// </summary>
    public class AssembyParser
    {
        #region States
        SegState segState;
        DataState dataState;
        CodeState codeState;
        DataType dataType;
        OperandState operandState;
        #endregion

        #region fields and data types
        private SegmentMemory dataSegment; // here goes the the machinecode for data segment
        private SegmentMemory codeSegment; //here goes the the machinecode for code segment
        private int stackSize;

        /// <summary>
        /// saves symbols names and their offset in the data seg
        /// </summary>
        Dictionary<string, int> symbolsFound;
        /// <summary>
        /// saves labes names and their offset in the code seg
        /// </summary>
        Dictionary<string, int> labelsFound;
        /// <summary>
        /// saves address of the label's usage occurrecnes 
        /// </summary>
        List<Label> labels;
        /// <summary>
        /// saves address of the symbol's usage occurences
        /// </summary>
        List<Symbol> symbols;

        private List<string> codeLines;
        private int current_line;
        private string filePath;
        private string outBinFilePath;

        #endregion

        string[] alpha = { "A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","S","T","U","V","W","X","Y","Z"};

       public AssembyParser(string filePath)
        {
            // TODO: Complete member initialization
            this.filePath = filePath;
            string fileName = Path.GetFileNameWithoutExtension(filePath);
            string fileDirectory = Path.GetDirectoryName(filePath);
            if (fileDirectory.Any())
            {
                this.outBinFilePath = fileDirectory + '\\' + fileName + ".bin";
            }
            else
            {
                this.outBinFilePath = fileName + ".bin";
            }
            
            this.codeLines = new List<string>();
            this.labels = new List<Label>();
            this.symbols = new List<Symbol>();
            this.symbolsFound = new Dictionary<string, int>();
            this.labelsFound = new Dictionary<string, int>();
            this.dataSegment = new SegmentMemory();
            this.codeSegment = new SegmentMemory();
        }

       public void Parse()
        {
            initParser();
            //algorithm for parsing
            foreach(string line in this.codeLines)
            {
                if (line.Contains("."))
                {
                    if (line.Contains("STACK"))
                    {
                        this.segState = SegState.Stack;
                    }
                    else if (line.Contains("DATA"))
                    {
                        this.segState = SegState.Data;
                        continue;
                    }
                    else if (line.Contains("CODE"))
                    {
                        this.segState = SegState.Code;
                        continue;
                    }
                    else
                    {
                        this.segState = SegState.err;
                    }
                }
                //fills the segmentMemory members
                this.StateMachine(line);
            }            
            //assigning remaining labels
            foreach(Label label in this.labels)
            {
                if (this.labelsFound.ContainsKey(label.LabelName))
                {
                    int labelTagrget;
                    this.labelsFound.TryGetValue(label.LabelName,out labelTagrget);
                    ushort offset = label.computeAdress((ushort)labelTagrget);
                    //this.codeSegment.InsertByteToAddress(label.offset, (byte)offset);
                    if (this.codeSegment[label.offset] != 0)
                    {
                        this.codeSegment.InsertByteToAddress(label.offset, (byte)(offset-2));
                    }
                    else
                    {
                        this.codeSegment[label.offset] = (ushort)(labelTagrget + dataSegment.SegmentSize);
                    }
                }
                else
                {
                    //problem!!!!
                }
            }
            //assigning symbols
            //a class uses the segments to create the output file in the same directory as the input one
            //also generates an .upsim file containing explicit code and data (text)
            MachineCodeFileGenerator mcfg = new MachineCodeFileGenerator(dataSegment, codeSegment, stackSize, codeLines);
            mcfg.generate_output(this.outBinFilePath);
        }

       private void initParser()
        {
            //read file
            StreamReader reader = new StreamReader(this.filePath);
            string line;
            string[] aux;
            while((line = reader.ReadLine() )!= null)
            {
                line = line.Trim(' ','\t');
                if (line.Any()) // ignore empty lines
                {
                    if (line[0] != ';') // ignore comment whole lines
                    {
                        if (line.Contains(";"))
                        {
                            line = line.Substring(0, line.IndexOf(';')); //remove comments after instr
                            line = line.Trim(' ', '\t');
                        }
                        if (line.Contains(':'))
                        {
                            aux = line.Split(new Char[] {':'}, StringSplitOptions.RemoveEmptyEntries); //split after ':' [0] is label and [1] is instr
                            if (aux.Length > 1) //in case there wad only the label on the line
                            {
                                codeLines.Add(aux[0] + ':'); //replace ':' to detect it in parsing progres as label
                                line = aux[1].Trim();
                            }
                        }
                        codeLines.Add(line.ToUpper());
                    } 
                }
            }
            //init states
            this.segState = SegState.Stack;
            this.codeState = CodeState.DecodeInstr_Sate;
            this.dataState = DataState.ParseDataType_State;
        }

       public void StateMachine(string line)
        {
            
            switch (this.segState)
            {
                case SegState.Stack:
                    {
                        string[] comp = line.Split(new Char[] {' '},StringSplitOptions.RemoveEmptyEntries);
                        if(comp.Length > 1)
                        {
                            try
                            {
                                this.stackSize = Convert.ToInt32(comp[1]);
                            }
                            catch (Exception)
                            {

                                this.stackSize = Convert.ToInt32(comp[1], 16);
                            }
                        }
                        else
                        {
                            this.stackSize = 0x64; //100 bytes stack size by default
                        }
                        break;
                    }
                case SegState.Data:
                    {
                        //determinate the substate of data procesing
                        if (line.Contains("DB ") || line.Contains("DW "))
                        {
                            this.dataState = DataState.ParseDataType_State;
                        }
                        else if(line.Contains(", 0x") || line.Contains(", "))
                        {
                            this.dataState = DataState.WriteData_State;
                        }
                        else
                        {
                            this.dataState = DataState.err;
                        }
                        this.DataParseStateMachine(line);
                        break;
                    }
                case SegState.Code:
                    {
                        if (line.Contains(':'))
                        {
                            this.codeState = CodeState.Label_State;
                        }else if (Char.IsLetter(line[0]))
                        {
                            this.codeState = CodeState.DecodeInstr_Sate;
                        }else
                        {
                            this.codeState = CodeState.err;
                        }
                        this.CodeParseStateMachine(line);
                        break;
                    }
                default:break; //error
            }   
        }

       private void DataParseStateMachine(string line, ushort d = 0)
        {
            //split line and stays here until processes all components
            string[] components = line.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string comp in components)
            {
                switch (this.dataState)
                {
                    case DataState.ParseDataType_State:
                        {
                            if (comp.Equals("DB"))
                            {
                                this.dataType = DataType.ByteType;
                                this.dataState = DataState.ParseDataName_State;
                            }else if (comp.Equals("DW"))
                            {
                                this.dataType = DataType.WordType;
                                this.dataState = DataState.ParseDataName_State;
                            }
                            else
                            {
                                this.dataType = DataType.err;
                            }
                            
                                break;
                        }
                    case DataState.ParseDataName_State:
                        {
                            //save name of var and the it's address
                            this.symbolsFound.Add(comp, this.dataSegment.CrntOffset);
                            this.dataState = DataState.WriteData_State;
                            break;
                        }
                    case DataState.WriteData_State:
                        {
                            switch (this.dataType)
                            {
                                case DataType.ByteType:
                                    {
                                        byte data;
                                        if (comp.Contains("0X"))
                                        {
                                            data = Convert.ToByte(comp, 16);
                                        }
                                        else
                                        {
                                            data = Convert.ToByte(comp, 10);
                                        }
                                        this.dataSegment.Add(data);
                                        break;
                                    }
                                case DataType.WordType:
                                    {
                                        ushort data;
                                        if (comp.Contains("0X"))
                                        {
                                            data = Convert.ToUInt16(comp, 16);
                                        }
                                        else
                                        {
                                            data = Convert.ToUInt16(comp, 10);
                                        }
                                        this.dataSegment.Add(data);
                                        break;
                                    }
                                default:
                                    break;
                            }
                            break;
                        }
                    default:
                        throw new Exception("error parsing data code on this line :" + line);
                        break;
                } 
            }
        }

       private void CodeParseStateMachine(string line)
        {
            string[] components = line.Split(new char[] { ' ', ',', ':' }, StringSplitOptions.RemoveEmptyEntries);
            Instruction i = null;
            UInt16? Destindex = null;
            UInt16? Srcindex = null;
            foreach (string comp in components)
            {
                switch (this.codeState)
                {
                    case CodeState.DecodeInstr_Sate:
                        {
                            if (InstructionCodes.TwoOpInstr.ContainsKey(comp))
                            {
                                this.codeState = CodeState.TwoOpInstr_State;
                                i = new TwoOpInstruction();
                                byte opcode;
                                InstructionCodes.TwoOpInstr.TryGetValue(comp, out opcode);
                                i.opcode = opcode;
                                this.operandState = OperandState.DstOp_State;
                            }else if (InstructionCodes.OneOpInstr.ContainsKey(comp))
                            {
                                this.codeState = CodeState.OneOpInstr_State;
                                i = new OneOpInstrution();
                                byte opcode;
                                InstructionCodes.OneOpInstr.TryGetValue(comp, out opcode);
                                i.opcode = opcode;
                                this.operandState = OperandState.DstOp_State;
                            }
                            else if (InstructionCodes.BranchInstr.ContainsKey(comp))
                            {
                                this.codeState = CodeState.BranchInstr_State;
                                i = new BranchInstruction();
                                byte opcode;
                                InstructionCodes.BranchInstr.TryGetValue(comp, out opcode);
                                i.opcode = opcode;
                                //this.operandState = OperandState.DstOp_State;
                            }
                            else if (InstructionCodes.CpuInstr.ContainsKey(comp))
                            {
                                this.codeState = CodeState.CpuInstr_State;
                                i = new CpuInstruction();
                                byte opcode;
                                InstructionCodes.CpuInstr.TryGetValue(comp, out opcode);
                                i.opcode = opcode;
                                //this.operandState = OperandState.DstOp_State;
                            }
                            else
                            {
                                this.codeState = CodeState.err;
                            }
                            break;
                        }
                    case CodeState.TwoOpInstr_State:
                        {
                            switch (this.operandState) 
                            {
                                case OperandState.DstOp_State:
                                    {
                                        if (Char.IsDigit(comp[0]) && comp.Contains("("))
                                        {
                                            //TODO: LOGIC FOR MX
                                            Destindex = Convert.ToUInt16(comp.Substring(0, comp.IndexOf("(")));
                                            string temp = comp.Substring(comp.IndexOf("R") + 1, comp.Length - comp.IndexOf(")"));
                                            byte reg = Convert.ToByte(temp);
                                            if (reg >= 16)
                                            {
                                                operandState = OperandState.err;
                                                break;
                                            }
                                            ((TwoOpInstruction)i).Dst = reg;
                                            ((TwoOpInstruction)i).MAdst = (byte)AddressingMode.MX;
                                        }
                                        else if (comp.Contains("(") && comp.Contains(")"))
                                        {
                                            //TODO: LOGIC FOR MI
                                            string temp = comp.Substring(comp.IndexOf("R") + 1, comp.Length - comp.IndexOf(")"));
                                            byte reg = Convert.ToByte(temp);
                                            if (reg >= 16)
                                            {
                                                operandState = OperandState.err;
                                                break;
                                            }
                                            ((TwoOpInstruction)i).Dst = reg;
                                            ((TwoOpInstruction)i).MAdst = (byte)AddressingMode.MI;
                                        }
                                        else if (comp.Contains("R") )
                                        {
                                            //TODO: LOGIC FOR MD
                                            string temp = comp.Substring(comp.IndexOf("R") + 1);
                                            byte reg = Convert.ToByte(temp);
                                            if (reg >= 16)
                                            {
                                                operandState = OperandState.err;
                                                break;
                                            }
                                            ((TwoOpInstruction)i).Dst = reg;
                                            ((TwoOpInstruction)i).MAdst = (byte)AddressingMode.MD;
                                        }
                                        else
                                        {
                                            this.operandState = OperandState.err;
                                        }
                                        this.operandState = OperandState.SrcOP_State;
                                        break;
                                    }
                                case OperandState.SrcOP_State:
                                    {
                                        if (Char.IsDigit(comp[0]) && comp.Contains("("))
                                        {
                                            //TODO: LOGIC FOR MX
                                            Srcindex = Convert.ToUInt16(comp.Substring(0, comp.IndexOf("(")));
                                            string temp = comp.Substring(comp.IndexOf("R") + 1, comp.Length - comp.IndexOf(")"));
                                            byte reg = Convert.ToByte(temp);
                                            if (reg >= 16)
                                            {
                                                operandState = OperandState.err;
                                                break;
                                            }
                                            ((TwoOpInstruction)i).Src = reg;
                                            ((TwoOpInstruction)i).MAsrc = (byte)AddressingMode.MX;
                                        }
                                        else if (comp.Contains("(") && comp.Contains(")"))
                                        {
                                            //TODO: LOGIC FOR MI
                                            string temp = comp.Substring(comp.IndexOf("R") + 1, comp.Length - comp.IndexOf(")"));
                                            byte reg = Convert.ToByte(temp);
                                            if (reg >= 16)
                                            {
                                                operandState = OperandState.err;
                                                break;
                                            }
                                            ((TwoOpInstruction)i).Src = reg;
                                            ((TwoOpInstruction)i).MAsrc = (byte)AddressingMode.MI;
                                        }
                                        else if (comp.Contains("R") && !isWord(comp))
                                        {
                                            //TODO: LOGIC FOR MD
                                            string temp = comp.Substring(comp.IndexOf("R") + 1);
                                            byte reg = Convert.ToByte(temp);
                                            if (reg >= 16)
                                            {
                                                operandState = OperandState.err;
                                                break;
                                            }
                                            ((TwoOpInstruction)i).Src = reg;
                                            ((TwoOpInstruction)i).MAsrc = (byte)AddressingMode.MD;
                                        }
                                        else if(comp.Contains("0X"))
                                        {
                                            ((TwoOpInstruction)i).Src = 0;
                                            Srcindex = Convert.ToByte(comp, 16);
                                            ((TwoOpInstruction)i).MAsrc = (byte)AddressingMode.MA;
                                        }
                                        else if(Char.IsNumber(comp, 0))
                                        {
                                            ((TwoOpInstruction)i).Src = 0;
                                            Srcindex = Convert.ToByte(comp);
                                            ((TwoOpInstruction)i).MAsrc = (byte)AddressingMode.MA;
                                        }
                                        else if (isSymbol(comp))
                                        {
                                            int dataOffset;
                                            this.symbolsFound.TryGetValue(comp, out dataOffset);
                                            ((TwoOpInstruction)i).Src = 0;
                                            Srcindex = (byte)(dataOffset);
                                            ((TwoOpInstruction)i).MAsrc = (byte)AddressingMode.MA;
                                        }else
                                        {
                                            this.operandState = OperandState.err;
                                            throw new Exception("Operand invalid");
                                        }
                                        break;
                                    }
                                default:
                                    {
                                        throw new Exception("Operand invalid : " + line);
                                    }
                            }

                            break;
                        }
                    case CodeState.OneOpInstr_State:
                        {
                            if (Char.IsDigit(comp[0]) && comp.Contains("("))
                            {
                                //TODO: LOGIC FOR MX
                                Destindex = Convert.ToUInt16(comp.Substring(0, comp.IndexOf("(")));
                                string temp = comp.Substring(comp.IndexOf("R") + 1, comp.Length - comp.IndexOf(")"));
                                byte reg = Convert.ToByte(temp);
                                if (reg >= 16)
                                {
                                    operandState = OperandState.err;
                                    break;
                                }
                                ((OneOpInstrution)i).Dst = reg;
                                ((OneOpInstrution)i).MAdst = (byte)AddressingMode.MX;
                            }
                            else if (comp.Contains("(") && comp.Contains(")"))
                            {
                                //TODO: LOGIC FOR MI
                                //TODO: LOGIC FOR MI
                                string temp = comp.Substring(comp.IndexOf("R") + 1, comp.Length - comp.IndexOf(")"));
                                byte reg = Convert.ToByte(temp);
                                if (reg >= 16)
                                {
                                    operandState = OperandState.err;
                                    break;
                                }
                                ((OneOpInstrution)i).Dst = reg;
                                ((OneOpInstrution)i).MAdst = (byte)AddressingMode.MI;
                            }
                            else if (comp.Contains("R") && !isWord(comp))
                            {
                                //TODO: LOGIC FOR MD
                                string temp = comp.Substring(comp.IndexOf("R") + 1);
                                byte reg = Convert.ToByte(temp);
                                if (reg >= 16)
                                {
                                    operandState = OperandState.err;
                                    break;
                                }
                                ((OneOpInstrution)i).Dst = reg;
                                ((OneOpInstrution)i).MAdst = (byte)AddressingMode.MD;
                            }
                            else if (isCallOrJump2Label(i))
                            {
                                this.labels.Add(new Label(comp, this.codeSegment.CrntOffset + 2)); //seve the next address 
                                Destindex = 0; //reserve location for label
                            }
                            else
                            {
                                this.operandState = OperandState.err;
                                throw new Exception("Operand invalid");
                            }
                            break;
                        }
                    case CodeState.BranchInstr_State:
                        {
                            this.labels.Add(new Label(comp, this.codeSegment.CrntOffset));
                            //this.codeSegment.Add(((BranchInstruction)i).toByteArray());
                            break;
                        }
                    case CodeState.CpuInstr_State:
                        {
                            //nothing to do
                            codeSegment.Add(i.toByteArray());
                            break;
                        }
                    case CodeState.Label_State: //
                        {
                            this.labelsFound.Add(comp, this.codeSegment.CrntOffset);
                            break;
                        }
                    default:
                        {
                            throw new Exception("illegal code");
                            break;
                        }
                } 
            }
            //commit to code memory segment
            if (i != null)
            {
                this.codeSegment.Add(i.toByteArray());
            }
            
            if(Srcindex.HasValue)
            {
                codeSegment.Add(Srcindex.Value);
            }
            if(Destindex.HasValue)
            {
                codeSegment.Add(Destindex.Value);
            }
        }

        private bool isWord(string comp)
        {
            for(int i = 0; i < alpha.Length; i++)
            {
                if (comp.Contains(alpha[i]))
                {
                    return true;
                }
            }
            return false;
        }

        private bool isCallOrJump2Label(Instruction i)
        {
            byte jumpOpcode;
            byte callOpCode;
            InstructionCodes.OneOpInstr.TryGetValue("JMP", out jumpOpcode);
            InstructionCodes.OneOpInstr.TryGetValue("CALL", out callOpCode);
            if(i.opcode == jumpOpcode || i.opcode == callOpCode)
            {
                return true;
            }
            return false;
        }

        private bool isSymbol(string operand)
        {
            return this.symbolsFound.ContainsKey(operand);
        }
    }
}
