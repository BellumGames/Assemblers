﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.Controller
{
    using Assembler;
    using System.Threading;
    using uProcessorSimulator.CpuModel;
    class CpuController
    {
        CpuModel cpuModel;
        UPSimView simView;
        ProgramMemoryController prgCtrl;
        MicroMemoryController uMemCtrl;
        ushort kernelAddress;
        Thread ExecThread;
        Thread StepThread;

        private ushort uaddress = 0;
        private uInstruction ui;
        private Instruction i;
        public CpuController( UPSimView simView, ProgramMemoryController prgCtrl, MicroMemoryController uMemCtrl)
        {
            this.simView = simView;
            this.cpuModel = new CpuModel();
            this.prgCtrl = prgCtrl;
            this.uMemCtrl = uMemCtrl;
            this.ExecThread = new Thread(Execute);
            this.StepThread = new Thread(PerformStep);
            i = new Instruction();
        }


        public CpuController(CpuModel cpuModel, UPSimView simView)
        {
            this.cpuModel = cpuModel;
            this.simView = simView;
            
        }

        internal void initCpu()
        {
            this.cpuModel.Pc = Memory.Pc;
            this.cpuModel.Sp = Memory.Sp;
            this.kernelAddress = Memory.KernelAddress;
            this.uaddress = 0;

            this.simView.setPC(cpuModel.Pc);
            this.simView.setSP(cpuModel.Sp);
        }

        internal void initCpu(ushort pc, ushort sp, ushort kernelAddress)
        {
            this.cpuModel.Pc = pc;
            this.cpuModel.Sp = sp;
            this.kernelAddress = kernelAddress;
        }

        internal bool checkForuCode()
        {
            try
            {
                if (MicroMemory.Length != 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }
        internal bool checkForProgram()
        {
            try
            {
                if (Memory.MemoryLengthBytes != 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        internal void Reset()
        {
            if (this.ExecThread.IsAlive)
            {
                this.ExecThread.Abort();
            }
            if (this.StepThread.IsAlive)
            {
                this.StepThread.Abort();
            }
            this.cpuModel = new CpuModel();
            this.initCpu();
            
        }

        internal void Step()
        {
            //this.initCpu();
            this.StepThread = new Thread(PerformStep);
            this.StepThread.Start();
        }
        internal void Run()
        {
            //this.initCpu();
            this.ExecThread = new Thread(Execute);
            this.ExecThread.Start();
        }
        private void PerformStep()
        {
            this.simView.deactivate_all();//.Invoke(simView.deactivate_all);//?
            this.ui = this.uMemCtrl.readMicroInstruction(this.uaddress);
            doSbus();
            Thread.Sleep(50 * Global.ExecutionSpeed);
            doDbus();
            Thread.Sleep(50 * Global.ExecutionSpeed);
            doAlu();
            Thread.Sleep(50 * Global.ExecutionSpeed);
            doRbus();
            Thread.Sleep(50 * Global.ExecutionSpeed);
            doOther();
            Thread.Sleep(50 * Global.ExecutionSpeed);
            doMem();
            Thread.Sleep(50 * Global.ExecutionSpeed);
            doIfJump();
        }
        private void Execute()
        {
            do
            {
                ui = MicroMemory.ReadUuInstr(uaddress);
                PerformStep();
                Thread.Sleep(100 * Global.ExecutionSpeed);
            } while (!isHalt());
        }

        #region State Machines

        private void doSbus()
        {
            switch (ui.Sbus)
            {
                case SbusSrc.none: {
                        //compute
                        ;
                        //notify
                    } break;
                case SbusSrc.Regs: {
                        //compute
                        i = new TwoOpInstruction();
                        i.InstructionCode = cpuModel.Ir;
                        cpuModel.issRegs_Sbus(((TwoOpInstruction)i).Src);
                        //notify
                        simView.activate_Reg(((TwoOpInstruction)i).Src);
                        simView.issReg_s();
                        simView.setSbus(cpuModel.Sbus);
                    }
                    break;
                case SbusSrc.SP: {
                        //compute
                        cpuModel.issSP_Sbus();
                        //notify
                        simView.activate_SP();
                        simView.issSP_s();
                        simView.setSbus(cpuModel.Sbus);
                    }
                    break;
                case SbusSrc.Temp: {
                        //compute
                        cpuModel.issT_Sbus();
                        //notify
                        simView.activate_T();
                        simView.issT_s();
                        simView.setSbus(cpuModel.Sbus);
                    }
                    break;
                case SbusSrc.nTemp: {
                        //compute
                        cpuModel.issNonT_Sbus();
                        //notify
                        simView.activate_T();
                        simView.issT_s();
                        simView.setSbus(cpuModel.Sbus);
                    }
                    break;
                case SbusSrc.PC: {
                        //compute
                        cpuModel.issPC_Sbus();
                        //notify
                        simView.activate_PC();
                        simView.issPC_s();
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.IVR: {
                        //compute
                        cpuModel.issIVR_Sbus();
                        //notify
                        simView.activate_IVR();
                        simView.issIVR_s();
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.ADR: {
                        //compute
                        cpuModel.issADR_Sbus();
                        //notify
                        simView.activate_ADR();
                        simView.issADR_s();
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.MDR: {
                        //compute
                        cpuModel.issMDR_Sbus();
                        //notify
                        simView.activate_MDR();
                        simView.issMDR_s();
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.IR: {
                        //compute
                        cpuModel.issIR_Sbus();
                        //notify
                        simView.activate_IR();
                        simView.issIR_s();
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.Flag: {
                        //compute
                        cpuModel.issFlag_Sbus();
                        //notify
                        simView.activate_Flag();
                        simView.issFlag_s();
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.ZERO: {
                        //compute
                        cpuModel.issZERO_Sbus();
                        //notify
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.ONE: {
                        //compute
                        cpuModel.issONE_Sbus();
                        //notify
                        simView.setSbus(cpuModel.Sbus);
                    } break;
                case SbusSrc.mnsONE: {
                        //compute
                        cpuModel.issmnsOne_Sbus();
                        //notify
                        simView.setSbus(cpuModel.Sbus);
                    } break;
            }
        }

        private void doDbus()
        {
            switch (ui.Dbus)
            {
                case DbusSrc.none: {; }break;
                case DbusSrc.Regs: {
                        //compute
                        i = new OneOpInstrution();
                        i.InstructionCode = cpuModel.Ir;
                        cpuModel.issRegs_Dbus(((OneOpInstrution)i).Dst);
                        //notify
                        simView.activate_Reg(((OneOpInstrution)i).Dst);
                        simView.issReg_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.SP: {
                        //compute
                        cpuModel.issSP_Dbus();
                        //notify
                        simView.activate_SP();
                        simView.issSP_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.Temp: {
                        //compute
                        cpuModel.issT_Dbus();
                        //notify
                        simView.activate_T();
                        simView.issT_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.nTemp: {
                        //compute
                        cpuModel.issNonT_Dbus();
                        //notify
                        simView.activate_T();
                        simView.issT_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.PC: {
                        //compute
                        cpuModel.issPC_Dbus();
                        //notify
                        simView.activate_PC();
                        simView.issPC_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.IVR: {
                        //compute
                        cpuModel.issIVR_Dbus();
                        //notify
                        simView.activate_IVR();
                        simView.issIVR_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.ADR: {
                        //compute
                        cpuModel.issADR_Dbus();
                        //notify
                        simView.activate_ADR();
                        simView.issADR_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.MDR: {
                        //compute
                        cpuModel.issMDR_Dbus();
                        //notify
                        simView.activate_MDR();
                        simView.issMDR_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.IR_off: {
                        //compute
                        cpuModel.issIRoff_Dbus();
                        //notify
                        simView.activate_IR();
                        simView.issIR_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.Flag: {
                        //compute
                        cpuModel.issFlag_Dbus();
                        //notify
                        simView.activate_Flag();
                        simView.issFlag_d();
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.ZERO: {
                        //compute
                        cpuModel.issZERO_Dbus();
                        //notify
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.ONE: {
                        //compute
                        cpuModel.issONE_Dbus();
                        //notify
                        simView.setDbus(cpuModel.Dbus);
                    } break;
                case DbusSrc.mnsONE: {
                        //compute
                        cpuModel.issmnsONE_Dbus();
                        //notify
                        simView.setDbus(cpuModel.Dbus);
                    } break;
            }
        }

        private void doAlu()
        {
            switch (ui.Aluop)
            {
                case AluOP.none: {
                        //compute
                        ;//nothing to compute
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                    } break;
                case AluOP.SUM: {
                        //compute
                        cpuModel.SUM();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_s();
                        simView.AluIn_d();
                    } break;
                case AluOP.SUB: {
                        //compute
                        cpuModel.SUB();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_s();
                        simView.AluIn_d();
                    } break;
                case AluOP.SBUS: {
                        //compute
                        cpuModel.SBUS();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_s();
                    } break;
                case AluOP.DBUS: {
                        //compute
                        cpuModel.DBUS();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.nDBUS: {
                        //compute
                        cpuModel.nDbus();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.AND: {
                        //compute
                        cpuModel.AND();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_s();
                        simView.AluIn_d();
                    } break;
                case AluOP.OR: {
                        //compute
                        cpuModel.OR();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_s();
                        simView.AluIn_d();
                    } break;
                case AluOP.XOR: {
                        //compute
                        cpuModel.XOR();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_s();
                        simView.AluIn_d();
                    } break;
                case AluOP.ASL: {
                        //compute
                        cpuModel.ASL();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.ASR: {
                        //compute
                        cpuModel.ASR();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.LSR: {
                        //compute
                        cpuModel.LSR();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.ROL: {
                        //compute
                        cpuModel.ROL();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.ROR: {
                        //compute
                        cpuModel.ROR();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                    } break;
                case AluOP.RLC: {
                        //compute
                        cpuModel.RLC();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
                case AluOP.RRC: {
                        //compute
                        cpuModel.RRC();
                        //notify
                        simView.setAluOp(ui.Aluop.ToString());
                        simView.setRbus(cpuModel.Rbus);
                        simView.AluIn_d();
                    } break;
            }
        }

        private void doRbus()
        {
            switch (ui.Rbus)
            {
                case RbusDst.none: {
                        //compute
                        ;
                        //notify
                        ;
                    } break;
                case RbusDst.Regs: {
                        //compute
                        i = new OneOpInstrution();
                        i.InstructionCode = cpuModel.Ir; 
                        cpuModel.ldRegs(((OneOpInstrution)i).Dst);
                        //notify
                        simView.ldReg();
                        simView.setReg[((OneOpInstrution)i).Dst](cpuModel.Regs[((OneOpInstrution)i).Dst]);
                        simView.activate_Reg(((OneOpInstrution)i).Dst);
                    } break;
                case RbusDst.SP: {
                        //compute
                        cpuModel.ldSP();
                        //notify
                        simView.ldSP();
                        simView.setSP(cpuModel.Sp);
                        simView.activate_SP();
                    } break;
                case RbusDst.Temp: {
                        //compute
                        cpuModel.ldTemp();
                        //notify
                        simView.ldT();
                        simView.setT(cpuModel.T);
                        simView.activate_T();
                    } break;
                case RbusDst.PC: {
                        //compute
                        cpuModel.ldPC();
                        //notify
                        simView.ldPC();
                        simView.setPC(cpuModel.Pc);
                        simView.activate_PC();
                    } break;
                case RbusDst.IVR: {
                        //compute
                        cpuModel.ldIVR();
                        //notify
                        simView.ldIVR();
                        simView.setIVR(cpuModel.Ivr);
                        simView.activate_IVR();
                    } break;
                case RbusDst.ADR: {
                        //compute
                        cpuModel.ldADR();
                        //notify
                        simView.ldADR();
                        simView.setADR(cpuModel.Adr);
                        simView.activate_ADR();
                    } break;
                case RbusDst.MDR: {
                        //compute
                        cpuModel.ldMDR();
                        //notify
                        simView.ldMDR();
                        simView.setMDR(cpuModel.Mdr);
                        simView.activate_MDR();
                    } break;
                case RbusDst.IR: {
                        //compute
                        cpuModel.ldIR();
                        //notify
                        simView.ldIR();
                        simView.activate_IR();
                        simView.setIR(cpuModel.Ir);
                    } break;
                case RbusDst.Flag: {
                        //compute
                        cpuModel.ldFlag();
                        //notify
                        simView.ldFlag();
                        simView.setFlag(cpuModel.Flags);
                        simView.activate_Flag();
                    } break;
            }
        }

        private void doOther()
        {
            switch (ui.Other)
            {
                case Other.none:{
                    }
                    break;
                case Other.incPC:{
                        //compute
                        cpuModel.incPC();
                        //notify
                        simView.setPC(cpuModel.Pc);
                    }
                    break;
                case Other.incSP:{
                        //compute
                        cpuModel.incSP();
                        //notify
                        simView.setSP(cpuModel.Sp);
                    }
                    break;
                case Other.decSP:{
                        //compute
                        cpuModel.decSP();
                        //notify
                        simView.setSP(cpuModel.Sp);
                        
                    }
                    break;
                case Other.C_0:{
                        //compute
                        cpuModel.clearC();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.C_1:{
                        //compute
                        cpuModel.setC();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.V_0:{
                        //compute
                        cpuModel.clearV();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.V_1:{
                        //compute
                        cpuModel.setV();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.Z_0:{
                        //compute
                        cpuModel.clearZ();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.Z_1:{
                        //compute
                        cpuModel.setZ();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.S_0:{
                        //compute
                        cpuModel.clearS();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.S_1:{
                        //compute
                        cpuModel.setS();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.Flg_0:{
                        //compute
                        cpuModel.clearFlags();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.Flg_1:{
                        //compute
                        cpuModel.setFlags();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.EnFlg:{
                        //compute
                        cpuModel.EnFlg();
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
                case Other.INTA:{
                        //compute
                        cpuModel.InterruptReq = false;
                        //notify
                        simView.setFlag(cpuModel.Flags);
                    }
                    break;
            }
        }

        private void doMem()
        {
            switch (ui.Mem)
            {
                case Mem.none: {
                        //compute

                        //notify
                        simView.setMemOp(ui.Mem.ToString());
                    }
                    break;
                case Mem.RD: {
                        //compute
                        cpuModel.Read();
                        //notify
                        simView.setMemOp(ui.Mem.ToString());
                        prgCtrl.selectMem(cpuModel.Adr);
                        simView.setMDR(cpuModel.Mdr);
                    } break;
                case Mem.RDFch: {
                        //compute
                        cpuModel.ReadIFCH();
                        //notify
                        simView.setMemOp(ui.Mem.ToString());
                        prgCtrl.selectMem(cpuModel.Adr);
                        simView.setIR(cpuModel.Ir);
                    } break;
                case Mem.WR: {
                        //compute
                        cpuModel.Write();
                        //notify
                        simView.setMemOp(ui.Mem.ToString());
                        prgCtrl.updateRow(cpuModel.Adr);
                        prgCtrl.selectMem(cpuModel.Adr);
                    } break;
            }
        }

        private void doIfJump()
        {
            switch (ui.Ifjmp)
            {
                case IF_JMP.if_none_STEP:
                    {
                        //i.InstructionCode = cpuModel.Ir;
                        this.uaddress++;
                    }
                    break;
                case IF_JMP.if_none_uadr:
                    {
                        this.doJumpuAdr();
                    }
                    break;
                case IF_JMP.if_none_DOF:
                    {
                        this.doJumpuAdr();
                    }
                    break;
                case IF_JMP.if_NoOprnd_ExBrDiv_STEP:
                    {
                        i.InstructionCode = cpuModel.Ir;
                        if((ushort)(i.opcode&0xf0)==0x80 || (ushort)(i.opcode & 0xf0) >= 0xc0)
                        {
                            this.doJumpuAdr(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_2OP_SOF_DOF:
                    {
                        i.InstructionCode = cpuModel.Ir;
                        if ((ushort)(i.opcode & 0xf0) < 0x80)
                        {
                            this.doJumpuAdr(uADR.SOF);
                        }
                        else
                        {
                            this.doJumpuAdr();
                        }
                    }
                    break;
                case IF_JMP.if_2OP_Ex2op_Ex1op:
                    {
                        i.InstructionCode = cpuModel.Ir;
                        if ((ushort)(i.opcode & 0xf0) < 0x80)
                        {
                            this.doJumpuAdr(uADR.Ex2OP);
                        }
                        else
                        {
                            this.doJumpuAdr();
                        }
                    }
                    break;
                case IF_JMP.if_RegD_STEP_WB:
                    {
                        i.InstructionCode = cpuModel.Ir;
                        if ((ushort)((i.InstructionCode & 0x0030) >> 4) == 1)
                        {
                            this.uaddress++;
                        }
                        else
                        {
                            this.doJumpuAdr();
                        }
                    }
                    break;
                case IF_JMP.if_INTR_INT_uadr:
                    {
                        if (this.cpuModel.InterruptReq)
                        {
                            this.doJumpuAdr(uADR.INT);
                        }
                        else
                        {
                            this.doJumpuAdr();
                        }
                    }
                    break;
                case IF_JMP.if_NZ_BR_STEP:
                    {
                        if (!this.cpuModel.Z())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_Z_BR_STEP:
                    {
                        if (this.cpuModel.Z())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_NS_BR_STEP:
                    {
                        if (!this.cpuModel.S())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_S_BR_STEP:
                    {
                        if (this.cpuModel.S())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_NC_BR_STEP:
                    {
                        if (!this.cpuModel.C())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_C_BR_STEP:
                    {
                        if (this.cpuModel.C())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_NV_BR_STEP:
                    {
                        if (!this.cpuModel.V())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
                case IF_JMP.if_V_BR_STEP:
                    {
                        if (this.cpuModel.V())
                        {
                            this.uaddress = (byte)(uADR.ExBrDiv_BR);
                        }
                        else
                        {
                            this.uaddress++;
                        }
                    }
                    break;
            }
        }

        private void doJumpuAdr(uADR uadr=uADR.none)
        {
            if (uadr == uADR.none)
            {
                uadr = ui.Uadr;
            }
            if(ui.uAdrByte == 0xff)
            {
                switch (uadr)
                {
                    case uADR.IFCH:
                        { uaddress = (byte)ui.Uadr; }
                        break;
                    case uADR.SOF:
                        {
                            ushort index = cpuModel.Ir;
                            index = (ushort)((index & 0x0c00) >> 9);//(ir11,ir10,0)
                            index += (ushort)uadr;//addbase

                            uaddress = index;
                        }
                        break;
                    case uADR.DOF:
                        {
                            ushort index = cpuModel.Ir;
                            index = (ushort)((index & 0x0030) >> 4);//(ir5,ir4)
                            index += (ushort)uadr;//addbase

                            uaddress = index;
                        }
                        break;
                    case uADR.WB:
                        { uaddress = (byte)uadr; }
                        break;
                    case uADR.Ex2OP:
                        {
                            ushort index = cpuModel.Ir;
                            index = (ushort)((index & 0x7000) >> 11);//(ir14,ir13,ir12,0)
                            index += (ushort)uadr;//addbase

                            uaddress = index;
                        }
                        break;
                    case uADR.Ex1OP:
                        {
                            ushort index = cpuModel.Ir;
                            index = (ushort)((index & 0x0f00) >> 7);//(ir11,ir10,ir9,ir8,0)
                            index += (ushort)uadr;//addbase

                            uaddress = index;
                        }
                        break;
                    case uADR.ExBrDiv_BR:
                        {
                            ushort index = cpuModel.Ir;
                            index = (ushort)((index & 0x1f00) >> 7);//(ir12,ir11,ir10,ir9,ir8,0)
                            index += (ushort)uadr;//addbase

                            uaddress = index;
                        }
                        break;
                    case uADR.Wait:
                        { uaddress = (byte)uadr; }
                        break;
                    case uADR.INT:
                        { uaddress = (byte)uADR.INT; }
                        break;
                }
            }
            else
            {
                uaddress = ui.uAdrByte;
            }
        }
        #endregion
        internal void IntReq()
        {
            this.cpuModel.InterruptReq = true;
            this.cpuModel.Ivr = Memory.KernelAddress;
            this.simView.setIVR(cpuModel.Ivr);
        }

        private bool isHalt()
        {
            return (
                ui.Sbus == SbusSrc.none && ui.Dbus == DbusSrc.none && ui.Aluop == AluOP.none &&
                ui.Other == Other.none && ui.Mem == Mem.none && ui.Ifjmp == IF_JMP.if_none_uadr
                && (ui.Uadr == uADR.none || ui.uAdrByte == 0xff)
                );
        }
    }
}
