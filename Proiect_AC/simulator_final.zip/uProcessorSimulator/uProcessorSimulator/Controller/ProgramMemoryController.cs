﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.Controller
{
    using System.Diagnostics;
    using System.IO;
    using uProcessorSimulator.CpuModel;
    using uProcessorSimulator.View;
    using Assembler;
    class ProgramMemoryController
    {
        ProgramMemoryView prgView;
        string currentFile;
        public ProgramMemoryController(ProgramMemoryView prgView)
        {
            this.prgView = prgView;
        }

        public void selectMem(int adr)
        {
            this.prgView.UpdateSelected(adr);
        }

        public void updateRow(int adr)
        {
            ushort value = Memory.read((ushort)adr);
            string[] content = new string[4];
            content[0] = "0x" + adr.ToString("X");
            content[1] = value.ToString("X");
            content[2] = value.ToString();
            content[3] = getBincodeString(value);
            this.prgView.UpdateRow(adr, content);
        }

        private void LoadView()
        {
            string[][] content = new string[Memory.MemoryLengthBytes/2][];
            int k = 0;
            for(int i = 0; i < Memory.MemoryLengthBytes; i+=2)
            {
                ushort word = Memory.read((ushort)i);
                content[k] = new string[4];
                content[k][0] = "0x" + i.ToString("X");
                content[k][1] = word.ToString("X");
                content[k][2] =(i<Memory.Pc)?word.ToString():getMemonic(word);
                content[k++][3] = getBincodeString(word);
            }
            this.prgView.LoadContent(content);
        }
        private void UpdateView()
        {
            string[][] content = new string[Memory.Pc / 2][];
            int k = 0;
            for (int i = 0; i < Memory.Pc; i += 2)
            {
                ushort word = Memory.read((ushort)i);
                content[k] = new string[4];
                content[k][0] = "0x" + i.ToString("X");
                content[k][1] = word.ToString("X");
                content[k][2] = word.ToString();
                content[k++][3] = getBincodeString(word);
            }
            this.prgView.UpdateMemory(content);
        }
        private string getMemonic(ushort word)
        {
            string memonic="";
            if (word == 0)
            {
                memonic = word.ToString();
            }
            else
            {
                Instruction i = new Instruction();
                i.InstructionCode = word;
                if (InstructionCodes.CpuInstr.ContainsValue(i.opcode))
                {
                    i = new CpuInstruction();
                    i.InstructionCode = word;
                    memonic = disassembledCpu((CpuInstruction)i);
                } else if (InstructionCodes.BranchInstr.ContainsValue(i.opcode))
                {
                    i = new BranchInstruction();
                    i.InstructionCode = word;
                    memonic = disassembledBr((BranchInstruction)i);
                }
                else if (InstructionCodes.OneOpInstr.ContainsValue(i.opcode))
                {
                    i = new OneOpInstrution();
                    i.InstructionCode = word;
                    memonic = disassembled1op((OneOpInstrution)i);
                }
                else if(InstructionCodes.TwoOpInstr.ContainsValue((byte)(i.opcode>>4)))
                {
                    i = new TwoOpInstruction();
                    i.InstructionCode = word;
                    memonic = dissassembled2op((TwoOpInstruction)i);
                }
                else
                {
                    memonic = word.ToString();
                }
            }
            
            return memonic;
        }
        private string dissassembled2op(TwoOpInstruction i)
        {
            string dest="",src="";
            string op = InstructionCodes.TwoOpInstr.FirstOrDefault(x => x.Value == i.opcode).Key;
            switch ((AddressingMode)i.MAdst)
            {
                case AddressingMode.MD: dest = " R" + i.Dst.ToString();
                    break;
                case AddressingMode.MI: dest = " (R" + i.Dst.ToString() + ")";
                    break;
                case AddressingMode.MX: dest = " index(R" + i.Dst.ToString() + ")";
                    break;
            }
            switch ((AddressingMode)i.MAsrc)
            {
                case AddressingMode.MA:
                    src = " imm";
                    break;
                case AddressingMode.MD:
                    src = " R" + i.Src.ToString();
                    break;
                case AddressingMode.MI:
                    src = " (R" + i.Src.ToString() + ")";
                    break;
                case AddressingMode.MX:
                    src = " index(R" + i.Src.ToString() + ")";
                    break;
            }

            return op + dest + src;
        }
        private string disassembled1op(OneOpInstrution i)
        {
            string dest = "";
            string op = InstructionCodes.OneOpInstr.FirstOrDefault(x => x.Value == i.opcode).Key;
            switch ((AddressingMode)i.MAdst)
            {
                case AddressingMode.MD:
                    dest = " R" + i.Dst.ToString();
                    break;
                case AddressingMode.MI:
                    dest = " (R" + i.Dst.ToString() + ")";
                    break;
                case AddressingMode.MX:
                    dest = " index(R" + i.Dst.ToString() + ")";
                    break;
            }
            return op + dest;
        }
        private string disassembledBr(BranchInstruction i)
        {
            string op = InstructionCodes.BranchInstr.FirstOrDefault(x => x.Value == i.opcode).Key;
            return op + i.offset.ToString();
        }
        private string disassembledCpu(CpuInstruction i)
        {
            string op = InstructionCodes.CpuInstr.FirstOrDefault(x => x.Value == i.opcode).Key;
            return op;
        }
        private string getBincodeString(ushort word)
        {
            string val = "";
            for (int i = 0; i < 16; i++)
            {
                val = (0x0001 & word).ToString() + val;
                word = (ushort)(word >> 1);
            }
            return val;
        }


        public void ReadBinaryFile(string path)
        {
            Memory.LoadMemory(path);
            LoadView();
            currentFile = path;
        }

        public void ReloadProgramInMemory()
        {
            this.ReadBinaryFile(currentFile);
        }

        internal void ParseAsm(string asmfilepath)
        {
            if(!File.Exists(Environment.CurrentDirectory + "\\Assembler.exe"))
            {
                throw new FileNotFoundException("Assembler not found in the application directory");
            }
            Process parser = new Process();
            parser.StartInfo.FileName = "Assembler.exe";
            parser.StartInfo.Arguments ="\"" + Path.GetFullPath( asmfilepath) + "\"";
            parser.StartInfo.UseShellExecute = false;
            parser.Start();
            parser.WaitForExit();
        }

        internal void relodForm(out ProgramMemoryView memView)
        {
            this.prgView = new ProgramMemoryView();
            memView = this.prgView;
        }
    }
}
