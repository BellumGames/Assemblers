﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.CpuModel
{

    #region Constants
    public enum SbusSrc
    {
        none	= 0x0,
        Regs	= 0x1,
        SP	    = 0x2,
        Temp	= 0x3,
        PC	    = 0x4,
        IVR	    = 0x5,
        ADR	    = 0x6,
        MDR	    = 0x7,
        IR      = 0x8,
        Flag    = 0x9,
        ZERO    = 0xA,
        ONE     = 0xB,
        mnsONE  = 0xC,
        nTemp   = 0xD

    }
    public enum DbusSrc
    {
        none	=	0x0,
        Regs	=	0x1,
        SP	    =	0x2,
        Temp	=	0x3,
        PC	    =	0x4,
        IVR	    =	0x5,
        ADR	    =	0x6,
        MDR	    =	0x7,
        IR_off  =	0x8,
        Flag	=	0x9,
        ZERO	=	0xA,
        ONE     =	0xB,
        mnsONE  =   0xC,
        nTemp   =   0xD
    }
    public enum AluOP
    {
        none	=	0x0,//none
        SUM	    =	0x1,
        SUB 	=	0x2,
        SBUS	=	0x3,
        DBUS	=	0x4,
        nDBUS	=	0x5,
        AND	    =	0x6,
        OR	    =	0x7,
        XOR 	=	0x8,
        ASL 	=	0x9,
        ASR 	=	0xA,
        LSR 	=	0xB,
        ROL 	=	0xC,
        ROR 	=	0xD,
        RLC 	=	0xE,
        RRC 	=	0xF

    }
    public enum RbusDst
    {
        none	=	0x0,
        Regs	=	0x1,
        SP	    =	0x2,
        Temp	=	0x3,
        PC	    =	0x4,
        IVR	    =	0x5,
        ADR	    =	0x6,
        MDR	    =	0x7,
        IR	    =	0x8,
        Flag	=	0x9

    }
    public enum Other
    {
        none	=	0x0,
        incPC	=	0x1,
        incSP	=	0x2,
        decSP	=	0x3,
        C_0 	=	0x4,
        C_1	    =	0x5,
        V_0	    =	0x6,
        V_1	    =	0x7,
        Z_0	    =	0x8,
        Z_1	    =	0x9,
        S_0	    =	0xA,
        S_1	    =	0xB,
        Flg_0	=	0xC,
        Flg_1	=	0xD,
        EnFlg   =   0xE,
        INTA    =   0xF

    }
    public enum Mem
    {
        none	=	0x0,
        RD	    =	0x1,
        RDFch	=	0x2,
        WR	    =	0x3

    }
    public enum IF_JMP
    {
        if_none_STEP	        =	0x0,
        if_none_uadr	        =	0x1,
        if_none_DOF	            =	0x2,
        if_NoOprnd_ExBrDiv_STEP	=	0x3,
        if_2OP_SOF_DOF	        =	0x4,
        if_2OP_Ex2op_Ex1op	    =	0x5,
        if_RegD_STEP_WB	        =	0x6,
        if_INTR_INT_uadr	    =	0x7,
        if_NZ_BR_STEP           =	0x8,
        if_Z_BR_STEP            =	0x9,
        if_NS_BR_STEP           =	0xA,
        if_S_BR_STEP            =	0xB,
        if_NC_BR_STEP           =	0xC,
        if_C_BR_STEP            =	0xD,
        if_NV_BR_STEP           =	0xE,
        if_V_BR_STEP            =	0xF

    }
    public enum uADR
    {
        none        =0xff,
        IFCH        =0x0,
        SOF         =0x9,//=0x2,
        DOF         =0x2,//=0xA,
        WB          =0x8,//=0xB,
        ExBrDiv_BR  =0x40,
        INT         =0x7A,
        Wait        =0x6c,
        Ex2OP       =0x10,
        Ex1OP       =0x20,

    }
    #endregion
    class uInstruction
    {
        private string label = "";
        private SbusSrc _sbus;
        private DbusSrc _dbus;
        private AluOP _aluop;
        private RbusDst _rbus;
        private Other _other;
        private Mem _mem;
        private IF_JMP _ifjmp;
        private uADR _uadr;
        private byte _uadrByte=0xff;

        #region properties
        public string Label { get { return this.label; } }
        public SbusSrc Sbus
        {
            get
            {
                return _sbus;
            }

        }
        public DbusSrc Dbus
        {
            get
            {
                return _dbus;
            }

        }
        public AluOP Aluop
        {
            get
            {
                return _aluop;
            }

        }
        public RbusDst Rbus
        {
            get
            {
                return _rbus;
            }

        }
        public Other Other
        {
            get
            {
                return _other;
            }

        }
        public Mem Mem
        {
            get
            {
                return _mem;
            }

        }
        public IF_JMP Ifjmp
        {
            get
            {
                return _ifjmp;
            }

        }
        public byte uAdrByte
        {
            get
            {
                return _uadrByte;
            }

        }

        public uADR Uadr
        {
            get
            {
                return _uadr;
            }
        }
        #endregion

        public uInstruction(string line)
        {
            string[] fields = line.Split(new string[] { ", ", ":\t"," " }, StringSplitOptions.RemoveEmptyEntries);
            int k = 0;
            if (fields.Length > 8)
            {
                this.label = fields[0];
                k++;
            }
            try { this._sbus = (SbusSrc)Enum.Parse(typeof(SbusSrc), fields[k++]); } catch (Exception) {; }
            try { this._dbus = (DbusSrc)Enum.Parse(typeof(DbusSrc), fields[k++]); } catch (Exception) {; }
            try { this._aluop = (AluOP)Enum.Parse(typeof(AluOP), fields[k++]); } catch (Exception) {; }
            try { this._rbus = (RbusDst)Enum.Parse(typeof(RbusDst), fields[k++]); } catch (Exception) {; }
            try { this._other = (Other)Enum.Parse(typeof(Other), fields[k++]); } catch (Exception) {; }
            try { this._mem = (Mem)Enum.Parse(typeof(Mem), fields[k++]); } catch (Exception) {; }
            try { this._ifjmp = (IF_JMP)Enum.Parse(typeof(IF_JMP), fields[k++]); } catch (Exception) {; }
            try { this._uadr = (uADR)Enum.Parse(typeof(uADR), fields[k]); }
            catch (Exception) { this._uadrByte = Convert.ToByte(fields[k],16); }

    }

        public uInstruction()
        {
            
        }

        internal string toString()
        {
            string ret = "";
            if (label.Any())
            {
                ret = ret + label + ":\t";
            }
            else
            {
                ret = ret + ":\t\t";
            }
            ret = ret + this._sbus.ToString() + ", " + this._dbus.ToString() + ", " +
                this._aluop.ToString() + ", " + this._rbus.ToString() + ", " + this._other.ToString() + ", " +
                this._mem.ToString() + ", " + this._ifjmp.ToString() + ", ";
            if (this._uadrByte == 0xff)
            { ret = ret + this._uadr.ToString(); }
            else
            { ret = ret + this._uadrByte; }
            return ret;
        }
    }
}
