﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator
{
    public static class Global
    {
        private static int executionSpeed;
        private static ushort pcAddress;
        private static ushort spAddress;


        public static int ExecutionSpeed
        {
            get
            {
                return executionSpeed;
            }

            set
            {
                if (value>=0 && value<=10)
                {
                    executionSpeed = value; 
                }else if (value > 10)
                {
                    executionSpeed = 10;
                }
                else
                {
                    executionSpeed = 0;
                }
            }
        }

        public static ushort SpAddress
        {
            get
            {
                return spAddress;
            }

            set
            {
                spAddress = value;
            }
        }
    }
}
