﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.ViewComponents
{
    using uProcessorSimulator.CpuModel;
    public delegate void SetRegDelegate(ushort value);
    public partial class cpuSchema : UserControl
    {
        Color deactive = SystemColors.ControlText;
        Color active = SystemColors.Highlight;

        
        public SetRegDelegate[] Reg = new SetRegDelegate[16];

        public cpuSchema()
        {
            InitializeComponent();
            Reg[0] = setR0;
            Reg[1] = setR1;
            Reg[2] = setR2;
            Reg[3] = setR3;
            Reg[4] = setR4;
            Reg[5] = setR5;
            Reg[6] = setR6;
            Reg[7] = setR7;
            Reg[8] = setR8;
            Reg[9] = setR9;
            Reg[10] = setR10;
            Reg[11] = setR11;
            Reg[12] = setR12;
            Reg[13] = setR13;
            Reg[14] = setR14;
            Reg[15] = setR15;
        }

        public void deactivate_All()
        {
            /*regs*/
            {
                this.R0.clearActive();
                this.R1.clearActive();
                this.R2.clearActive();
                this.R3.clearActive();
                this.R4.clearActive();
                this.R5.clearActive();
                this.R6.clearActive();
                this.R7.clearActive();
                this.R8.clearActive();
                this.R9.clearActive();
                this.R10.clearActive();
                this.R11.clearActive();
                this.R12.clearActive();
                this.R13.clearActive();
                this.R14.clearActive();
                this.R15.clearActive();
                this.IR.clearActive();
                this.MDR.clearActive();
                this.ADR.clearActive();
                this.PC.clearActive();
                this.SP.clearActive();
                this.T.clearActive();
                this.IVR.clearActive();
                this.Flag.clearActive();
            }
            /*comand lines*/
            {
                this.issIR_s.BorderColor = deactive;
                this.issIR_d.BorderColor = deactive;
                this.ldIR.BorderColor = deactive;

                this.issMDR_s.BorderColor = deactive;
                this.issMDR_d.BorderColor = deactive;
                this.ldMDR.BorderColor = deactive;

                this.issADR_s.BorderColor = deactive;
                this.issADR_d.BorderColor = deactive;
                this.ldADR.BorderColor = deactive;

                this.issREG_s.BorderColor = deactive;
                this.issREG_d.BorderColor = deactive;
                this.ldREG.BorderColor = deactive;

                this.issPC_s.BorderColor = deactive;
                this.issPC_d.BorderColor = deactive;
                this.ldPC.BorderColor = deactive;

                this.issSP_s.BorderColor = deactive;
                this.issSP_d.BorderColor = deactive;
                this.ldSP.BorderColor = deactive;

                this.issT_s.BorderColor = deactive;
                this.issT_d.BorderColor = deactive;
                this.ldT.BorderColor = deactive;

                this.issIVR_s.BorderColor = deactive;
                this.issIVR_d.BorderColor = deactive;
                this.ldIVR.BorderColor = deactive;

                this.issFlag_s.BorderColor = deactive;
                this.issFlag_d.BorderColor = deactive;
                this.ldFlag.BorderColor = deactive;

                this.aluIn_s.BorderColor = deactive;
                this.aluIn_d.BorderColor = deactive;
                this.aluOut.BorderColor = deactive;
            }
            /*clear busses*/
            this.DbusView.Value = 0;
            this.SbusView.Value = 0;
            this.RbusView.Value = 0;
            /*clear operations*/
            this.memOperation(Mem.none.ToString());
            this.setAluOp(AluOP.none.ToString());
        }

        public void toggleHexView()
        {
            bool newVal = !this.R0.HexView;
            this.R0.HexView = !this.R0.HexView;
            this.R1.HexView = !this.R1.HexView;
            this.R2.HexView = !this.R2.HexView;
            this.R3.HexView = !this.R3.HexView;
            this.R4.HexView = !this.R4.HexView;
            this.R5.HexView = !this.R5.HexView;
            this.R6.HexView = !this.R6.HexView;
            this.R7.HexView = !this.R7.HexView;
            this.R8.HexView = !this.R8.HexView;
            this.R9.HexView = !this.R9.HexView;
            this.R10.HexView = !this.R10.HexView;
            this.R11.HexView = !this.R11.HexView;
            this.R12.HexView = !this.R12.HexView;
            this.R13.HexView = !this.R13.HexView;
            this.R14.HexView = !this.R14.HexView;
            this.R15.HexView = !this.R15.HexView;

            this.IR.HexView = newVal;
            this.MDR.HexView = newVal;
            this.ADR.HexView = newVal;
            this.PC.HexView = newVal;
            this.SP.HexView = newVal;
            this.T.HexView = newVal;
            this.IVR.HexView = newVal;
            this.Flag.HexView = newVal;
            this.SbusView.HexView = newVal;
            this.DbusView.HexView = newVal;
            this.RbusView.HexView = newVal;
        }

        public void activateReg(int index)
        {
            switch (index)
            {
                case 0:
                    this.R0.setActive();
                    break;
                case 1:
                    this.R1.setActive();
                    break;
                case 2:
                    this.R2.setActive();
                    break;
                case 3:
                    this.R3.setActive();
                    break;
                case 4:
                    this.R4.setActive();
                    break;
                case 5:
                    this.R5.setActive();
                    break;
                case 6:
                    this.R6.setActive();
                    break;
                case 7:
                    this.R7.setActive();
                    break;
                case 8:
                    this.R8.setActive();
                    break;
                case 9:
                    this.R9.setActive();
                    break;
                case 10:
                    this.R10.setActive();
                    break;
                case 11:
                    this.R11.setActive();
                    break;
                case 12:
                    this.R12.setActive();
                    break;
                case 13:
                    this.R13.setActive();
                    break;
                case 14:
                    this.R14.setActive();
                    break;
                case 15:
                    this.R15.setActive();
                    break;
            }
        }

        //comands activation
        public void activateIR() { this.IR.setActive(); }
        public void activateMDR() { this.MDR.setActive(); }
        public void activateADR() { this.ADR.setActive(); }
        public void activatePC() { this.PC.setActive(); }
        public void activateSP() { this.SP.setActive(); }
        public void activateT() { this.T.setActive(); }
        public void activateIVR() { this.IVR.setActive(); }
        public void activateFlag() { this.Flag.setActive(); }
        
        /*issue on SBUS*/
        public void issIR_sbus() { this.issIR_s.BorderColor = active; }
        public void issMDR_sbus() { this.issMDR_s.BorderColor = active; }
        public void issADR_sbus() { this.issADR_s.BorderColor = active; }
        public void issREG_sbus() { this.issREG_s.BorderColor = active; }
        public void issPC_sbus() { this.issPC_s.BorderColor = active; }
        public void issSP_sbus() { this.issSP_s.BorderColor = active; }
        public void issT_sbus() { this.issT_s.BorderColor = active; }
        public void issIVR_sbus() { this.issIVR_s.BorderColor = active; }
        public void issFlag_sbus() { this.issFlag_s.BorderColor = active; }

        /*issue on DBUS*/
        public void issIR_dbus() { this.issIR_d.BorderColor = active; }
        public void issMDR_dbus() { this.issMDR_d.BorderColor = active; }
        public void issADR_dbus() { this.issADR_d.BorderColor = active; }
        public void issREG_dbus() { this.issREG_d.BorderColor = active; }
        public void issPC_dbus() { this.issPC_d.BorderColor = active; }
        public void issSP_dbus() { this.issSP_d.BorderColor = active; }
        public void issT_dbus() { this.issT_d.BorderColor = active; }
        public void issIVR_dbus() { this.issIVR_d.BorderColor = active; }
        public void issFlag_dbus() { this.issFlag_d.BorderColor = active; }

        public void alu_inpit_S() {
            this.aluIn_s.BorderColor = active;
            this.aluOut.BorderColor = active;
        }
        public void alu_inpit_D() {
            this.aluIn_d.BorderColor = active;
            this.aluOut.BorderColor = active;
        }

        /*load from RBUS*/
        public void ld_IR() { this.ldIR.BorderColor = active; }
        public void ld_MDR() { this.ldMDR.BorderColor = active; }
        public void ld_ADR() { this.ldADR.BorderColor = active; }
        public void ld_REG() { this.ldREG.BorderColor = active; }
        public void ld_PC() { this.ldPC.BorderColor = active; }
        public void ld_SP() { this.ldSP.BorderColor = active; }
        public void ld_T() { this.ldT.BorderColor = active; }
        public void ld_IVR() { this.ldIVR.BorderColor = active; }
        public void ld_Flag() { this.ldFlag.BorderColor = active; }

        public void setAluOp(string opr) { this.Alu_op.Text = opr; }
        public void memOperation(string opr) { this.memOp.Text = opr; }

        /*sets*/
        public void setIR(ushort value) { this.IR.Value = value; }
        public void setMDR(ushort value) { this.MDR.Value = value; }
        public void setADR(ushort value) { this.ADR.Value = value; }
        public void setR0(ushort value) { this.R0.Value = value; }
        public void setR1(ushort value) { this.R1.Value = value; }
        public void setR2(ushort value) { this.R2.Value = value; }
        public void setR3(ushort value) { this.R3.Value = value; }
        public void setR4(ushort value) { this.R4.Value = value; }
        public void setR5(ushort value) { this.R5.Value = value; }
        public void setR6(ushort value) { this.R6.Value = value; }
        public void setR7(ushort value) { this.R7.Value = value; }
        public void setR8(ushort value) { this.R8.Value = value; }
        public void setR9(ushort value) { this.R9.Value = value; }
        public void setR10(ushort value) { this.R10.Value = value; }
        public void setR11(ushort value) { this.R11.Value = value; }
        public void setR12(ushort value) { this.R12.Value = value; }
        public void setR13(ushort value) { this.R13.Value = value; }
        public void setR14(ushort value) { this.R14.Value = value; }
        public void setR15(ushort value) { this.R15.Value = value; }
        public void setPC(ushort value) { this.PC.Value = value; }
        public void setSP(ushort value) { this.SP.Value = value; }
        public void setT(ushort value) { this.T.Value = value; }
        public void setIVR(ushort value) { this.IVR.Value = value; }
        public void setFlag(ushort value) { this.Flag.Value = value; }
        public void setDbus(ushort value) { this.DbusView.Value = value; }
        public void setSbus(ushort value) { this.SbusView.Value = value; }
        public void setRbus(ushort value) { this.RbusView.Value = value; }

        private void cpuSchema_Load(object sender, EventArgs e)
        {

        }
    }
}
