﻿namespace uProcessorSimulator
{
    partial class UPSimView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadAsmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadBinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadUCodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.memoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.µInstructionMemoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.toggleBinHexViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uCodeEditorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stepToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.execSpeed = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.stepBtn = new System.Windows.Forms.Button();
            this.intreqBtn = new System.Windows.Forms.Button();
            this.cpuSchema = new uProcessorSimulator.ViewComponents.cpuSchema();
            this.runBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.mainMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.execSpeed)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuItem,
            this.viewToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.runToolStripMenuItem});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(176, 24);
            this.mainMenuStrip.TabIndex = 0;
            this.mainMenuStrip.Text = "mainMenuStrip";
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadAsmToolStripMenuItem,
            this.loadBinToolStripMenuItem,
            this.loadUCodeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.quitToolStripMenuItem});
            this.fileMenuItem.Name = "fileMenuItem";
            this.fileMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileMenuItem.Text = "File";
            // 
            // loadAsmToolStripMenuItem
            // 
            this.loadAsmToolStripMenuItem.Name = "loadAsmToolStripMenuItem";
            this.loadAsmToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.loadAsmToolStripMenuItem.Text = "Load asm";
            this.loadAsmToolStripMenuItem.Click += new System.EventHandler(this.loadAsmToolStripMenuItem_Click);
            // 
            // loadBinToolStripMenuItem
            // 
            this.loadBinToolStripMenuItem.Name = "loadBinToolStripMenuItem";
            this.loadBinToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.loadBinToolStripMenuItem.Text = "Load bin";
            this.loadBinToolStripMenuItem.Click += new System.EventHandler(this.loadBinToolStripMenuItem_Click);
            // 
            // loadUCodeToolStripMenuItem
            // 
            this.loadUCodeToolStripMenuItem.Name = "loadUCodeToolStripMenuItem";
            this.loadUCodeToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.loadUCodeToolStripMenuItem.Text = "Load uCode";
            this.loadUCodeToolStripMenuItem.Click += new System.EventHandler(this.loadUCodeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(135, 6);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.memoryToolStripMenuItem,
            this.µInstructionMemoryToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toggleBinHexViewToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // memoryToolStripMenuItem
            // 
            this.memoryToolStripMenuItem.Name = "memoryToolStripMenuItem";
            this.memoryToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.memoryToolStripMenuItem.Text = "Memory";
            this.memoryToolStripMenuItem.Click += new System.EventHandler(this.memoryToolStripMenuItem_Click);
            // 
            // µInstructionMemoryToolStripMenuItem
            // 
            this.µInstructionMemoryToolStripMenuItem.Name = "µInstructionMemoryToolStripMenuItem";
            this.µInstructionMemoryToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.µInstructionMemoryToolStripMenuItem.Text = "µInstruction Memory";
            this.µInstructionMemoryToolStripMenuItem.Click += new System.EventHandler(this.µInstructionMemoryToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(183, 6);
            // 
            // toggleBinHexViewToolStripMenuItem
            // 
            this.toggleBinHexViewToolStripMenuItem.Name = "toggleBinHexViewToolStripMenuItem";
            this.toggleBinHexViewToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.toggleBinHexViewToolStripMenuItem.Text = "Toggle Bin/Hex view";
            this.toggleBinHexViewToolStripMenuItem.Click += new System.EventHandler(this.toggleBinHexViewToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uCodeEditorToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // uCodeEditorToolStripMenuItem
            // 
            this.uCodeEditorToolStripMenuItem.Name = "uCodeEditorToolStripMenuItem";
            this.uCodeEditorToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.uCodeEditorToolStripMenuItem.Text = "uCodeEditor";
            this.uCodeEditorToolStripMenuItem.Click += new System.EventHandler(this.uCodeEditorToolStripMenuItem_Click);
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stepToolStripMenuItem,
            this.runToolStripMenuItem1});
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.runToolStripMenuItem.Text = "Run";
            // 
            // stepToolStripMenuItem
            // 
            this.stepToolStripMenuItem.Name = "stepToolStripMenuItem";
            this.stepToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.stepToolStripMenuItem.Text = "Step";
            this.stepToolStripMenuItem.Click += new System.EventHandler(this.stepToolStripMenuItem_Click);
            // 
            // runToolStripMenuItem1
            // 
            this.runToolStripMenuItem1.Name = "runToolStripMenuItem1";
            this.runToolStripMenuItem1.Size = new System.Drawing.Size(97, 22);
            this.runToolStripMenuItem1.Text = "Run";
            this.runToolStripMenuItem1.Click += new System.EventHandler(this.runToolStripMenuItem1_Click);
            // 
            // execSpeed
            // 
            this.execSpeed.Location = new System.Drawing.Point(273, 4);
            this.execSpeed.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.execSpeed.Name = "execSpeed";
            this.execSpeed.Size = new System.Drawing.Size(36, 20);
            this.execSpeed.TabIndex = 2;
            this.execSpeed.ValueChanged += new System.EventHandler(this.execSpeed_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(221, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "100ms x";
            // 
            // stepBtn
            // 
            this.stepBtn.Location = new System.Drawing.Point(315, 1);
            this.stepBtn.Name = "stepBtn";
            this.stepBtn.Size = new System.Drawing.Size(46, 23);
            this.stepBtn.TabIndex = 4;
            this.stepBtn.Text = "Step";
            this.stepBtn.UseVisualStyleBackColor = true;
            this.stepBtn.Click += new System.EventHandler(this.stepBtn_Click);
            // 
            // intreqBtn
            // 
            this.intreqBtn.Location = new System.Drawing.Point(672, 1);
            this.intreqBtn.Name = "intreqBtn";
            this.intreqBtn.Size = new System.Drawing.Size(54, 23);
            this.intreqBtn.TabIndex = 5;
            this.intreqBtn.Text = "INTreq";
            this.intreqBtn.UseVisualStyleBackColor = true;
            this.intreqBtn.Click += new System.EventHandler(this.intreqBtn_Click);
            // 
            // cpuSchema
            // 
            this.cpuSchema.BackColor = System.Drawing.Color.White;
            this.cpuSchema.Cursor = System.Windows.Forms.Cursors.Default;
            this.cpuSchema.Location = new System.Drawing.Point(12, 27);
            this.cpuSchema.Name = "cpuSchema";
            this.cpuSchema.Size = new System.Drawing.Size(727, 499);
            this.cpuSchema.TabIndex = 1;
            // 
            // runBtn
            // 
            this.runBtn.Location = new System.Drawing.Point(367, 1);
            this.runBtn.Name = "runBtn";
            this.runBtn.Size = new System.Drawing.Size(46, 23);
            this.runBtn.TabIndex = 6;
            this.runBtn.Text = "Run";
            this.runBtn.UseVisualStyleBackColor = true;
            this.runBtn.Click += new System.EventHandler(this.runBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(419, 1);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(46, 23);
            this.resetBtn.TabIndex = 7;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // UPSimView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 542);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.runBtn);
            this.Controls.Add(this.intreqBtn);
            this.Controls.Add(this.stepBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.execSpeed);
            this.Controls.Add(this.cpuSchema);
            this.Controls.Add(this.mainMenuStrip);
            this.MainMenuStrip = this.mainMenuStrip;
            this.Name = "UPSimView";
            this.Text = "uProcessor Simulator";
            this.Load += new System.EventHandler(this.MainFrom_Load);
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.execSpeed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem memoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem µInstructionMemoryToolStripMenuItem;
        private ViewComponents.cpuSchema cpuSchema;
        private System.Windows.Forms.ToolStripMenuItem loadAsmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadUCodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uCodeEditorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stepToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem1;
        private System.Windows.Forms.NumericUpDown execSpeed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button stepBtn;
        private System.Windows.Forms.ToolStripMenuItem loadBinToolStripMenuItem;
        private System.Windows.Forms.Button intreqBtn;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toggleBinHexViewToolStripMenuItem;
        private System.Windows.Forms.Button runBtn;
        private System.Windows.Forms.Button resetBtn;
    }
}

