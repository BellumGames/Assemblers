﻿using Microsoft.VisualBasic.PowerPacks;
namespace uProcessorSimulator
{
    partial class CpuShema
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registerComponent12 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent11 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent10 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent9 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent8 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent7 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent6 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent5 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent4 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent3 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent2 = new uProcessorSimulator.RegisterComponent();
            this.registerComponent1 = new uProcessorSimulator.RegisterComponent();
            this.R3regComp = new uProcessorSimulator.RegisterComponent();
            this.R2regComp = new uProcessorSimulator.RegisterComponent();
            this.R1regComp = new uProcessorSimulator.RegisterComponent();
            this.R0regComp = new uProcessorSimulator.RegisterComponent();
            this.flag_ReagComp1 = new uProcessorSimulator.ViewComponents.Flag_ReagComp();
            this.pC_RegComp1 = new uProcessorSimulator.ViewComponents.PC_RegComp();
            this.sP_RegComp1 = new uProcessorSimulator.ViewComponents.SP_RegComp();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.dBusDrawLine = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.SbusDrawLine = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.SuspendLayout();
            // 
            // registerComponent12
            // 
            this.registerComponent12.HexView = false;
            this.registerComponent12.Location = new System.Drawing.Point(234, 175);
            this.registerComponent12.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent12.Name = "registerComponent12";
            this.registerComponent12.RegisterName = "R15 ";
            this.registerComponent12.Size = new System.Drawing.Size(160, 23);
            this.registerComponent12.TabIndex = 15;
            this.registerComponent12.Value = ((ushort)(2));
            // 
            // registerComponent11
            // 
            this.registerComponent11.HexView = false;
            this.registerComponent11.Location = new System.Drawing.Point(234, 153);
            this.registerComponent11.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent11.Name = "registerComponent11";
            this.registerComponent11.RegisterName = "R14 ";
            this.registerComponent11.Size = new System.Drawing.Size(160, 24);
            this.registerComponent11.TabIndex = 14;
            this.registerComponent11.Value = ((ushort)(0));
            // 
            // registerComponent10
            // 
            this.registerComponent10.HexView = false;
            this.registerComponent10.Location = new System.Drawing.Point(234, 131);
            this.registerComponent10.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent10.Name = "registerComponent10";
            this.registerComponent10.RegisterName = "R13 ";
            this.registerComponent10.Size = new System.Drawing.Size(160, 24);
            this.registerComponent10.TabIndex = 13;
            this.registerComponent10.Value = ((ushort)(0));
            // 
            // registerComponent9
            // 
            this.registerComponent9.HexView = false;
            this.registerComponent9.Location = new System.Drawing.Point(234, 109);
            this.registerComponent9.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent9.Name = "registerComponent9";
            this.registerComponent9.RegisterName = "R12 ";
            this.registerComponent9.Size = new System.Drawing.Size(160, 22);
            this.registerComponent9.TabIndex = 12;
            this.registerComponent9.Value = ((ushort)(0));
            // 
            // registerComponent8
            // 
            this.registerComponent8.HexView = false;
            this.registerComponent8.Location = new System.Drawing.Point(234, 87);
            this.registerComponent8.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent8.Name = "registerComponent8";
            this.registerComponent8.RegisterName = "R11 ";
            this.registerComponent8.Size = new System.Drawing.Size(159, 24);
            this.registerComponent8.TabIndex = 11;
            this.registerComponent8.Value = ((ushort)(0));
            // 
            // registerComponent7
            // 
            this.registerComponent7.HexView = false;
            this.registerComponent7.Location = new System.Drawing.Point(234, 65);
            this.registerComponent7.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent7.Name = "registerComponent7";
            this.registerComponent7.RegisterName = "R10";
            this.registerComponent7.Size = new System.Drawing.Size(156, 24);
            this.registerComponent7.TabIndex = 10;
            this.registerComponent7.Value = ((ushort)(0));
            // 
            // registerComponent6
            // 
            this.registerComponent6.HexView = false;
            this.registerComponent6.Location = new System.Drawing.Point(234, 43);
            this.registerComponent6.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent6.Name = "registerComponent6";
            this.registerComponent6.RegisterName = "R9  ";
            this.registerComponent6.Size = new System.Drawing.Size(157, 24);
            this.registerComponent6.TabIndex = 9;
            this.registerComponent6.Value = ((ushort)(0));
            // 
            // registerComponent5
            // 
            this.registerComponent5.HexView = false;
            this.registerComponent5.Location = new System.Drawing.Point(234, 21);
            this.registerComponent5.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent5.Name = "registerComponent5";
            this.registerComponent5.RegisterName = "R8  ";
            this.registerComponent5.Size = new System.Drawing.Size(157, 24);
            this.registerComponent5.TabIndex = 8;
            this.registerComponent5.Value = ((ushort)(0));
            // 
            // registerComponent4
            // 
            this.registerComponent4.HexView = false;
            this.registerComponent4.Location = new System.Drawing.Point(77, 175);
            this.registerComponent4.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent4.Name = "registerComponent4";
            this.registerComponent4.RegisterName = "R7  ";
            this.registerComponent4.Size = new System.Drawing.Size(157, 24);
            this.registerComponent4.TabIndex = 7;
            this.registerComponent4.Value = ((ushort)(0));
            // 
            // registerComponent3
            // 
            this.registerComponent3.HexView = false;
            this.registerComponent3.Location = new System.Drawing.Point(77, 153);
            this.registerComponent3.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent3.Name = "registerComponent3";
            this.registerComponent3.RegisterName = "R6  ";
            this.registerComponent3.Size = new System.Drawing.Size(157, 24);
            this.registerComponent3.TabIndex = 6;
            this.registerComponent3.Value = ((ushort)(0));
            // 
            // registerComponent2
            // 
            this.registerComponent2.HexView = false;
            this.registerComponent2.Location = new System.Drawing.Point(77, 131);
            this.registerComponent2.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent2.Name = "registerComponent2";
            this.registerComponent2.RegisterName = "R5  ";
            this.registerComponent2.Size = new System.Drawing.Size(157, 24);
            this.registerComponent2.TabIndex = 5;
            this.registerComponent2.Value = ((ushort)(0));
            // 
            // registerComponent1
            // 
            this.registerComponent1.HexView = false;
            this.registerComponent1.Location = new System.Drawing.Point(77, 109);
            this.registerComponent1.Margin = new System.Windows.Forms.Padding(0);
            this.registerComponent1.Name = "registerComponent1";
            this.registerComponent1.RegisterName = "R4  ";
            this.registerComponent1.Size = new System.Drawing.Size(157, 24);
            this.registerComponent1.TabIndex = 4;
            this.registerComponent1.Value = ((ushort)(0));
            // 
            // R3regComp
            // 
            this.R3regComp.HexView = false;
            this.R3regComp.Location = new System.Drawing.Point(77, 87);
            this.R3regComp.Margin = new System.Windows.Forms.Padding(0);
            this.R3regComp.Name = "R3regComp";
            this.R3regComp.RegisterName = "R3  ";
            this.R3regComp.Size = new System.Drawing.Size(158, 24);
            this.R3regComp.TabIndex = 3;
            this.R3regComp.Value = ((ushort)(0));
            // 
            // R2regComp
            // 
            this.R2regComp.HexView = false;
            this.R2regComp.Location = new System.Drawing.Point(77, 65);
            this.R2regComp.Margin = new System.Windows.Forms.Padding(0);
            this.R2regComp.Name = "R2regComp";
            this.R2regComp.RegisterName = "R2  ";
            this.R2regComp.Size = new System.Drawing.Size(157, 24);
            this.R2regComp.TabIndex = 2;
            this.R2regComp.Value = ((ushort)(0));
            // 
            // R1regComp
            // 
            this.R1regComp.HexView = false;
            this.R1regComp.Location = new System.Drawing.Point(77, 43);
            this.R1regComp.Margin = new System.Windows.Forms.Padding(0);
            this.R1regComp.Name = "R1regComp";
            this.R1regComp.RegisterName = "R1  ";
            this.R1regComp.Size = new System.Drawing.Size(158, 24);
            this.R1regComp.TabIndex = 1;
            this.R1regComp.Value = ((ushort)(0));
            // 
            // R0regComp
            // 
            this.R0regComp.HexView = false;
            this.R0regComp.Location = new System.Drawing.Point(77, 21);
            this.R0regComp.Margin = new System.Windows.Forms.Padding(0);
            this.R0regComp.Name = "R0regComp";
            this.R0regComp.RegisterName = "R0  ";
            this.R0regComp.Size = new System.Drawing.Size(158, 24);
            this.R0regComp.TabIndex = 0;
            this.R0regComp.Value = ((ushort)(0));
            // 
            // flag_ReagComp1
            // 
            this.flag_ReagComp1.HexView = false;
            this.flag_ReagComp1.Location = new System.Drawing.Point(234, 449);
            this.flag_ReagComp1.Name = "flag_ReagComp1";
            this.flag_ReagComp1.Size = new System.Drawing.Size(186, 30);
            this.flag_ReagComp1.TabIndex = 16;
            this.flag_ReagComp1.Value = ((ushort)(0));
            // 
            // pC_RegComp1
            // 
            this.pC_RegComp1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pC_RegComp1.HexView = false;
            this.pC_RegComp1.Location = new System.Drawing.Point(234, 374);
            this.pC_RegComp1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pC_RegComp1.Name = "pC_RegComp1";
            this.pC_RegComp1.Size = new System.Drawing.Size(173, 30);
            this.pC_RegComp1.TabIndex = 17;
            this.pC_RegComp1.Value = ((ushort)(0));
            // 
            // sP_RegComp1
            // 
            this.sP_RegComp1.HexView = false;
            this.sP_RegComp1.Location = new System.Drawing.Point(234, 323);
            this.sP_RegComp1.Name = "sP_RegComp1";
            this.sP_RegComp1.Size = new System.Drawing.Size(173, 32);
            this.sP_RegComp1.TabIndex = 18;
            this.sP_RegComp1.Value = ((ushort)(0));
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.SbusDrawLine,
            this.dBusDrawLine});
            this.shapeContainer1.Size = new System.Drawing.Size(886, 633);
            this.shapeContainer1.TabIndex = 19;
            this.shapeContainer1.TabStop = false;
            // 
            // dBusDrawLine
            // 
            this.dBusDrawLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dBusDrawLine.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.dBusDrawLine.BorderWidth = 8;
            this.dBusDrawLine.Name = "dBusDrawLine";
            this.dBusDrawLine.X1 = 496;
            this.dBusDrawLine.X2 = 492;
            this.dBusDrawLine.Y1 = 20;
            this.dBusDrawLine.Y2 = 579;
            // 
            // SbusDrawLine
            // 
            this.SbusDrawLine.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.SbusDrawLine.BorderWidth = 8;
            this.SbusDrawLine.Name = "SbusDrawLine";
            this.SbusDrawLine.X1 = 600;
            this.SbusDrawLine.X2 = 593;
            this.SbusDrawLine.Y1 = 22;
            this.SbusDrawLine.Y2 = 573;
            // 
            // CpuShema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.sP_RegComp1);
            this.Controls.Add(this.pC_RegComp1);
            this.Controls.Add(this.flag_ReagComp1);
            this.Controls.Add(this.registerComponent12);
            this.Controls.Add(this.registerComponent11);
            this.Controls.Add(this.registerComponent10);
            this.Controls.Add(this.registerComponent9);
            this.Controls.Add(this.registerComponent8);
            this.Controls.Add(this.registerComponent7);
            this.Controls.Add(this.registerComponent6);
            this.Controls.Add(this.registerComponent5);
            this.Controls.Add(this.registerComponent4);
            this.Controls.Add(this.registerComponent3);
            this.Controls.Add(this.registerComponent2);
            this.Controls.Add(this.registerComponent1);
            this.Controls.Add(this.R3regComp);
            this.Controls.Add(this.R2regComp);
            this.Controls.Add(this.R1regComp);
            this.Controls.Add(this.R0regComp);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "CpuShema";
            this.Size = new System.Drawing.Size(886, 633);
            this.ResumeLayout(false);

        }


        #endregion

        private RegisterComponent R0regComp;
        private RegisterComponent R1regComp;
        private RegisterComponent R2regComp;
        private RegisterComponent R3regComp;
        private RegisterComponent registerComponent1;
        private RegisterComponent registerComponent2;
        private RegisterComponent registerComponent11;
        private RegisterComponent registerComponent12;
        private RegisterComponent registerComponent10;
        private RegisterComponent registerComponent9;
        private RegisterComponent registerComponent8;
        private RegisterComponent registerComponent7;
        private RegisterComponent registerComponent6;
        private RegisterComponent registerComponent5;
        private RegisterComponent registerComponent4;
        private RegisterComponent registerComponent3;
        private ViewComponents.Flag_ReagComp flag_ReagComp1;
        private ViewComponents.PC_RegComp pC_RegComp1;
        private ViewComponents.SP_RegComp sP_RegComp1;
        private ShapeContainer shapeContainer1;
        private LineShape dBusDrawLine;
        private LineShape SbusDrawLine;
    }
}
