﻿namespace uProcessorSimulator.ViewComponents
{
    partial class PC_RegComp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegName = new System.Windows.Forms.Label();
            this.RegValue = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // RegName
            // 
            this.RegName.AutoSize = true;
            this.RegName.BackColor = System.Drawing.Color.DarkGray;
            this.RegName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RegName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegName.Location = new System.Drawing.Point(1, 4);
            this.RegName.Margin = new System.Windows.Forms.Padding(0);
            this.RegName.Name = "RegName";
            this.RegName.Padding = new System.Windows.Forms.Padding(2);
            this.RegName.Size = new System.Drawing.Size(40, 22);
            this.RegName.TabIndex = 3;
            this.RegName.Text = "PC  ";
            // 
            // RegValue
            // 
            this.RegValue.AutoSize = true;
            this.RegValue.BackColor = System.Drawing.Color.DarkGray;
            this.RegValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RegValue.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegValue.Location = new System.Drawing.Point(41, 4);
            this.RegValue.Margin = new System.Windows.Forms.Padding(0);
            this.RegValue.Name = "RegValue";
            this.RegValue.Padding = new System.Windows.Forms.Padding(2);
            this.RegValue.Size = new System.Drawing.Size(119, 22);
            this.RegValue.TabIndex = 2;
            this.RegValue.Text = "000000000000000";
            // 
            // PC_RegComp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.RegName);
            this.Controls.Add(this.RegValue);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PC_RegComp";
            this.Size = new System.Drawing.Size(163, 30);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label RegName;
        private System.Windows.Forms.Label RegValue;
    }
}
