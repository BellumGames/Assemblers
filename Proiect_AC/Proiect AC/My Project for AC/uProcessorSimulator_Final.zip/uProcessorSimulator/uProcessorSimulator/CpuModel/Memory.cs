﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace uProcessorSimulator.CpuModel
{
    using Assembler;
    static class Memory
    {
        static SegmentMemory memory;
        static ushort pc = 0, sp = 0;
        static ushort kernelAddress;
        static ushort kernelSize = 1;
        static ushort[] kernel = { 0xDB00 }; //iret
        static ushort[] Ivt = { 0x004C };

        public static int MemoryLengthBytes
        {
            get { return memory.SegmentSize; }
        }

        public static ushort Pc
        {
            get
            {
                return pc;
            }
        }
        public static ushort Sp
        {
            get
            {
                return sp;
            }
        }
        public static ushort KernelAddress
        {
            get
            {
                return kernelAddress;
            }
        }

        public static void LoadMemory(string filePath)
        {
            memory = new SegmentMemory();
            FileStream fs = new FileStream(filePath, FileMode.Open);
            BinaryReader binReader = new BinaryReader(fs);
            pc = binReader.ReadUInt16();
            sp = binReader.ReadUInt16();
            ushort word;
            while(true)
            {
                try
                {
                    word = binReader.ReadUInt16();
                }
                catch (EndOfStreamException)
                {
                    break;
                }
                memory.Add(word);
            }
            binReader.Close();
            fs.Close();
            int k = sp - memory.CrntOffset;
            for (; k > 0; k-=2)
            {
                memory.Add(0);
            }
            kernelAddress = (ushort)memory.CrntOffset;
            for (int i = 0; i < Ivt.Length; i++)
            {
                memory.Add(Ivt[i]);
            }
            for (int i = 0; i < kernel.Length; i++)
            {
                memory.Add(kernel[i]);
            }
        }

        public static ushort read(ushort address)
        {
            return memory[address];
        }

        public static Instruction readInstruction(ushort address)
        {
            Instruction i = new Instruction();
            i.InstructionCode = memory[address];
            return i;
        }
        public static void write(ushort address, ushort data)
        {
            memory[address] = data;
        }

        public static List<string> getDecodedCode()
        {
            List<string> code = new List<string>();
            //find way to decode

            return code;
        }
    }
}
