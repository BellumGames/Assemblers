﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.View
{
    public partial class ProgramMemoryView : Form
    {
        public delegate void UpdateSelectDel(int index);
        public delegate void UpdateRowDel(int index, string[] content);
        public UpdateSelectDel UpdateSelected;
        public UpdateRowDel UpdateRow;
        public ProgramMemoryView()
        {
            InitializeComponent();
            this.UpdateSelected = selectRow;
            this.UpdateRow = updateRow;
        }

        internal void LoadContent(string[][] content)
        {
            this.dataview.Rows.Clear();
            for (int i = 0; i < content.Length; i++)
            {
                dataview.Rows.Add();
                dataview.Rows[i].Cells[0].Value = content[i][0];
                dataview.Rows[i].Cells[1].Value = content[i][1];
                dataview.Rows[i].Cells[2].Value = content[i][2];
                dataview.Rows[i].Cells[3].Value = content[i][3]; 
            }
        }
        internal void UpdateMemory(string[][] content)
        {
            this.dataview.Rows.Clear();
            for (int i = 0; i < content.Length; i++)
            {
                this.dataview.Rows.Add();
                dataview.Rows[i].Cells[0].Value = content[i][0];
                dataview.Rows[i].Cells[1].Value = content[i][1];
                dataview.Rows[i].Cells[2].Value = content[i][2];
                dataview.Rows[i].Cells[3].Value = content[i][3];
            }
        }
        private void selectRow(int index)
        {
            this.dataview.Focus();
            this.dataview.Rows[index/2].Selected = true;
        }

        private void updateRow(int index,string[] content)
        {
            this.dataview.Rows[index / 2].Cells[1].Value = content[1];
            this.dataview.Rows[index / 2].Cells[2].Value = content[2];
            this.dataview.Rows[index / 2].Cells[3].Value = content[3];
        }
    }
}
