﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.View
{
    public partial class MicroMemoryView : Form
    {
        public delegate void updateSelectDel(int index);
        public updateSelectDel UpdateSelected;

        public MicroMemoryView()
        {
            InitializeComponent();
            this.UpdateSelected = selectRow;
        }

        private void MicroMemoryView_Load(object sender, EventArgs e)
        {

        }

        internal void LoadContent(List<string> ucode)
        {
            this.dataView.Rows.Clear();
            int length = ucode.Count;
            for (int i = 0; i < length; i++)
            {
                string[] fields = ucode[i].Split(new string[] { ", ", ":\t", " " }, StringSplitOptions.RemoveEmptyEntries);
                int k = 0;
                this.dataView.Rows.Add();
                this.dataView.Rows[i].Cells[0].Value = "0x" + i.ToString("X");
                if (fields.Length > 8)
                {
                    this.dataView.Rows[i].Cells[1].Value = fields[0];
                    k++;
                }
                else
                {
                    this.dataView.Rows[i].Cells[1].Value = "";
                }
                this.dataView.Rows[i].Cells[2].Value = fields[0+k];//sbus
                this.dataView.Rows[i].Cells[3].Value = fields[1+k];//dbus
                this.dataView.Rows[i].Cells[4].Value = fields[2+k];//alu
                this.dataView.Rows[i].Cells[5].Value = fields[3+k];//rbus
                this.dataView.Rows[i].Cells[6].Value = fields[4+k];//other
                this.dataView.Rows[i].Cells[7].Value = fields[5+k];//mem
                this.dataView.Rows[i].Cells[8].Value = fields[6+k];//jmp
                this.dataView.Rows[i].Cells[9].Value = fields[7+k];//uadr
            }
            this.dataView.ClearSelection();
        }

        private void selectRow(int index)
        {
            this.dataView.Focus();
            this.dataView.Rows[index].Selected = true;
        }

        private void MicroMemoryView_FormClosing(object sender, FormClosingEventArgs e)
        {
        }
    }
}
