﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.Tools
{
    public partial class uCodeEditorForm : Form
    {
        private const  int max=128;
        uInstrEditorComp[] uInstr = new uInstrEditorComp[max];
        string openedFilePath = "";

        public uCodeEditorForm()
        {
            InitializeComponent();
            openFileDialog.InitialDirectory = Environment.CurrentDirectory;
            saveFileDialog.InitialDirectory = Environment.CurrentDirectory;
        }

        private void uCodeEditorForm_Load(object sender, EventArgs e)
        {
            this.tableLayout.RowCount = this.uInstr.Length;
            for (int index = 0; index < this.uInstr.Length; index++)
            {
                this.uInstr[index] = new uInstrEditorComp(index);
                this.tableLayout.Controls.Add(this.uInstr[index], 0, index);
                this.tableLayout.RowCount += 1;
            }

        }

        private void load()
        {
            string line;
            int k = 0;
            StreamReader sr = new StreamReader(openedFilePath);
            while((line = sr.ReadLine()) != null)
            {
                this.uInstr[k++].init(line);
            }
            sr.Close();
        }

        public void generate_file(string path)
        {
            List<string> list = new List<string>();
            foreach (uInstrEditorComp ui in uInstr) 
            {
                if (ui!=null)
                {
                    list.Add(ui.GetuInstr()); 
                }

            }
            StreamWriter sw = new StreamWriter(path);
            foreach(string line in list)
            {
                sw.WriteLine(line);
            }
            sw.Close();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog.Filter = "(.uc)|*.uc|All Files (*.*)|*.*";
            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.generate_file(saveFileDialog.FileName);
            }
            this.saveFileDialog.Filter = "(.uc)|*.uc";
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.openedFilePath = this.openFileDialog.FileName;
                this.load();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(this.openedFilePath != "")
            {
                generate_file(this.openedFilePath);
            }
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
