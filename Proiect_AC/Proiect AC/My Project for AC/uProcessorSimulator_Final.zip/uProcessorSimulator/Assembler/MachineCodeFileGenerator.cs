﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Assembler
{
    internal class MachineCodeFileGenerator
    {
        private List<string> codeLines;
        private SegmentMemory codeSegment;
        private SegmentMemory dataSegment;
        private int stackSize;

        private ushort dataAddress;
        private ushort codeAddress;
        private ushort stackpointer;
        private SegmentMemory program;

        public MachineCodeFileGenerator(SegmentMemory dataSegment, SegmentMemory codeSegment, int stackSize, List<string> codeLines)
        {
            this.dataSegment = dataSegment;
            this.codeSegment = codeSegment;
            this.stackSize = stackSize;
            this.codeLines = codeLines;

        }

        public void generate_output(string filePath)
        {
            this.dataAddress = 0;
            this.codeAddress = (ushort)this.dataSegment.CrntOffset; // length
            //complete the program segment
            this.program = new SegmentMemory();
            int program_length = this.dataSegment.CrntOffset + this.codeSegment.CrntOffset;
            for(int i = 0; i < this.dataSegment.CrntOffset; i+=2)
            {
                this.program.Add(this.dataSegment[i]);
            }
            for (int i = 0; i < this.codeSegment.CrntOffset; i += 2)
            {
                this.program.Add(this.codeSegment[i]);
            }
            this.stackpointer = (ushort)(this.program.CrntOffset + this.stackSize);

            StreamWriter file = new StreamWriter(filePath+"s");
            file.AutoFlush = true;
            //file.WriteLine(this.dataAddress);
            file.WriteLine(this.codeAddress);
            file.WriteLine(this.stackpointer);
            for (int i = 0; i < this.program.CrntOffset; i += 2)
            {
                file.WriteLine(this.program[i]);
            }
            FileStream binFile = new FileStream(filePath,FileMode.Create);
            BinaryWriter binW = new BinaryWriter(binFile);
            binW.Write(this.codeAddress);
            binW.Write(this.stackpointer);
            for(int i = 0; i < this.program.CrntOffset; i += 2)
            {
                binW.Write(this.program[i]);
            }
            binW.Close();
            binFile.Close();
            readback(filePath);
        }

        private void readback(string filePath)
        {
            FileStream binfile = new FileStream(filePath, FileMode.Open);
            BinaryReader binr = new BinaryReader(binfile);
            ushort read = binr.ReadUInt16();
            read = binr.ReadUInt16();
            for(int i = 0; i < this.program.CrntOffset; i += 2)
            {
                read = binr.ReadUInt16();
                if(read!= program[i])
                {
                    Console.WriteLine("problem");
                }
            }
            binr.Close();
            binfile.Close();
        }
    }
}