﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Assembler
{
    #region constants
    public static class Const
    {
        public static readonly byte HIGH = 1;
        public static readonly byte LOW = 0;
    }
    #endregion

    #region classes

    public class Instruction
    {
        protected const int high = 1;
        protected const int low = 0;

        private ushort _Instruction;
        public Instruction()
        {
            //this._Instruction = 0;
        }

        public byte[] toByteArray()
        {
            byte[] ret = new byte[2];
            ret[Const.HIGH] = (byte)(this._Instruction >> 8);
            ret[Const.LOW] = (byte)(this._Instruction);
            return ret;
        }

        public ushort InstructionCode
        {
            get { return this._Instruction; }
            set { this._Instruction = (ushort)value; }

        }

        public byte this[int index]
        {
            get { return (byte)(this._Instruction >> (index * 8)); }
            set
            {
                this._Instruction &= (ushort)(0xff00 >> (index * 8));
                this._Instruction += (ushort)(value << (index * 8));
            }
        }

        public virtual byte opcode
        {
            get { return (byte)(_Instruction >> 8); }
            set
            {
                this._Instruction = (ushort)(this._Instruction & 0x00ff); //clear old opcode
                this._Instruction += (ushort)(value << 8);
            }
        }

    }

    public class TwoOpInstruction : Instruction
    {
        public TwoOpInstruction():base()
        {

        }

        public override byte opcode
        {
            get
            {
                return (byte)(this[high]>>4);
            }

            set
            {
                this[high] = (byte)(this[high] & 0x0f);
                this[high] += (byte)(value << 4);
            }
        }

        public byte Dst
        {
            get
            {
                return (byte)(this[low] & 0x0f); 
            }

            set
            {
                this[low] = (byte)((value & 0x0f) + (this[low] & 0xf0));
            }
        }

        public byte MAdst
        {
            get
            {
                return (byte)((this[low] >> 4) & 0x03);
            }

            set
            {
                this[low] = (byte)(((value&0x3) << 4) + (this[low] & 0xcf));
            }
        }

        public byte MAsrc
        {
            get
            {
                return (byte)((this[high]>>2)&0x03);
            }

            set
            {
                this[high] = (byte)((this[high] & 0xf3) + ((value & 0x3) << 2));
            }
        }

        public byte Src
        {
            get
            {
                return (byte)((this.InstructionCode & 0x03cf) >> 6);
            }

            set
            {
                //ushort a  = (ushort)((value & 0x0f) << 6);
                this.InstructionCode = (ushort)((this.InstructionCode & 0xfc3f) + ((value & 0x0f) << 6));
            }
        }

    }

    public class OneOpInstrution:Instruction
    {
        public OneOpInstrution() : base()
        {

        }

        public byte Dst
        {
            get
            {
                return (byte)(this[low] & 0x0f);
            }

            set
            {
                this[low] = (byte)((value & 0x0f) + (this[low] & 0xf0));
            }
        }

        public byte MAdst
        {
            get
            {
                return (byte)((this[low] >> 4) & 0x03);
            }

            set
            {
                this[low] = (byte)(((value & 0x3) << 4) + (this[low] & 0xcf));
            }
        }

    }
    
    public class BranchInstruction : Instruction
    {
        public BranchInstruction() : base()
        {

        }

        public byte offset
        {
            get { return this[low]; }
            set { this[low] = value; }
        }
    }

    public class CpuInstruction :Instruction
    {
        public CpuInstruction() : base()
        {

        }
    }

    #endregion
}
