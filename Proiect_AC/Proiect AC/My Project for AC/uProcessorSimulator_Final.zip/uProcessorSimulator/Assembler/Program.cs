﻿//#define Debug
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace Assembler
{
    class Program
    {
        static bool parsingSuccessful = true;
        static void Main(string[] args)
        {
#if Debug
           // debug1();
            //debug2();
            AssembyParser parser = new AssembyParser("debug test.txt");
            parser.Parse();
#endif
            
            string filePath;
            if (args.Any())
            {
                filePath = args[0];
                try
                {
                    AssembyParser Parser = new AssembyParser(filePath);
                    Parser.Parse();
                }catch(Exception e)
                {
                    parsingSuccessful = false;
                    Console.WriteLine(e.Message);
                }
            }
            else
            {
                Console.WriteLine("Specify file path: ");
                filePath = Console.ReadLine();
                if (File.Exists(filePath))
                {
                    try
                    {
                        AssembyParser Parser = new AssembyParser(filePath);
                        Parser.Parse();
                    }
                    catch (Exception e)
                    {
                        parsingSuccessful = false;
                        Console.WriteLine(e.Message);
                    }
                }
            }

            if(!File.Exists(filePath))
            {
                Console.WriteLine("File not found or path invalid");
                
            }

            if (parsingSuccessful)
            {
                Console.WriteLine("Parsing was successful\n" + "file " + Path.GetFileNameWithoutExtension(filePath) + ".bin " +
                    "was generated in the same folder with the .asm" + "\nPress any key to exit");
            }
            else
            {
                Console.WriteLine("error");
            }

            Console.ReadKey();
            
        }
#if Debug
        static void debug()
        {
            string a = "lbl:    abc 3(r4), 0x9";
            string[] sep = { " ", ",",", ","(",")" };
            string[] reults = a.Split(sep,StringSplitOptions.RemoveEmptyEntries);
            foreach(string s in reults)
            {
                Console.Write(s + "\n");
            }
            string[] r = "6(r5)".Split(sep, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in r)
            {
                Console.Write(s + "\n");
            }
            Console.ReadKey();
        }

        static void debug1()
        {
            string hex = Console.ReadLine();
            int x = Convert.ToInt32(hex, 16);
            SegmentMemory memtest = new SegmentMemory();
            memtest.Add(0xabcd);
            memtest.Add(0x12);
            ushort test = memtest[0];
            test = memtest[2];
            memtest[0] = 0x3456;
            Dictionary<string, int> dic = new Dictionary<string, int>();
            dic.Add("lala", 32);
            //dic.Add("lala",40);
        }

        static void debug2()
        {
            InstructionCodes.CpuInstr.ContainsKey("halt");
        }
#endif
    }
}
