﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.Tools
{
    using uProcessorSimulator.CpuModel;
    public partial class uInstrEditorComp : UserControl
    {
        string sbus;
        string dbus;
        string rbus;
        string alu;
        string other;
        string mem;
        string ifjmp;
        byte? uadr;

        public uInstrEditorComp()
        {
            InitializeComponent();
            this.Sbus.DataSource = Enum.GetValues(typeof(SbusSrc));
            this.Dbus.DataSource = Enum.GetValues(typeof(DbusSrc));
            this.Alu.DataSource = Enum.GetValues(typeof(AluOP));
            this.Rbus.DataSource = Enum.GetValues(typeof(RbusDst));
            this.Other.DataSource = Enum.GetValues(typeof(Other));
            this.Mem.DataSource = Enum.GetValues(typeof(Mem));
            this.Ifjmp.DataSource = Enum.GetValues(typeof(IF_JMP));
            this.uAdr.DataSource = Enum.GetValues(typeof(uADR));
            this.uAdr.SelectedIndexChanged += new System.EventHandler(this.uAdr_SelectedIndexChanged);
            this.IndexLabel.Text = "0";
        }
        public uInstrEditorComp(int index)
        {
            InitializeComponent();
            this.Sbus.DataSource = Enum.GetValues(typeof(SbusSrc));
            this.Dbus.DataSource = Enum.GetValues(typeof(DbusSrc));
            this.Alu.DataSource = Enum.GetValues(typeof(AluOP));
            this.Rbus.DataSource = Enum.GetValues(typeof(RbusDst));
            this.Other.DataSource = Enum.GetValues(typeof(Other));
            this.Mem.DataSource = Enum.GetValues(typeof(Mem));
            this.Ifjmp.DataSource = Enum.GetValues(typeof(IF_JMP));
            this.uAdr.DataSource = Enum.GetValues(typeof(uADR));
            this.uAdr.SelectedIndexChanged += new System.EventHandler(this.uAdr_SelectedIndexChanged);
            this.IndexLabel.Text = index.ToString("X");
        }

        public void init(string line)
        {
            string[] fields = line.Split(new string[] { ", ",": "},StringSplitOptions.RemoveEmptyEntries);
            int k = 0;
            if(fields.Length > 8)
            {
                this.Label.Text = fields[k++];
            }
            try { this.Sbus.SelectedItem = (SbusSrc)Enum.Parse(typeof(SbusSrc),fields[k++]);  } catch (Exception) {; }
            try { this.Dbus.SelectedItem = (DbusSrc)Enum.Parse(typeof(DbusSrc), fields[k++]); } catch (Exception) {; }
            try { this.Alu.SelectedItem = (AluOP)Enum.Parse(typeof(AluOP), fields[k++]); } catch (Exception) {; }
            try { this.Rbus.SelectedItem = (RbusDst)Enum.Parse(typeof(RbusDst), fields[k++]); } catch (Exception) {; }
            try { this.Other.SelectedItem = (Other)Enum.Parse(typeof(Other), fields[k++]); } catch (Exception) {; }
            try { this.Mem.SelectedItem = (Mem)Enum.Parse(typeof(Mem), fields[k++]); } catch (Exception) {; }
            try { this.Ifjmp.SelectedItem = (IF_JMP)Enum.Parse(typeof(IF_JMP), fields[k++]); } catch (Exception) {; }
            try { this.uAdr.SelectedItem = (uADR)Enum.Parse(typeof(uADR), fields[k]);  }
            catch (Exception) {this.uAdr.Text = fields[k]; }
        }

        public string GetuInstr()
        {
            string ret = "";
            if (sbus.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (dbus.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (alu.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (rbus.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (other.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (mem.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (ifjmp.Any()) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            if (uadr==null) { ret += sbus + ", "; }
            else { throw new Exception("null field"); }

            return ret;
        }

        private void Sbus_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Sbus.Text = this.Sbus.SelectedItem.ToString();
            
        }

        private void Dbus_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Dbus.Text = this.Dbus.SelectedItem.ToString();
        }

        private void Alu_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Alu.Text = this.Alu.SelectedItem.ToString();
        }

        private void Rbus_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Rbus.Text = this.Rbus.SelectedItem.ToString();
        }

        private void Other_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Other.Text = this.Other.SelectedItem.ToString();
        }

        private void Mem_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Mem.Text = this.Mem.SelectedItem.ToString();
        }

        private void Ifjmp_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Ifjmp.Text = this.Ifjmp.SelectedItem.ToString();
        }

        private void uAdr_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.uadr = Convert.ToByte(this.uAdr.Text, 16);
            }
            catch (FormatException)
            {
                MessageBox.Show("please give a number in Hex");
            }
        }


    }
}
