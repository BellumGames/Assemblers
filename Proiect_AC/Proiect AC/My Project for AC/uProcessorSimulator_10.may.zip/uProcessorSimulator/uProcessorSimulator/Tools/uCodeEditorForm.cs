﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.Tools
{
    public partial class uCodeEditorForm : Form
    {
        private const  int max=128;
        uInstrEditorComp[] uInstr = new uInstrEditorComp[max];

        public uCodeEditorForm()
        {
            InitializeComponent();
        }

        private void uCodeEditorForm_Load(object sender, EventArgs e)
        {
            this.tableLayout.RowCount = this.uInstr.Length;
            for (int index = 0; index < 15/*this.uInstr.Length*/; index++)
            {
                this.uInstr[index] = new uInstrEditorComp(index);
                this.tableLayout.Controls.Add(this.uInstr[index], 0, index);
                this.tableLayout.RowCount += 1;
            }

        }

        public void generate_file(string path)
        {

        }

    }
}
