﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.Controller
{
    using uProcessorSimulator.CpuModel;
    class CpuController
    {
        CpuModel cpuModel;
        UPSimView simView;

        public CpuController(CpuModel cpuModel, UPSimView simView)
        {
            this.cpuModel = cpuModel;
            this.simView = simView;
        }
    }
}
