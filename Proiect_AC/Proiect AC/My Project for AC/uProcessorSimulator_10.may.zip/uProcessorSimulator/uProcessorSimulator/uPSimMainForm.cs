﻿#define debug
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator
{
    using uProcessorSimulator.CpuModel;
    public partial class UPSimView : Form
    {

        public UPSimView()
        {
            InitializeComponent();
        }

        private void MainFrom_Load(object sender, EventArgs e)
        {
#if debug
            debug();
#endif
        }

        private void debug()
        {
            CpuModel.CpuModel cpu = new CpuModel.CpuModel();
            cpu.SUB();
            (new uProcessorSimulator.Tools.uCodeEditorForm()).ShowDialog();
        }
    }
}
