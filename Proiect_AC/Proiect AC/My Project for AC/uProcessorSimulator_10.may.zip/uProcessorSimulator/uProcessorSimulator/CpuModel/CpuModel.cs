﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.CpuModel
{
    class CpuModel
    {
        public CpuModel()
        {

        }

        #region cpu fields
        ushort[] regs = new ushort[16];
        ushort pc = 0, sp = 0, ir = 0, adr = 0, mdr = 0, ivr = 0, flags = 0, t = 0;
        ushort sbus = 0, dbus = 0, rbus = 0;
        private const ushort CflagMask = 0x08;
        private const ushort SflagMask = 0x01;
        private ushort ZflagMask = 0x02;
        private ushort VflagMAsk = 0x04;
        private ushort aluFlags;
        #endregion
        
        #region properties
        public ushort[] Regs
        {
            get
            {
                return regs;
            }
        }

        public ushort Pc
        {
            get
            {
                return pc;
            }
        }

        public ushort Sp
        {
            get
            {
                return sp;
            }
        }

        public ushort Ir
        {
            get
            {
                return ir;
            }
        }

        public ushort Adr
        {
            get
            {
                return adr;
            }
        }

        public ushort Mdr
        {
            get
            {
                return mdr;
            }
        }

        public ushort Ivr
        {
            get
            {
                return ivr;
            }
        }

        public ushort Flags
        {
            get
            {
                return flags;
            }

        }

        public ushort T
        {
            get
            {
                return t;
            }
        }

        public ushort Sbus
        {
            get
            {
                return sbus;
            }
        }

        public ushort Dbus
        {
            get
            {
                return dbus;
            }
        }

        public ushort Rbus
        {
            get
            {
                return rbus;
            }

            set
            {
                rbus = value;
            }
        }
        #endregion

        #region comands
        
        #region Sbus
                public void issRegs_Sbus(int index) {
                    this.sbus = this.Regs[index];
                }
                public void issSP_Sbus() { this.sbus = this.sp; }
                public void issT_Sbus() { this.sbus = this.t; }
                public void issPC_Sbus() { this.sbus = this.pc; }
                public void issIVR_Sbus() { this.sbus = this.ivr; }
                public void issADR_Sbus() { this.sbus = this.adr; }
                public void issMDR_Sbus() { this.sbus = this.mdr; }
                public void issIR_Sbus() { this.sbus = this.ir; }
                public void issFlag_Sbus() { this.sbus = flags; }
                public void issZERO_Sbus() { this.sbus = 0; }
                public void issONE_Sbus() { this.sbus = 1; }

        #endregion
        
        #region Dbus
        public void issRegs_Dbus(int index)
        {
            this.dbus = this.regs[index];
        }
        public void issSP_Dbus() { this.dbus = this.sp; }
        public void issT_Dbus() { this.dbus = this.t; }
        public void issPC_Dbus() { this.dbus = this.pc; }
        public void issIVR_Dbus() { this.dbus = this.ivr; }
        public void issADR_Dbus() { this.dbus = this.adr; }
        public void issMDR_Dbus() { this.dbus = this.mdr; }
        public void issIR_Dbus() { this.dbus = this.ir; }
        public void issFlag_Dbus() { this.dbus = flags; }
        public void issZERO_Dbus() { this.dbus = 0; }
        public void issONE_Dbus() { this.dbus = 1; }
        #endregion

        #region Alu
        public void SUM()
        {
            try
            {
                checked{ this.rbus = (ushort)(this.sbus + this.dbus); }
            }
            catch (OverflowException)
            {
                unchecked{ this.rbus = this.rbus = (ushort)(this.sbus + this.dbus); }
            }
            finally { /*set aluflags*/}
        }
        public void SUB()
        {
            try
            {
                checked { this.rbus = (ushort)(this.sbus + this.dbus + 1); }
            }
            catch (OverflowException)
            {
                unchecked{ this.rbus = (ushort)(this.sbus + this.dbus + 1); }
            }
            finally { /*set aluflags*/}
        }
        public void SBUS()
        {
            this.rbus = this.sbus;
        }
        public void nSBUS()
        {
            this.rbus = (ushort)(~this.sbus);
        }
        public void DBUS()
        {
            this.rbus = this.dbus;
        }
        public void nDbus()
        {
            this.rbus = (ushort)(~this.dbus);
        }
        public void AND()
        {
            this.rbus = (ushort)(this.sbus & this.dbus);
        }
        public void OR()
        {
            this.rbus = (ushort)(this.sbus | this.dbus);
        }
        public void XOR()
        {
            this.rbus = (ushort)(this.sbus ^ this.dbus);
        }
        #endregion

        #region Rbus
        #endregion

        #region Other
        #endregion

        #region Mem
        #endregion

        #region Flags
        public bool C()
        {
            if((CflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool S()
        {
            if((SflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Z()
        {
            if((ZflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool V()
        {
            if((VflagMAsk & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

#endregion

#endregion


#region methods
#endregion
    }
}
