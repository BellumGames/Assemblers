﻿namespace uProcessorSimulator.ViewComponents
{
    partial class cpuSchema
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.IVR = new uProcessorSimulator.ViewComponents.RegComp();
            this.Flag = new uProcessorSimulator.ViewComponents.RegComp();
            this.T = new uProcessorSimulator.ViewComponents.RegComp();
            this.SP = new uProcessorSimulator.ViewComponents.RegComp();
            this.PC = new uProcessorSimulator.ViewComponents.RegComp();
            this.IR = new uProcessorSimulator.ViewComponents.RegComp();
            this.ADR = new uProcessorSimulator.ViewComponents.RegComp();
            this.MDR = new uProcessorSimulator.ViewComponents.RegComp();
            this.R15 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R14 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R13 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R12 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R11 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R10 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R9 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R8 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R7 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R6 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R5 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R4 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R3 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R2 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R1 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R0 = new uProcessorSimulator.ViewComponents.RegComp();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.DBUS = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::uProcessorSimulator.Properties.Resources.Alu;
            this.pictureBox1.Location = new System.Drawing.Point(269, 299);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 119);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // IVR
            // 
            this.IVR.HexView = false;
            this.IVR.Location = new System.Drawing.Point(269, 193);
            this.IVR.Margin = new System.Windows.Forms.Padding(0);
            this.IVR.Name = "IVR";
            this.IVR.NameReg = "IVR";
            this.IVR.Size = new System.Drawing.Size(165, 15);
            this.IVR.TabIndex = 23;
            this.IVR.Value = ((ushort)(0));
            // 
            // Flag
            // 
            this.Flag.HexView = false;
            this.Flag.Location = new System.Drawing.Point(269, 223);
            this.Flag.Margin = new System.Windows.Forms.Padding(0);
            this.Flag.Name = "Flag";
            this.Flag.NameReg = "Flag";
            this.Flag.Size = new System.Drawing.Size(165, 15);
            this.Flag.TabIndex = 22;
            this.Flag.Value = ((ushort)(0));
            // 
            // T
            // 
            this.T.HexView = false;
            this.T.Location = new System.Drawing.Point(269, 163);
            this.T.Margin = new System.Windows.Forms.Padding(0);
            this.T.Name = "T";
            this.T.NameReg = "T";
            this.T.Size = new System.Drawing.Size(165, 15);
            this.T.TabIndex = 21;
            this.T.Value = ((ushort)(0));
            // 
            // SP
            // 
            this.SP.HexView = false;
            this.SP.Location = new System.Drawing.Point(269, 133);
            this.SP.Margin = new System.Windows.Forms.Padding(0);
            this.SP.Name = "SP";
            this.SP.NameReg = "SP";
            this.SP.Size = new System.Drawing.Size(165, 15);
            this.SP.TabIndex = 20;
            this.SP.Value = ((ushort)(0));
            // 
            // PC
            // 
            this.PC.HexView = false;
            this.PC.Location = new System.Drawing.Point(269, 103);
            this.PC.Margin = new System.Windows.Forms.Padding(0);
            this.PC.Name = "PC";
            this.PC.NameReg = "PC";
            this.PC.Size = new System.Drawing.Size(165, 15);
            this.PC.TabIndex = 19;
            this.PC.Value = ((ushort)(0));
            // 
            // IR
            // 
            this.IR.HexView = false;
            this.IR.Location = new System.Drawing.Point(610, 103);
            this.IR.Margin = new System.Windows.Forms.Padding(0);
            this.IR.Name = "IR";
            this.IR.NameReg = "IR";
            this.IR.Size = new System.Drawing.Size(165, 15);
            this.IR.TabIndex = 18;
            this.IR.Value = ((ushort)(0));
            // 
            // ADR
            // 
            this.ADR.HexView = false;
            this.ADR.Location = new System.Drawing.Point(610, 133);
            this.ADR.Margin = new System.Windows.Forms.Padding(0);
            this.ADR.Name = "ADR";
            this.ADR.NameReg = "ADR";
            this.ADR.Size = new System.Drawing.Size(165, 15);
            this.ADR.TabIndex = 17;
            this.ADR.Value = ((ushort)(0));
            // 
            // MDR
            // 
            this.MDR.HexView = false;
            this.MDR.Location = new System.Drawing.Point(610, 163);
            this.MDR.Margin = new System.Windows.Forms.Padding(0);
            this.MDR.Name = "MDR";
            this.MDR.NameReg = "MDR";
            this.MDR.Size = new System.Drawing.Size(165, 15);
            this.MDR.TabIndex = 16;
            this.MDR.Value = ((ushort)(0));
            // 
            // R15
            // 
            this.R15.HexView = false;
            this.R15.Location = new System.Drawing.Point(610, 418);
            this.R15.Margin = new System.Windows.Forms.Padding(0);
            this.R15.Name = "R15";
            this.R15.NameReg = "R15";
            this.R15.Size = new System.Drawing.Size(165, 15);
            this.R15.TabIndex = 15;
            this.R15.Value = ((ushort)(0));
            // 
            // R14
            // 
            this.R14.HexView = false;
            this.R14.Location = new System.Drawing.Point(610, 403);
            this.R14.Margin = new System.Windows.Forms.Padding(0);
            this.R14.Name = "R14";
            this.R14.NameReg = "R14";
            this.R14.Size = new System.Drawing.Size(165, 15);
            this.R14.TabIndex = 14;
            this.R14.Value = ((ushort)(0));
            // 
            // R13
            // 
            this.R13.HexView = false;
            this.R13.Location = new System.Drawing.Point(610, 388);
            this.R13.Margin = new System.Windows.Forms.Padding(0);
            this.R13.Name = "R13";
            this.R13.NameReg = "R13";
            this.R13.Size = new System.Drawing.Size(165, 15);
            this.R13.TabIndex = 13;
            this.R13.Value = ((ushort)(0));
            // 
            // R12
            // 
            this.R12.HexView = false;
            this.R12.Location = new System.Drawing.Point(610, 373);
            this.R12.Margin = new System.Windows.Forms.Padding(0);
            this.R12.Name = "R12";
            this.R12.NameReg = "R12";
            this.R12.Size = new System.Drawing.Size(165, 15);
            this.R12.TabIndex = 12;
            this.R12.Value = ((ushort)(0));
            // 
            // R11
            // 
            this.R11.HexView = false;
            this.R11.Location = new System.Drawing.Point(610, 358);
            this.R11.Margin = new System.Windows.Forms.Padding(0);
            this.R11.Name = "R11";
            this.R11.NameReg = "R11";
            this.R11.Size = new System.Drawing.Size(165, 15);
            this.R11.TabIndex = 11;
            this.R11.Value = ((ushort)(0));
            // 
            // R10
            // 
            this.R10.HexView = false;
            this.R10.Location = new System.Drawing.Point(610, 343);
            this.R10.Margin = new System.Windows.Forms.Padding(0);
            this.R10.Name = "R10";
            this.R10.NameReg = "R10";
            this.R10.Size = new System.Drawing.Size(165, 15);
            this.R10.TabIndex = 10;
            this.R10.Value = ((ushort)(0));
            // 
            // R9
            // 
            this.R9.HexView = false;
            this.R9.Location = new System.Drawing.Point(610, 328);
            this.R9.Margin = new System.Windows.Forms.Padding(0);
            this.R9.Name = "R9";
            this.R9.NameReg = "R9";
            this.R9.Size = new System.Drawing.Size(165, 15);
            this.R9.TabIndex = 9;
            this.R9.Value = ((ushort)(0));
            // 
            // R8
            // 
            this.R8.HexView = false;
            this.R8.Location = new System.Drawing.Point(610, 313);
            this.R8.Margin = new System.Windows.Forms.Padding(0);
            this.R8.Name = "R8";
            this.R8.NameReg = "R8";
            this.R8.Size = new System.Drawing.Size(165, 15);
            this.R8.TabIndex = 8;
            this.R8.Value = ((ushort)(0));
            // 
            // R7
            // 
            this.R7.HexView = false;
            this.R7.Location = new System.Drawing.Point(610, 298);
            this.R7.Margin = new System.Windows.Forms.Padding(0);
            this.R7.Name = "R7";
            this.R7.NameReg = "R7";
            this.R7.Size = new System.Drawing.Size(165, 15);
            this.R7.TabIndex = 7;
            this.R7.Value = ((ushort)(0));
            // 
            // R6
            // 
            this.R6.HexView = false;
            this.R6.Location = new System.Drawing.Point(610, 283);
            this.R6.Margin = new System.Windows.Forms.Padding(0);
            this.R6.Name = "R6";
            this.R6.NameReg = "R6";
            this.R6.Size = new System.Drawing.Size(165, 15);
            this.R6.TabIndex = 6;
            this.R6.Value = ((ushort)(0));
            // 
            // R5
            // 
            this.R5.HexView = false;
            this.R5.Location = new System.Drawing.Point(610, 268);
            this.R5.Margin = new System.Windows.Forms.Padding(0);
            this.R5.Name = "R5";
            this.R5.NameReg = "R5";
            this.R5.Size = new System.Drawing.Size(165, 15);
            this.R5.TabIndex = 5;
            this.R5.Value = ((ushort)(0));
            // 
            // R4
            // 
            this.R4.HexView = false;
            this.R4.Location = new System.Drawing.Point(610, 253);
            this.R4.Margin = new System.Windows.Forms.Padding(0);
            this.R4.Name = "R4";
            this.R4.NameReg = "R4";
            this.R4.Size = new System.Drawing.Size(165, 15);
            this.R4.TabIndex = 4;
            this.R4.Value = ((ushort)(0));
            // 
            // R3
            // 
            this.R3.HexView = false;
            this.R3.Location = new System.Drawing.Point(610, 238);
            this.R3.Margin = new System.Windows.Forms.Padding(0);
            this.R3.Name = "R3";
            this.R3.NameReg = "R3";
            this.R3.Size = new System.Drawing.Size(165, 15);
            this.R3.TabIndex = 3;
            this.R3.Value = ((ushort)(0));
            // 
            // R2
            // 
            this.R2.HexView = false;
            this.R2.Location = new System.Drawing.Point(610, 223);
            this.R2.Margin = new System.Windows.Forms.Padding(0);
            this.R2.Name = "R2";
            this.R2.NameReg = "R2";
            this.R2.Size = new System.Drawing.Size(165, 15);
            this.R2.TabIndex = 2;
            this.R2.Value = ((ushort)(0));
            // 
            // R1
            // 
            this.R1.HexView = false;
            this.R1.Location = new System.Drawing.Point(610, 208);
            this.R1.Margin = new System.Windows.Forms.Padding(0);
            this.R1.Name = "R1";
            this.R1.NameReg = "R1";
            this.R1.Size = new System.Drawing.Size(165, 15);
            this.R1.TabIndex = 1;
            this.R1.Value = ((ushort)(0));
            // 
            // R0
            // 
            this.R0.HexView = false;
            this.R0.Location = new System.Drawing.Point(610, 193);
            this.R0.Margin = new System.Windows.Forms.Padding(0);
            this.R0.Name = "R0";
            this.R0.NameReg = "R0";
            this.R0.Size = new System.Drawing.Size(165, 15);
            this.R0.TabIndex = 0;
            this.R0.Value = ((ushort)(0));
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape1,
            this.DBUS});
            this.shapeContainer1.Size = new System.Drawing.Size(1042, 623);
            this.shapeContainer1.TabIndex = 25;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.rectangleShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape1.Location = new System.Drawing.Point(542, 85);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(15, 370);
            // 
            // DBUS
            // 
            this.DBUS.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.DBUS.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.DBUS.Location = new System.Drawing.Point(485, 85);
            this.DBUS.Name = "DBUS";
            this.DBUS.Size = new System.Drawing.Size(15, 370);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(482, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "DBUS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(545, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "SBUS";
            // 
            // cpuSchema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.IVR);
            this.Controls.Add(this.Flag);
            this.Controls.Add(this.T);
            this.Controls.Add(this.SP);
            this.Controls.Add(this.PC);
            this.Controls.Add(this.IR);
            this.Controls.Add(this.ADR);
            this.Controls.Add(this.MDR);
            this.Controls.Add(this.R15);
            this.Controls.Add(this.R14);
            this.Controls.Add(this.R13);
            this.Controls.Add(this.R12);
            this.Controls.Add(this.R11);
            this.Controls.Add(this.R10);
            this.Controls.Add(this.R9);
            this.Controls.Add(this.R8);
            this.Controls.Add(this.R7);
            this.Controls.Add(this.R6);
            this.Controls.Add(this.R5);
            this.Controls.Add(this.R4);
            this.Controls.Add(this.R3);
            this.Controls.Add(this.R2);
            this.Controls.Add(this.R1);
            this.Controls.Add(this.R0);
            this.Controls.Add(this.shapeContainer1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "cpuSchema";
            this.Size = new System.Drawing.Size(1042, 623);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RegComp R0;
        private RegComp R1;
        private RegComp R2;
        private RegComp R3;
        private RegComp R4;
        private RegComp R5;
        private RegComp R6;
        private RegComp R7;
        private RegComp R8;
        private RegComp R9;
        private RegComp R10;
        private RegComp R11;
        private RegComp R12;
        private RegComp R13;
        private RegComp R14;
        private RegComp R15;
        private RegComp MDR;
        private RegComp ADR;
        private RegComp IR;
        private RegComp PC;
        private RegComp SP;
        private RegComp T;
        private RegComp Flag;
        private RegComp IVR;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape DBUS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
