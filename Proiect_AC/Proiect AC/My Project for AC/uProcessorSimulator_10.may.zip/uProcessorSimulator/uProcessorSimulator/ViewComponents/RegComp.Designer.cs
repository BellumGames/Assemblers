﻿namespace uProcessorSimulator.ViewComponents
{
    partial class RegComp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegName = new System.Windows.Forms.Label();
            this.RegValue = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // RegName
            // 
            this.RegName.AutoSize = true;
            this.RegName.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.RegName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RegName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegName.Location = new System.Drawing.Point(0, 0);
            this.RegName.MaximumSize = new System.Drawing.Size(45, 15);
            this.RegName.MinimumSize = new System.Drawing.Size(45, 15);
            this.RegName.Name = "RegName";
            this.RegName.Size = new System.Drawing.Size(45, 15);
            this.RegName.TabIndex = 0;
            this.RegName.Text = "R";
            this.RegName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RegValue
            // 
            this.RegValue.AutoSize = true;
            this.RegValue.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.RegValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RegValue.Location = new System.Drawing.Point(45, 0);
            this.RegValue.MaximumSize = new System.Drawing.Size(120, 15);
            this.RegValue.MinimumSize = new System.Drawing.Size(120, 15);
            this.RegValue.Name = "RegValue";
            this.RegValue.Size = new System.Drawing.Size(120, 15);
            this.RegValue.TabIndex = 1;
            this.RegValue.Text = "0000000000000000";
            this.RegValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RegValue.UseMnemonic = false;
            // 
            // RegComp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.RegValue);
            this.Controls.Add(this.RegName);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "RegComp";
            this.Size = new System.Drawing.Size(165, 15);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label RegName;
        private System.Windows.Forms.Label RegValue;
    }
}
