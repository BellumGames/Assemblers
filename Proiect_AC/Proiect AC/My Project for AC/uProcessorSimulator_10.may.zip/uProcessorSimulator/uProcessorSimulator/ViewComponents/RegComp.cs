﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.ViewComponents
{
    public partial class RegComp : UserControl
    {
        public RegComp()
        {
            InitializeComponent();
        }
        #region const
        Color active = SystemColors.Highlight;
        Color normal = SystemColors.ActiveCaption;
        #endregion

        #region fields
        private ushort _value;
        public bool _hexView;
        #endregion

        #region properties
        /// <summary>
        /// reprezentation of the register value in hex
        /// </summary>
        public bool HexView
        {
            set
            {
                this._hexView = value;
                this.DisplayValue(this._value);
            }
            get { return this._hexView; }
        }

        public ushort Value
        {
            get { return this._value; }
            set
            {
                this._value = value;
                this.DisplayValue(value);
            }
        }
        public string NameReg
        {
            set { this.RegName.Text = value; }
            get { return this.RegName.Text; }
        }
        #endregion

        #region methods
        public void setActive()
        {
            this.RegName.BackColor = this.active;
            this.RegValue.BackColor = this.active;
        }
        public void clearActive()
        {
            this.RegName.BackColor = this.normal;
            this.RegValue.BackColor = this.normal;
        }
        private void DisplayValue(ushort value)
        {
            if (!this._hexView)
            {
                string val = "";
                for (int i = 0; i < 16; i++)
                {
                    val = (0x0001 & value).ToString() + val;
                    value = (ushort)(value >> 1);
                }
                this.RegValue.Text = val;
            }
            else
            {
                this.RegValue.Text = String.Format("{0:x}", value);
            }
        }
        #endregion
    }
}
