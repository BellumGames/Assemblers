﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assembler
{
    class SegmentMemory
    {
        List<byte> MemWords;
        private int _head;
        /// <summary>
        /// gets the offset were about to read
        /// </summary>
        public int CrntOffset
        {
            get { return this._head; }
        }

        public int SegmentSize
        {
            get { return this.MemWords.Count; }
        }

        public SegmentMemory()
        {
            this._head = 0;
            this.MemWords = new List<byte>();
        }
        /// <summary>
        /// adds the bytes from given array high firs then low
        /// </summary>
        /// <param name="word">array of the two bytes of a 16bit word (high=1 and low=0)</param>
        public void Add(byte[] word)
        {
            this.MemWords.Add(word[Const.LOW]);
            this.MemWords.Add(word[Const.HIGH]);
            this._head += 2;
        }
        /// <summary>
        /// adds the given word, high first then low byte
        /// </summary>
        /// <param name="word">16</param>
        public void Add(ushort word)
        {
            this.MemWords.Add((byte)(word >> (8 * Const.LOW)));
            this.MemWords.Add((byte)(word >> (8*Const.HIGH)));
            this._head += 2; 
        }

        /// <summary>
        /// returns the 16bit word from given index and index+1
        /// </summary>
        /// <param name="index">index of the high byte of word</param>
        /// <returns></returns>
        public ushort this[int index]
        {
            get {
                    return (ushort)((ushort)(this.MemWords[index])
                    + (ushort)(this.MemWords[index + 1] << 8));
                }
            set {
                    this.MemWords[index] = (byte)(value);
                    this.MemWords[index + 1] = (byte)(value >> 8);
                }
        }

        /// <summary>
        /// writes the byte pointetd by index
        /// </summary>
        /// <param name="index">index of byte to modify</param>
        public void InsertByteToAddress(int index, byte value)
        {
            this.MemWords[index] = value;
        }
    }
}
