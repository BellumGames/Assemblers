﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assembler
{
    class Label
    {
        /// <summary>
        /// label's name
        /// </summary>
        public string LabelName;
        /// <summary>
        /// address of the label (high byte in memory)
        /// </summary>
        public int offset;

        public Label(string name, int offset)
        {
            LabelName = name;
            this.offset = offset;
        }
        /// <summary>
        /// calculates the offset operand for branch, jump, and call instructions
        /// </summary>
        /// <param name="labelAddress">address of label</param>
        /// <returns></returns>
        public ushort computeAdress(ushort labelAddress)
        {
            short Resultoffset = 0;

            //TODO: implement calculation of jump target Address
            //if before the curent IP (instruction pointer) offset is negative
            //else is positive
            Resultoffset = (short)(labelAddress - this.offset);

            return (ushort)Resultoffset;
        }
    }

    class Symbol 
    {
        public string SymbolName = "";
        /// <summary>
        /// address of the symbol (low byte in memory)
        /// </summary>
        public ushort symbolOffset = 0;
        public Symbol()
        {

        }

        public bool Equals(string str)
        {
            return this.SymbolName.Equals(str);
        }

        /// <summary>
        /// calculates absolute address of the symbol
        /// </summary>
        /// <param name="symbolAddress"></param>
        /// <returns></returns>
        public ushort computeAdress(ushort symbolAddress,ushort dataSegLength = 0)
        {
            short address = 0;

            //TODO: implement calculation of the symbols address
            //the address is relative to Data Segment!!!

            return (ushort)address;
        }

    }
}

