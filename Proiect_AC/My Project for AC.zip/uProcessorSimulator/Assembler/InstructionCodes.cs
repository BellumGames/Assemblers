﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assembler
{
    static class InstructionCodes
    {
        public static readonly Dictionary<string, byte> TwoOpInstr = new Dictionary<string, byte>
            {
                {"MOV"  ,0x01 },
                {"ADD"  ,0x02 },
                {"CMP"  ,0x03 },
                {"AND"  ,0x04 },
                {"OR"   ,0x05 },
                {"XOR"  ,0x06 },
                {"SUB"  ,0x07 }
            };
        public static readonly Dictionary<string, byte> OneOpInstr = new Dictionary<string, byte>
            {
                {"CLR"  ,0xA1 },
                {"NEG"  ,0xA0 },
                {"INC"  ,0xA2 },
                {"DEC"  ,0xA3 },
                {"ASL"  ,0xA4 },
                {"ASR"  ,0xA5 },
                {"CALL" ,0xA6 },
                {"LSR"  ,0xA8 },
                {"ROL"  ,0xA9 },
                {"ROR"  ,0xAA },
                {"RLC"  ,0xAB },
                {"RRC"  ,0xAC },
                {"JMP"  ,0xAD },
                {"PUSH" ,0xAE },
                {"POP"  ,0xAF }
            };
        public static readonly Dictionary<string, byte> BranchInstr = new Dictionary<string, byte>
            {
                {"BR"   ,0x80 },
                {"BNE"  ,0x81 },
                {"BEQ"  ,0x82 },
                {"BPL"  ,0x83 },
                {"BMI"  ,0x84 },
                {"BCS"  ,0x85 },
                {"BCC"  ,0x86 },
                {"BVS"  ,0x87 },
                {"BVc"  ,0x88 }

            };
        public static readonly Dictionary<string, byte> CpuInstr = new Dictionary<string, byte>
            {
                {"CLC"      ,0xC9 },
                {"CLV"      ,0xCA },
                {"CLZ"      ,0xCB },
                {"CLS"      ,0xCC },
                {"CCF"      ,0xCD },
                {"SEC"      ,0xCE },
                {"SEV"      ,0xCF },
                {"SEZ"      ,0xD0 },
                {"SES"      ,0xD1 },
                {"SCF"      ,0xD2 },
                {"NOP"      ,0xD3 },
                {"RET"      ,0xD4 },
                {"IRET"     ,0xDB },
                {"HALT"     ,0xD5 },
                {"WAIT"     ,0xD6 },
                {"PUSHPC"   ,0xD7 },
                {"POPPC"    ,0xD8 },
                {"PUSHF"    ,0xD9 },
                {"POPF"     ,0xDA },
            };
        
    }

    enum AddressingMode
    {
        MA = (byte)0x00,
        MD = (byte)0x01,
        MI = (byte)0x02,
        MX = (byte)0x03
    }
}
