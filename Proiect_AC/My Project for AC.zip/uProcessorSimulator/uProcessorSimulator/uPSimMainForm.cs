﻿#define debug
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator
{
    //using uProcessorSimulator.CpuModel;
    using uProcessorSimulator.ViewComponents;
    using uProcessorSimulator.View;
    using uProcessorSimulator.Controller;
    using Assembler;
    using System.IO;
    public partial class UPSimView : Form
    {
        public delegate void CpuSchemaVoidDel();
        public delegate void CpuSchemaStringDel(string op);
        public delegate void CpuSchemaIntDel(int index);

        #region delegates
        public CpuSchemaVoidDel issIR_s;
        public CpuSchemaVoidDel issIR_d;
        public CpuSchemaVoidDel ldIR;

        public SetRegDelegate[] setReg;

        public CpuSchemaVoidDel issMDR_s;
        public CpuSchemaVoidDel issMDR_d;
        public CpuSchemaVoidDel ldMDR;

        public CpuSchemaVoidDel issADR_s;
        public CpuSchemaVoidDel issADR_d;
        public CpuSchemaVoidDel ldADR;

        public CpuSchemaVoidDel issReg_s;
        public CpuSchemaVoidDel issReg_d;
        public CpuSchemaVoidDel ldReg;

        public CpuSchemaVoidDel issPC_s;
        public CpuSchemaVoidDel issPC_d;
        public CpuSchemaVoidDel ldPC;

        public CpuSchemaVoidDel issSP_s;
        public CpuSchemaVoidDel issSP_d;
        public CpuSchemaVoidDel ldSP;

        public CpuSchemaVoidDel issT_s;
        public CpuSchemaVoidDel issT_d;
        public CpuSchemaVoidDel ldT;

        public CpuSchemaVoidDel issIVR_s;
        public CpuSchemaVoidDel issIVR_d;
        public CpuSchemaVoidDel ldIVR;

        public CpuSchemaVoidDel issFlag_s;
        public CpuSchemaVoidDel issFlag_d;
        public CpuSchemaVoidDel ldFlag;

        public SetRegDelegate setIR;
        public SetRegDelegate setMDR;
        public SetRegDelegate setADR;
        public SetRegDelegate setPC;
        public SetRegDelegate setSP;
        public SetRegDelegate setT;
        public SetRegDelegate setFlag;
        public CpuSchemaStringDel setAluOp;
        public CpuSchemaStringDel setMemOp;

        public CpuSchemaVoidDel activate_IR;
        public CpuSchemaVoidDel activate_MDR;
        public CpuSchemaVoidDel activate_ADR;
        public CpuSchemaIntDel activate_Reg;
        public CpuSchemaVoidDel activate_PC;
        public CpuSchemaVoidDel activate_SP;
        public CpuSchemaVoidDel activate_T;
        public CpuSchemaVoidDel activate_IVR;
        public CpuSchemaVoidDel activate_Flag;
        #endregion

        #region fields
        CpuController ctrl;
        ProgramMemoryController memCtrl;
        MicroMemoryController uMemCtrl;

        MicroMemoryView uMemView;
        ProgramMemoryView memView;
        #endregion

        public UPSimView()
        {
            InitializeComponent();
            this.initDelegates();

            this.uMemView = new MicroMemoryView();
            this.memView = new ProgramMemoryView();

            this.ctrl = new CpuController(this);
            this.memCtrl = new ProgramMemoryController(this.ctrl,this.memView);
            this.uMemCtrl = new MicroMemoryController(this.uMemView);
            this.openFileDialog.InitialDirectory = Environment.CurrentDirectory;
        }

        private void MainFrom_Load(object sender, EventArgs e)
        {
#if debug
            debug();
#endif
        }

        private void debug()
        {
            //CpuModel.CpuModel cpu = new CpuModel.CpuModel();
            //cpu.SUB();
            
            
        }

        #region Methods
        
        #endregion

        #region CpuSchema Methods
        void initDelegates()
        {
            this.setIR = cpuSchema.setIR;
            this.setIR = cpuSchema.setMDR;
            this.setIR = cpuSchema.setADR;
            this.setReg = cpuSchema.Reg;
            this.setIR = cpuSchema.setPC;
            this.setIR = cpuSchema.setSP;
            this.setIR = cpuSchema.setT;
            this.setIR = cpuSchema.setIVR;
            this.setIR = cpuSchema.setFlag;
            this.setAluOp = cpuSchema.setAluOp;
            this.setMemOp = cpuSchema.memOperation;

            this.issIR_s = cpuSchema.issIR_sbus;
            this.issIR_d = cpuSchema.issIR_dbus;
            this.ldIR = cpuSchema.ld_IR;

            this.issMDR_s = cpuSchema.issMDR_sbus;
            this.issMDR_d = cpuSchema.issMDR_dbus;
            this.ldMDR = cpuSchema.ld_MDR;

            this.issADR_s = cpuSchema.issADR_sbus;
            this.issADR_d = cpuSchema.issADR_dbus;
            this.ldADR = cpuSchema.ld_ADR;

            this.issReg_s = cpuSchema.issREG_sbus;
            this.issReg_d = cpuSchema.issREG_dbus;
            this.ldReg = cpuSchema.ld_REG;

            this.issPC_s = cpuSchema.issPC_sbus;
            this.issPC_d = cpuSchema.issPC_dbus;
            this.ldPC = cpuSchema.ld_PC;

            this.issSP_s = cpuSchema.issSP_sbus;
            this.issSP_d = cpuSchema.issSP_dbus;
            this.ldSP = cpuSchema.ld_SP;

            this.issT_s = cpuSchema.issT_sbus;
            this.issT_d = cpuSchema.issT_dbus;
            this.ldT = cpuSchema.ld_T;

            this.issIVR_s = cpuSchema.issIVR_sbus;
            this.issIVR_d = cpuSchema.issIVR_dbus;
            this.ldIVR = cpuSchema.ld_IVR;

            this.issFlag_s = cpuSchema.issFlag_sbus;
            this.issFlag_d = cpuSchema.issFlag_dbus;
            this.ldFlag = cpuSchema.ld_Flag;

            this.activate_IR = cpuSchema.activateIR;
            this.activate_MDR = cpuSchema.activateMDR;
            this.activate_ADR = cpuSchema.activateADR;
            this.activate_Reg = cpuSchema.activateReg;
            this.activate_PC = cpuSchema.activatePC;
            this.activate_T = cpuSchema.activateT;
            this.activate_IVR = cpuSchema.activateIVR;
            this.activate_Flag = cpuSchema.activateFlag;
        }
        public void Deactivate_all()
        {
            this.cpuSchema.deactivate_All();
        }
        #endregion//cpuSchemaMethods

        #region events
        private void loadAsmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string asmfilepath = openFileDialog.FileName;
                this.memCtrl.ReadBinaryFile(asmfilepath);
            }
        }

        private void loadUCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string ucodefilepath = openFileDialog.FileName;
                this.uMemCtrl.load_uCodeFile(ucodefilepath);
                //this.readuCode(openFileDialog.FileName);
            }
        }


        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void memoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.memView.Show();
        }

        private void µInstructionMemoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.uMemView.Show();
        }

        private void uCodeEditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            (new uProcessorSimulator.Tools.uCodeEditorForm()).ShowDialog();
        }

        private void stepToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ctrl.Step();
        }

        private void runToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void execSpeed_ValueChanged(object sender, EventArgs e)
        {
            Global.ExecutionSpeed = (int)execSpeed.Value;
        }
        #endregion
    }
}
