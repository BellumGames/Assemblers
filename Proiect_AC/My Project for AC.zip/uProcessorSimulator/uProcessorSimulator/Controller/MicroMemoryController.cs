﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.Controller
{
    using uProcessorSimulator.View;
    using uProcessorSimulator.CpuModel;
    using System.IO;
    class MicroMemoryController
    {
        public delegate void ViewUpdateDel(int index);
        public ViewUpdateDel indexSelect;

        private MicroMemoryView uMemView;

        public MicroMemoryController(MicroMemoryView uMemView)
        {
            this.uMemView = uMemView;

            this.indexSelect = this.selectMicroInstructionInView;
        }

        public void load_uCodeFile(string path)
        {
            StreamReader reader = new StreamReader(path);
            string line;
            List<string> ucode = new List<string>();
            while ((line = reader.ReadLine()) != null)
            {
                ucode.Add(line);
            }
            reader.Close();
            MicroMemory.LoadMicroMemory(ucode);
            this.uMemView.LoadContent(ucode);
        }

        public uInstruction readMicroInstruction(int adr)
        {
            this.indexSelect(adr);
            return MicroMemory.ReadUuInstr(adr);
        }

        private void selectMicroInstructionInView(int index)
        {
            this.uMemView.UpdateSelected(index);
        }
    }
}
