﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.Controller
{
    using System.IO;
    using uProcessorSimulator.CpuModel;
    using uProcessorSimulator.View;
    class ProgramMemoryController
    {
        CpuController cpuCtrl;
        ProgramMemoryView prgView;
        public ProgramMemoryController(CpuController cpuCtrl,ProgramMemoryView prgView)
        {
            this.cpuCtrl = cpuCtrl;
            this.prgView = prgView;
        }
        struct progrmLine
        {
            
        }
        //read the binary file
        //update Memory
        public void ReadBinaryFile(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            BinaryReader binReader = new BinaryReader(fs);
            ushort pc = binReader.ReadUInt16();
            ushort sp = binReader.ReadUInt16();
            this.cpuCtrl.initCpu(pc, sp);
            Global.SpAddress = sp;
            binReader.Close();
            fs.Close();
            //read rest
            Memory.LoadMemory(path);
        }
        
        private void LoadView()
        {
            this.prgView.LoadContent();
        }
    }
}
