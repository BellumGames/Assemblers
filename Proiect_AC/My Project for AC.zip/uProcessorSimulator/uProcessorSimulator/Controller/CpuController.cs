﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.Controller
{
    using uProcessorSimulator.CpuModel;
    class CpuController
    {
        CpuModel cpuModel;
        UPSimView simView;

        public CpuController( UPSimView simView)
        {
            this.cpuModel = new CpuModel();
            this.simView = simView;

        }

        public CpuController(CpuModel cpuModel, UPSimView simView)
        {
            this.cpuModel = cpuModel;
            this.simView = simView;
            
        }

        public void initCpu(ushort pc, ushort sp)
        {
            this.cpuModel.Pc = pc;
            this.cpuModel.Sp = sp;
        }

        internal void Step()
        {
            throw new NotImplementedException();
        }
    }
}
