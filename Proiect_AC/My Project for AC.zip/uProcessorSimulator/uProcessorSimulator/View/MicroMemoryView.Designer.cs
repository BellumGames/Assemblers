﻿namespace uProcessorSimulator.View
{
    partial class MicroMemoryView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataView = new System.Windows.Forms.DataGridView();
            this.addr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sbus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dbus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Alu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rbus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.other = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ifjmp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uadr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataView
            // 
            this.dataView.AllowUserToAddRows = false;
            this.dataView.AllowUserToDeleteRows = false;
            this.dataView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.addr,
            this.label,
            this.Sbus,
            this.Dbus,
            this.Alu,
            this.Rbus,
            this.other,
            this.mem,
            this.ifjmp,
            this.uadr});
            this.dataView.Location = new System.Drawing.Point(12, 12);
            this.dataView.MultiSelect = false;
            this.dataView.Name = "dataView";
            this.dataView.ReadOnly = true;
            this.dataView.Size = new System.Drawing.Size(874, 246);
            this.dataView.TabIndex = 0;
            // 
            // addr
            // 
            this.addr.HeaderText = "addr";
            this.addr.Name = "addr";
            this.addr.ReadOnly = true;
            this.addr.Width = 53;
            // 
            // label
            // 
            this.label.HeaderText = "label";
            this.label.Name = "label";
            this.label.ReadOnly = true;
            this.label.Width = 54;
            // 
            // Sbus
            // 
            this.Sbus.HeaderText = "Sbus Source";
            this.Sbus.Name = "Sbus";
            this.Sbus.ReadOnly = true;
            this.Sbus.Width = 86;
            // 
            // Dbus
            // 
            this.Dbus.HeaderText = "Dbus Source";
            this.Dbus.Name = "Dbus";
            this.Dbus.ReadOnly = true;
            this.Dbus.Width = 87;
            // 
            // Alu
            // 
            this.Alu.HeaderText = "Alu Operation";
            this.Alu.Name = "Alu";
            this.Alu.ReadOnly = true;
            this.Alu.Width = 88;
            // 
            // Rbus
            // 
            this.Rbus.HeaderText = "Rbus Destination";
            this.Rbus.Name = "Rbus";
            this.Rbus.ReadOnly = true;
            this.Rbus.Width = 104;
            // 
            // other
            // 
            this.other.HeaderText = "Other Operation";
            this.other.Name = "other";
            this.other.ReadOnly = true;
            this.other.Width = 98;
            // 
            // mem
            // 
            this.mem.HeaderText = "I/O Operation";
            this.mem.Name = "mem";
            this.mem.ReadOnly = true;
            this.mem.Width = 89;
            // 
            // ifjmp
            // 
            this.ifjmp.HeaderText = "Jump Condition";
            this.ifjmp.Name = "ifjmp";
            this.ifjmp.ReadOnly = true;
            this.ifjmp.Width = 96;
            // 
            // uadr
            // 
            this.uadr.HeaderText = "uAddress";
            this.uadr.Name = "uadr";
            this.uadr.ReadOnly = true;
            this.uadr.Width = 76;
            // 
            // MicroMemoryView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 270);
            this.Controls.Add(this.dataView);
            this.Name = "MicroMemoryView";
            this.Text = "MicroMemoryView";
            this.Load += new System.EventHandler(this.MicroMemoryView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataView;
        private System.Windows.Forms.DataGridViewTextBoxColumn addr;
        private System.Windows.Forms.DataGridViewTextBoxColumn label;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sbus;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dbus;
        private System.Windows.Forms.DataGridViewTextBoxColumn Alu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rbus;
        private System.Windows.Forms.DataGridViewTextBoxColumn other;
        private System.Windows.Forms.DataGridViewTextBoxColumn mem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ifjmp;
        private System.Windows.Forms.DataGridViewTextBoxColumn uadr;
    }
}