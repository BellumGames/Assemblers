﻿namespace uProcessorSimulator.View
{
    partial class ProgramMemoryView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataview = new System.Windows.Forms.DataGridView();
            this.addr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memonic = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataview)).BeginInit();
            this.SuspendLayout();
            // 
            // dataview
            // 
            this.dataview.AllowUserToAddRows = false;
            this.dataview.AllowUserToDeleteRows = false;
            this.dataview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.addr,
            this.hex,
            this.memonic,
            this.bin});
            this.dataview.Location = new System.Drawing.Point(12, 12);
            this.dataview.Name = "dataview";
            this.dataview.ReadOnly = true;
            this.dataview.Size = new System.Drawing.Size(468, 611);
            this.dataview.TabIndex = 0;
            // 
            // addr
            // 
            this.addr.HeaderText = "Address";
            this.addr.Name = "addr";
            this.addr.ReadOnly = true;
            this.addr.Width = 70;
            // 
            // hex
            // 
            this.hex.HeaderText = "Hexcode";
            this.hex.Name = "hex";
            this.hex.ReadOnly = true;
            this.hex.Width = 75;
            // 
            // memonic
            // 
            this.memonic.HeaderText = "Memonic";
            this.memonic.Name = "memonic";
            this.memonic.ReadOnly = true;
            this.memonic.Width = 75;
            // 
            // bin
            // 
            this.bin.HeaderText = "Binary";
            this.bin.Name = "bin";
            this.bin.ReadOnly = true;
            this.bin.Width = 61;
            // 
            // ProgramMemoryView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 635);
            this.Controls.Add(this.dataview);
            this.Name = "ProgramMemoryView";
            this.Text = "ProgramView";
            ((System.ComponentModel.ISupportInitialize)(this.dataview)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataview;
        private System.Windows.Forms.DataGridViewTextBoxColumn addr;
        private System.Windows.Forms.DataGridViewTextBoxColumn hex;
        private System.Windows.Forms.DataGridViewTextBoxColumn memonic;
        private System.Windows.Forms.DataGridViewTextBoxColumn bin;
    }
}