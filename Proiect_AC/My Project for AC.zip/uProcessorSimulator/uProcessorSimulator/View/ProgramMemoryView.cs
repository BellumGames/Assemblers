﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.View
{
    public partial class ProgramMemoryView : Form
    {
        public delegate void UpdateSelectDel(int index);
        public UpdateSelectDel UpdateSelected;
        public ProgramMemoryView()
        {
            InitializeComponent();
            this.UpdateSelected = selectRow;
        }

        internal void LoadContent()
        {
            dataview.Rows.Add();
            dataview.Rows[].Cells[].Value = 
        }

        private void selectRow(int index)
        {
            throw new NotImplementedException();
        }
    }
}
