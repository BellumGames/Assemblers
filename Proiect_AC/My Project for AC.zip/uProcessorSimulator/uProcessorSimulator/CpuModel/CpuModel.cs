﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.CpuModel
{
    class CpuModel
    {
        public CpuModel()
        {

        }

        #region cpu fields
        ushort[] regs = new ushort[16];
        ushort pc = 0, sp = 0, ir = 0, adr = 0, mdr = 0, ivr = 0, flags = 0, t = 0;
        ushort sbus = 0, dbus = 0, rbus = 0;
        private readonly ushort CflagMask = 0x08;
        private readonly ushort SflagMask = 0x01;
        private readonly ushort ZflagMask = 0x02;
        private readonly ushort VflagMask = 0x04;
        private ushort aluFlags;
        private bool intr = false;
        #endregion
        
        #region properties
        public ushort[] Regs
        {
            get
            {
                return regs;
            }
        }

        public ushort Pc
        {
            get{ return pc; }
            set { this.pc = value; }
        }

        public ushort Sp
        {
            get{ return sp; }
            set { this.sp = value; }
        }

        public ushort Ir
        {
            get
            {
                return ir;
            }
        }

        public ushort Adr
        {
            get
            {
                return adr;
            }
        }

        public ushort Mdr
        {
            get
            {
                return mdr;
            }
        }

        public ushort Ivr
        {
            get
            {
                return ivr;
            }
        }

        public ushort Flags
        {
            get
            {
                return flags;
            }

        }

        public ushort T
        {
            get
            {
                return t;
            }
        }

        public ushort Sbus
        {
            get
            {
                return sbus;
            }
        }

        public ushort Dbus
        {
            get
            {
                return dbus;
            }
        }

        public ushort Rbus
        {
            get
            {
                return rbus;
            }

            set
            {
                rbus = value;
            }
        }

        public bool InterruptReq
        {
            set { this.intr = value; }
        }
        #endregion

        #region comands
        
        #region Sbus
                public void issRegs_Sbus(int index) {
                    this.sbus = this.Regs[index];
                }
                public void issSP_Sbus() { this.sbus = this.sp; }
                public void issT_Sbus() { this.sbus = this.t; }
                public void issPC_Sbus() { this.sbus = this.pc; }
                public void issIVR_Sbus() { this.sbus = this.ivr; }
                public void issADR_Sbus() { this.sbus = this.adr; }
                public void issMDR_Sbus() { this.sbus = this.mdr; }
                public void issIR_Sbus() { this.sbus = this.ir; }
                public void issFlag_Sbus() { this.sbus = flags; }
                public void issZERO_Sbus() { this.sbus = 0; }
                public void issONE_Sbus() { this.sbus = 1; }
                public void issmnsOne_Sbus() { this.sbus = 0xffff; }
                public void issNonT_Sbus() { this.sbus = (ushort)(~this.t); }

        #endregion
        
        #region Dbus
        public void issRegs_Dbus(int index)
        {
            this.dbus = this.regs[index];
        }
        public void issSP_Dbus() { this.dbus = this.sp; }
        public void issT_Dbus() { this.dbus = this.t; }
        public void issPC_Dbus() { this.dbus = this.pc; }
        public void issIVR_Dbus() { this.dbus = this.ivr; }
        public void issADR_Dbus() { this.dbus = this.adr; }
        public void issMDR_Dbus() { this.dbus = this.mdr; }
        public void issIR_Dbus() { this.dbus = (ushort)(this.ir&0x00ff); }
        public void issFlag_Dbus() { this.dbus = flags; }
        public void issZERO_Dbus() { this.dbus = 0; }
        public void issONE_Dbus() { this.dbus = 1; }
        public void issmnsONE_Dbus() { this.dbus = 0xffff; }
        public void issNonT_Dbus() { this.dbus = (ushort)(~this.t); }
        #endregion

        #region Alu
        public void SUM()
        {
            try
            {
                checked{ this.rbus = (ushort)(this.sbus + this.dbus); }
            }
            catch (OverflowException)
            {
                unchecked{ this.rbus = this.rbus = (ushort)(this.sbus + this.dbus); }
            }
            finally { this.setAluFlags(); }
        }
        public void SUB()
        {
            try
            {
                checked { this.rbus = (ushort)(this.sbus + this.dbus + 1); }
            }
            catch (OverflowException)
            {
                unchecked{ this.rbus = (ushort)(this.sbus + this.dbus + 1); }
            }
            finally { this.setAluFlags(); }
        }
        public void SBUS()
        {
            this.rbus = this.sbus;
        }
        /*public void nSBUS()
        {
            this.rbus = (ushort)(~this.sbus);
        }*/
        public void DBUS()
        {
            this.rbus = this.dbus;
        }
        public void nDbus()
        {
            this.rbus = (ushort)(~this.dbus);
        }
        public void AND()
        {
            this.rbus = (ushort)(this.sbus & this.dbus);
        }
        public void OR()
        {
            this.rbus = (ushort)(this.sbus | this.dbus);
        }
        public void XOR()
        {
            this.rbus = (ushort)(this.sbus ^ this.dbus);
        }
        public void ASL()
        {
            this.rbus = (ushort)(this.dbus << 1);
        }
        public void ASR()
        {
            //save sign and shift it
            ushort s = (ushort)((this.dbus & 0x8000) >> 1);
            this.rbus = (ushort)((this.dbus >> 1) | s);
        }
        public void LSR()
        {
            this.rbus = (ushort)(this.dbus >> 1);
        }
        public void ROL()
        {
            ushort rot_bit = (ushort)(this.dbus & 0x0001);
            this.rbus = (ushort)((this.dbus>>1) | rot_bit);
        }
        public void ROR()
        {
            ushort rot_bit = (ushort)(this.dbus & 0x8000);
            this.rbus = (ushort)((this.dbus << 1) | rot_bit);
        }
        public void RCL()
        {
            ushort carry = ((ushort)(this.flags & this.CflagMask) == 0) ? (ushort)0 : (ushort)0x0001;
            if ((ushort)(this.dbus & 0x8000) == 0x8000)
            { this.flags |= CflagMask; }
            else
            { this.flags &= (ushort)(~CflagMask); }
            this.dbus = (ushort)(this.dbus << 1);
            this.dbus = (ushort)(this.dbus | carry);
        }
        public void RCR()
        {
            ushort carry = ((ushort)(this.flags & this.CflagMask) == 0) ? (ushort)0 : (ushort)0x8000;
            if ((ushort)(this.dbus & 0x0001) == 1)
            { this.flags |= CflagMask; }
            else
            { this.flags &= (ushort)(~CflagMask); }
            this.dbus = (ushort)(this.dbus >> 1);
            this.dbus = (ushort)(this.dbus | carry);
        }
        #endregion

        #region Rbus
        public void ldRegs(int index)
        {
            this.Regs[index] = this.rbus;
        }
        public void ldSP()
        {
            this.sp = this.rbus;
        }
        public void ldTemp()
        {
            this.t = this.rbus;
        }
        public void ldPC()
        {
            this.pc = this.rbus;
        }
        public void ldIVR()
        {
            this.ivr = this.rbus;
        }
        public void ldADR()
        {
            this.adr = this.rbus;
        }
        public void ldMDR()
        {
            this.adr = this.rbus;
        }
        public void ldIR()
        {
            this.ir = this.rbus;
        }
        public void ldFlag()
        {
            this.flags = this.rbus;
        }
        #endregion

        #region Other
        public void incPC()
        {
            this.pc += 2;
        }
        public void incSP()
        {
            this.sp += 2;
        }
        public void decSP()
        {
            this.sp -= 2;
        }
        public void EnFlg()
        {
            this.flags = aluFlags;
        }
        public void INTA() { this.intr = false; }
        #endregion

        #region Mem
        public void Read()
        {
            this.mdr = Memory.read(this.adr);
        }
        public void Write()
        {
            
        }
        #endregion

        #region Flags
        public bool C()
        {
            if((CflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool S()
        {
            if((SflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Z()
        {
            if((ZflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool V()
        {
            if((VflagMask & Flags) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void setC() { this.flags |= this.CflagMask; }
        public void setS() { this.flags |= this.SflagMask; }
        public void setZ() { this.flags |= this.ZflagMask; }
        public void setV() { this.flags |= this.VflagMask; }

        public void clearC() { this.flags &= (ushort)(~this.CflagMask); }
        public void clearS() { this.flags &= (ushort)(~this.SflagMask); }
        public void clearZ() { this.flags &= (ushort)(~this.ZflagMask); }
        public void clearV() { this.flags &= (ushort)(~this.VflagMask); }

        public void setFlags()
        {
            this.setC();
            this.setS();
            this.setZ();
            this.setV();
        }
        public void clearFlags()
        {
            this.clearC();
            this.clearS();
            this.clearZ();
            this.clearV();
        }
        #endregion

        #endregion


        #region methods
        private void setAluFlags()
        {
            //overflow
            if(((short)this.rbus < 0 && (short)this.sbus >=0 && (short)this.dbus >=0) || 
                ((short)this.rbus >=0 && (short)this.sbus < 0 && (short)this.dbus > 0))
            {
                this.aluFlags |= this.VflagMask;
            }
            else
            {
                this.aluFlags &= (ushort)(~this.VflagMask);
            }
            //carry
            if(this.rbus>>15 == 1)
            {
                this.aluFlags |= this.CflagMask;
            }
            else
            {
                this.aluFlags &= (ushort)(~this.CflagMask);
            }
            //sign
            if ((short)this.rbus < 0)
            {
                this.aluFlags |= this.SflagMask;
            }
            else
            {
                this.aluFlags &= (ushort)(~this.SflagMask);
            }
            //zero
            if (this.rbus == 0)
            {
                this.aluFlags |= this.ZflagMask;
            }
            else
            {
                this.aluFlags &= (ushort)(~this.CflagMask);
            }
        }
        #endregion

    }
}
