﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace uProcessorSimulator.CpuModel
{
    using Assembler;
    static class Memory
    {
        static ushort[] memory;

        public static int MemoryLengthWords
        {
            get { return memory.Length; }
        }

        public static void LoadMemory(string filePath)
        {
            byte[] bytes = File.ReadAllBytes(filePath);
            int k = 0;
            for(int i = 4; i<bytes.Length; i += 2)
            {
                ushort word = (ushort)((ushort)(bytes[i]) + (ushort)(bytes[i + 1] << 8));
                memory[k++] = word;
            }
        }

        public static ushort read(ushort address)
        {
            return memory[address];
        }

        public static Instruction readInstruction(ushort address)
        {
            Instruction i = new Instruction();
            i.InstructionCode = memory[address];
            return i;
        }
        public static void write(ushort address, ushort data)
        {
            memory[address] = data;
        }

        public static List<string> getDecodedCode()
        {
            List<string> code = new List<string>();
            //find way to decode

            return code;
        }
    }
}
