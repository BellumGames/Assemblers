﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uProcessorSimulator.CpuModel
{
    static class MicroMemory
    {
        static uInstruction[] umem;
        static bool allocated = false;

        public static void LoadMicroMemory(List<string> lines)
        {
            int length = lines.Count;
            if (!allocated)
            {
                umem = new uInstruction[length];
                for (int i = 0; i < length; i++)
                {
                    umem[i] = new uInstruction(lines[i]);
                }
                allocated = true;
            }
            else
            {
                if(length != umem.Length) { umem = new uInstruction[length]; }
                for (int i = 0; i < length; i++)
                {
                    umem[i] = new uInstruction(lines[i]);
                }
            }
        }

        public static uInstruction ReadUuInstr(int addr)
        {
            return umem[addr];
        }

    }
}
