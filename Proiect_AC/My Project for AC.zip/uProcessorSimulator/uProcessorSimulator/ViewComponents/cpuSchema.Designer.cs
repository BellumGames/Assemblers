﻿namespace uProcessorSimulator.ViewComponents
{
    partial class cpuSchema
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cpuSchema));
            this.ALU = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldFlag = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldIVR = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldT = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldSP = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldPC = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issT_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issFlag_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issIVR_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issSP_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issPC_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issFlag_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issIVR_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issT_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issSP_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issPC_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issREG_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issADR_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issMDR_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issREG_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issMDR_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issADR_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldREG = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldADR = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldMDR = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ldIR = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issIR_d = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.issIR_s = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.RBUS_right = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.RBUS_horiz = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.SBUS = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.DBUS = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Alu_op = new System.Windows.Forms.Label();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape10 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape11 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape12 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label4 = new System.Windows.Forms.Label();
            this.memOp = new System.Windows.Forms.Label();
            this.lineShape13 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape14 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape15 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape16 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.RbusView = new uProcessorSimulator.ViewComponents.RegComp();
            this.SbusView = new uProcessorSimulator.ViewComponents.RegComp();
            this.DbusView = new uProcessorSimulator.ViewComponents.RegComp();
            this.IVR = new uProcessorSimulator.ViewComponents.RegComp();
            this.Flag = new uProcessorSimulator.ViewComponents.RegComp();
            this.T = new uProcessorSimulator.ViewComponents.RegComp();
            this.SP = new uProcessorSimulator.ViewComponents.RegComp();
            this.PC = new uProcessorSimulator.ViewComponents.RegComp();
            this.IR = new uProcessorSimulator.ViewComponents.RegComp();
            this.ADR = new uProcessorSimulator.ViewComponents.RegComp();
            this.MDR = new uProcessorSimulator.ViewComponents.RegComp();
            this.R15 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R14 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R13 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R12 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R11 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R10 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R9 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R8 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R7 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R6 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R5 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R4 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R3 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R2 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R1 = new uProcessorSimulator.ViewComponents.RegComp();
            this.R0 = new uProcessorSimulator.ViewComponents.RegComp();
            ((System.ComponentModel.ISupportInitialize)(this.ALU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ALU
            // 
            this.ALU.BackColor = System.Drawing.Color.White;
            this.ALU.Image = global::uProcessorSimulator.Properties.Resources.Alu;
            this.ALU.Location = new System.Drawing.Point(91, 313);
            this.ALU.Name = "ALU";
            this.ALU.Size = new System.Drawing.Size(117, 113);
            this.ALU.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ALU.TabIndex = 24;
            this.ALU.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape16,
            this.lineShape15,
            this.lineShape14,
            this.lineShape13,
            this.lineShape12,
            this.lineShape11,
            this.lineShape10,
            this.lineShape9,
            this.lineShape8,
            this.rectangleShape2,
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.ldFlag,
            this.ldIVR,
            this.ldT,
            this.ldSP,
            this.ldPC,
            this.issT_d,
            this.issFlag_d,
            this.issIVR_d,
            this.issSP_d,
            this.issPC_d,
            this.issFlag_s,
            this.issIVR_s,
            this.issT_s,
            this.issSP_s,
            this.issPC_s,
            this.issREG_s,
            this.issADR_s,
            this.issMDR_s,
            this.issREG_d,
            this.issMDR_d,
            this.issADR_d,
            this.ldREG,
            this.ldADR,
            this.ldMDR,
            this.ldIR,
            this.issIR_d,
            this.issIR_s,
            this.rectangleShape1,
            this.RBUS_right,
            this.RBUS_horiz,
            this.SBUS,
            this.DBUS});
            this.shapeContainer1.Size = new System.Drawing.Size(737, 501);
            this.shapeContainer1.TabIndex = 25;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.lineShape3.BorderWidth = 2;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 31;
            this.lineShape3.X2 = 90;
            this.lineShape3.Y1 = 373;
            this.lineShape3.Y2 = 373;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.lineShape2.BorderWidth = 2;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.lineShape2.X1 = 209;
            this.lineShape2.X2 = 311;
            this.lineShape2.Y1 = 403;
            this.lineShape2.Y2 = 402;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.lineShape1.BorderWidth = 2;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.lineShape1.X1 = 209;
            this.lineShape1.X2 = 367;
            this.lineShape1.Y1 = 327;
            this.lineShape1.Y2 = 327;
            // 
            // ldFlag
            // 
            this.ldFlag.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldFlag.BorderWidth = 2;
            this.ldFlag.Name = "ldFlag";
            this.ldFlag.X1 = 30;
            this.ldFlag.X2 = 89;
            this.ldFlag.Y1 = 289;
            this.ldFlag.Y2 = 289;
            // 
            // ldIVR
            // 
            this.ldIVR.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldIVR.BorderWidth = 2;
            this.ldIVR.Name = "ldIVR";
            this.ldIVR.X1 = 31;
            this.ldIVR.X2 = 90;
            this.ldIVR.Y1 = 260;
            this.ldIVR.Y2 = 260;
            // 
            // ldT
            // 
            this.ldT.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldT.BorderWidth = 2;
            this.ldT.Name = "ldT";
            this.ldT.X1 = 31;
            this.ldT.X2 = 90;
            this.ldT.Y1 = 231;
            this.ldT.Y2 = 231;
            // 
            // ldSP
            // 
            this.ldSP.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldSP.BorderWidth = 2;
            this.ldSP.Name = "ldSP";
            this.ldSP.X1 = 30;
            this.ldSP.X2 = 89;
            this.ldSP.Y1 = 200;
            this.ldSP.Y2 = 200;
            // 
            // ldPC
            // 
            this.ldPC.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldPC.BorderWidth = 2;
            this.ldPC.Name = "ldPC";
            this.ldPC.X1 = 31;
            this.ldPC.X2 = 90;
            this.ldPC.Y1 = 171;
            this.ldPC.Y2 = 171;
            // 
            // issT_d
            // 
            this.issT_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issT_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issT_d.BorderWidth = 2;
            this.issT_d.Name = "issT_d";
            this.issT_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issT_d.X1 = 255;
            this.issT_d.X2 = 305;
            this.issT_d.Y1 = 235;
            this.issT_d.Y2 = 235;
            // 
            // issFlag_d
            // 
            this.issFlag_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issFlag_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issFlag_d.BorderWidth = 2;
            this.issFlag_d.Name = "issFlag_d";
            this.issFlag_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issFlag_d.X1 = 254;
            this.issFlag_d.X2 = 304;
            this.issFlag_d.Y1 = 285;
            this.issFlag_d.Y2 = 285;
            // 
            // issIVR_d
            // 
            this.issIVR_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issIVR_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issIVR_d.BorderWidth = 2;
            this.issIVR_d.Name = "issIVR_d";
            this.issIVR_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issIVR_d.X1 = 255;
            this.issIVR_d.X2 = 305;
            this.issIVR_d.Y1 = 266;
            this.issIVR_d.Y2 = 266;
            // 
            // issSP_d
            // 
            this.issSP_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issSP_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issSP_d.BorderWidth = 2;
            this.issSP_d.Name = "issSP_d";
            this.issSP_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issSP_d.X1 = 256;
            this.issSP_d.X2 = 306;
            this.issSP_d.Y1 = 206;
            this.issSP_d.Y2 = 206;
            // 
            // issPC_d
            // 
            this.issPC_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issPC_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issPC_d.BorderWidth = 2;
            this.issPC_d.Name = "issPC_d";
            this.issPC_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issPC_d.X1 = 256;
            this.issPC_d.X2 = 306;
            this.issPC_d.Y1 = 176;
            this.issPC_d.Y2 = 176;
            // 
            // issFlag_s
            // 
            this.issFlag_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issFlag_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issFlag_s.BorderWidth = 2;
            this.issFlag_s.Name = "issFlag_s";
            this.issFlag_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issFlag_s.X1 = 257;
            this.issFlag_s.X2 = 362;
            this.issFlag_s.Y1 = 295;
            this.issFlag_s.Y2 = 295;
            // 
            // issIVR_s
            // 
            this.issIVR_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issIVR_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issIVR_s.BorderWidth = 2;
            this.issIVR_s.Name = "issIVR_s";
            this.issIVR_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issIVR_s.X1 = 256;
            this.issIVR_s.X2 = 361;
            this.issIVR_s.Y1 = 256;
            this.issIVR_s.Y2 = 256;
            // 
            // issT_s
            // 
            this.issT_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issT_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issT_s.BorderWidth = 2;
            this.issT_s.Name = "issT_s";
            this.issT_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issT_s.X1 = 257;
            this.issT_s.X2 = 362;
            this.issT_s.Y1 = 226;
            this.issT_s.Y2 = 226;
            // 
            // issSP_s
            // 
            this.issSP_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issSP_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issSP_s.BorderWidth = 2;
            this.issSP_s.Name = "issSP_s";
            this.issSP_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issSP_s.X1 = 255;
            this.issSP_s.X2 = 360;
            this.issSP_s.Y1 = 196;
            this.issSP_s.Y2 = 196;
            // 
            // issPC_s
            // 
            this.issPC_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issPC_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issPC_s.BorderWidth = 2;
            this.issPC_s.Name = "issPC_s";
            this.issPC_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issPC_s.X1 = 256;
            this.issPC_s.X2 = 361;
            this.issPC_s.Y1 = 167;
            this.issPC_s.Y2 = 167;
            // 
            // issREG_s
            // 
            this.issREG_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issREG_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issREG_s.BorderWidth = 2;
            this.issREG_s.Name = "issREG_s";
            this.issREG_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issREG_s.X1 = 376;
            this.issREG_s.X2 = 432;
            this.issREG_s.Y1 = 253;
            this.issREG_s.Y2 = 253;
            // 
            // issADR_s
            // 
            this.issADR_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issADR_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issADR_s.BorderWidth = 2;
            this.issADR_s.Name = "issADR_s";
            this.issADR_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issADR_s.X1 = 377;
            this.issADR_s.X2 = 433;
            this.issADR_s.Y1 = 117;
            this.issADR_s.Y2 = 117;
            // 
            // issMDR_s
            // 
            this.issMDR_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issMDR_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issMDR_s.BorderWidth = 2;
            this.issMDR_s.Name = "issMDR_s";
            this.issMDR_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issMDR_s.X1 = 377;
            this.issMDR_s.X2 = 433;
            this.issMDR_s.Y1 = 87;
            this.issMDR_s.Y2 = 87;
            // 
            // issREG_d
            // 
            this.issREG_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issREG_d.BorderWidth = 2;
            this.issREG_d.Name = "issREG_d";
            this.issREG_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issREG_d.X1 = 321;
            this.issREG_d.X2 = 432;
            this.issREG_d.Y1 = 282;
            this.issREG_d.Y2 = 282;
            // 
            // issMDR_d
            // 
            this.issMDR_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issMDR_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issMDR_d.BorderWidth = 2;
            this.issMDR_d.Name = "issMDR_d";
            this.issMDR_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issMDR_d.X1 = 321;
            this.issMDR_d.X2 = 432;
            this.issMDR_d.Y1 = 96;
            this.issMDR_d.Y2 = 96;
            // 
            // issADR_d
            // 
            this.issADR_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issADR_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issADR_d.BorderWidth = 2;
            this.issADR_d.Name = "issADR_d";
            this.issADR_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issADR_d.X1 = 321;
            this.issADR_d.X2 = 432;
            this.issADR_d.Y1 = 125;
            this.issADR_d.Y2 = 125;
            // 
            // ldREG
            // 
            this.ldREG.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldREG.BorderWidth = 2;
            this.ldREG.Name = "ldREG";
            this.ldREG.X1 = 595;
            this.ldREG.X2 = 678;
            this.ldREG.Y1 = 269;
            this.ldREG.Y2 = 269;
            // 
            // ldADR
            // 
            this.ldADR.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldADR.BorderWidth = 2;
            this.ldADR.Name = "ldADR";
            this.ldADR.X1 = 596;
            this.ldADR.X2 = 679;
            this.ldADR.Y1 = 123;
            this.ldADR.Y2 = 123;
            // 
            // ldMDR
            // 
            this.ldMDR.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldMDR.BorderWidth = 2;
            this.ldMDR.Name = "ldMDR";
            this.ldMDR.X1 = 597;
            this.ldMDR.X2 = 680;
            this.ldMDR.Y1 = 92;
            this.ldMDR.Y2 = 92;
            // 
            // ldIR
            // 
            this.ldIR.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.ldIR.BorderWidth = 2;
            this.ldIR.Name = "ldIR";
            this.ldIR.X1 = 597;
            this.ldIR.X2 = 680;
            this.ldIR.Y1 = 62;
            this.ldIR.Y2 = 62;
            // 
            // issIR_d
            // 
            this.issIR_d.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issIR_d.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issIR_d.BorderWidth = 2;
            this.issIR_d.Name = "issIR_d";
            this.issIR_d.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issIR_d.X1 = 320;
            this.issIR_d.X2 = 431;
            this.issIR_d.Y1 = 69;
            this.issIR_d.Y2 = 69;
            // 
            // issIR_s
            // 
            this.issIR_s.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.issIR_s.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.issIR_s.BorderWidth = 2;
            this.issIR_s.Name = "issIR_s";
            this.issIR_s.SelectionColor = System.Drawing.SystemColors.Desktop;
            this.issIR_s.X1 = 377;
            this.issIR_s.X2 = 433;
            this.issIR_s.Y1 = 59;
            this.issIR_s.Y2 = 59;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.rectangleShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape1.Location = new System.Drawing.Point(15, 61);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(15, 408);
            // 
            // RBUS_right
            // 
            this.RBUS_right.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.RBUS_right.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.RBUS_right.Location = new System.Drawing.Point(679, 54);
            this.RBUS_right.Name = "RBUS_right";
            this.RBUS_right.Size = new System.Drawing.Size(15, 415);
            // 
            // RBUS_horiz
            // 
            this.RBUS_horiz.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.RBUS_horiz.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.RBUS_horiz.Location = new System.Drawing.Point(16, 454);
            this.RBUS_horiz.Name = "RBUS_horiz";
            this.RBUS_horiz.Size = new System.Drawing.Size(678, 15);
            // 
            // SBUS
            // 
            this.SBUS.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.SBUS.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.SBUS.Location = new System.Drawing.Point(362, 55);
            this.SBUS.Name = "SBUS";
            this.SBUS.Size = new System.Drawing.Size(15, 370);
            // 
            // DBUS
            // 
            this.DBUS.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.DBUS.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.DBUS.Location = new System.Drawing.Point(305, 55);
            this.DBUS.Name = "DBUS";
            this.DBUS.Size = new System.Drawing.Size(15, 370);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(302, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "DBUS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(359, 428);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "SBUS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(91, 55);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(323, 477);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "RBUS";
            // 
            // Alu_op
            // 
            this.Alu_op.AutoSize = true;
            this.Alu_op.Location = new System.Drawing.Point(129, 358);
            this.Alu_op.Name = "Alu_op";
            this.Alu_op.Size = new System.Drawing.Size(31, 13);
            this.Alu_op.TabIndex = 33;
            this.Alu_op.Text = "none";
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 279;
            this.lineShape4.X2 = 516;
            this.lineShape4.Y1 = 145;
            this.lineShape4.Y2 = 145;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 516;
            this.lineShape5.X2 = 516;
            this.lineShape5.Y1 = 130;
            this.lineShape5.Y2 = 145;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 278;
            this.lineShape6.X2 = 278;
            this.lineShape6.Y1 = 115;
            this.lineShape6.Y2 = 145;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 254;
            this.lineShape7.X2 = 278;
            this.lineShape7.Y1 = 114;
            this.lineShape7.Y2 = 114;
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.rectangleShape2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape2.Location = new System.Drawing.Point(272, 45);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(21, 30);
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 256;
            this.lineShape8.X2 = 271;
            this.lineShape8.Y1 = 64;
            this.lineShape8.Y2 = 64;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 292;
            this.lineShape9.X2 = 516;
            this.lineShape9.Y1 = 75;
            this.lineShape9.Y2 = 75;
            // 
            // lineShape10
            // 
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 293;
            this.lineShape10.X2 = 517;
            this.lineShape10.Y1 = 45;
            this.lineShape10.Y2 = 45;
            // 
            // lineShape11
            // 
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 516;
            this.lineShape11.X2 = 516;
            this.lineShape11.Y1 = 75;
            this.lineShape11.Y2 = 85;
            // 
            // lineShape12
            // 
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 517;
            this.lineShape12.X2 = 517;
            this.lineShape12.Y1 = 45;
            this.lineShape12.Y2 = 55;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(88, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Mem Op:";
            // 
            // memOp
            // 
            this.memOp.AutoSize = true;
            this.memOp.Location = new System.Drawing.Point(144, 38);
            this.memOp.Name = "memOp";
            this.memOp.Size = new System.Drawing.Size(31, 13);
            this.memOp.TabIndex = 35;
            this.memOp.Text = "none";
            // 
            // lineShape13
            // 
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 278;
            this.lineShape13.X2 = 516;
            this.lineShape13.Y1 = 106;
            this.lineShape13.Y2 = 106;
            // 
            // lineShape14
            // 
            this.lineShape14.Name = "lineShape14";
            this.lineShape14.X1 = 253;
            this.lineShape14.X2 = 278;
            this.lineShape14.Y1 = 90;
            this.lineShape14.Y2 = 90;
            // 
            // lineShape15
            // 
            this.lineShape15.Name = "lineShape15";
            this.lineShape15.X1 = 278;
            this.lineShape15.X2 = 278;
            this.lineShape15.Y1 = 91;
            this.lineShape15.Y2 = 105;
            // 
            // lineShape16
            // 
            this.lineShape16.Name = "lineShape16";
            this.lineShape16.X1 = 516;
            this.lineShape16.X2 = 516;
            this.lineShape16.Y1 = 99;
            this.lineShape16.Y2 = 106;
            // 
            // RbusView
            // 
            this.RbusView.HexView = false;
            this.RbusView.Location = new System.Drawing.Point(421, 7);
            this.RbusView.Margin = new System.Windows.Forms.Padding(0);
            this.RbusView.Name = "RbusView";
            this.RbusView.NameReg = "Rbus";
            this.RbusView.Size = new System.Drawing.Size(165, 15);
            this.RbusView.TabIndex = 32;
            this.RbusView.Value = ((ushort)(0));
            // 
            // SbusView
            // 
            this.SbusView.HexView = false;
            this.SbusView.Location = new System.Drawing.Point(256, 7);
            this.SbusView.Margin = new System.Windows.Forms.Padding(0);
            this.SbusView.Name = "SbusView";
            this.SbusView.NameReg = "Sbus";
            this.SbusView.Size = new System.Drawing.Size(165, 15);
            this.SbusView.TabIndex = 31;
            this.SbusView.Value = ((ushort)(0));
            // 
            // DbusView
            // 
            this.DbusView.HexView = false;
            this.DbusView.Location = new System.Drawing.Point(91, 7);
            this.DbusView.Margin = new System.Windows.Forms.Padding(0);
            this.DbusView.Name = "DbusView";
            this.DbusView.NameReg = "Dbus";
            this.DbusView.Size = new System.Drawing.Size(165, 15);
            this.DbusView.TabIndex = 30;
            this.DbusView.Value = ((ushort)(0));
            // 
            // IVR
            // 
            this.IVR.HexView = false;
            this.IVR.Location = new System.Drawing.Point(91, 253);
            this.IVR.Margin = new System.Windows.Forms.Padding(0);
            this.IVR.Name = "IVR";
            this.IVR.NameReg = "IVR";
            this.IVR.Size = new System.Drawing.Size(165, 15);
            this.IVR.TabIndex = 23;
            this.IVR.Value = ((ushort)(0));
            // 
            // Flag
            // 
            this.Flag.HexView = false;
            this.Flag.Location = new System.Drawing.Point(91, 283);
            this.Flag.Margin = new System.Windows.Forms.Padding(0);
            this.Flag.Name = "Flag";
            this.Flag.NameReg = "Flag";
            this.Flag.Size = new System.Drawing.Size(165, 15);
            this.Flag.TabIndex = 22;
            this.Flag.Value = ((ushort)(0));
            // 
            // T
            // 
            this.T.HexView = false;
            this.T.Location = new System.Drawing.Point(91, 223);
            this.T.Margin = new System.Windows.Forms.Padding(0);
            this.T.Name = "T";
            this.T.NameReg = "T";
            this.T.Size = new System.Drawing.Size(165, 15);
            this.T.TabIndex = 21;
            this.T.Value = ((ushort)(0));
            // 
            // SP
            // 
            this.SP.HexView = false;
            this.SP.Location = new System.Drawing.Point(91, 193);
            this.SP.Margin = new System.Windows.Forms.Padding(0);
            this.SP.Name = "SP";
            this.SP.NameReg = "SP";
            this.SP.Size = new System.Drawing.Size(165, 15);
            this.SP.TabIndex = 20;
            this.SP.Value = ((ushort)(0));
            // 
            // PC
            // 
            this.PC.HexView = false;
            this.PC.Location = new System.Drawing.Point(91, 163);
            this.PC.Margin = new System.Windows.Forms.Padding(0);
            this.PC.Name = "PC";
            this.PC.NameReg = "PC";
            this.PC.Size = new System.Drawing.Size(165, 15);
            this.PC.TabIndex = 19;
            this.PC.Value = ((ushort)(0));
            // 
            // IR
            // 
            this.IR.HexView = false;
            this.IR.Location = new System.Drawing.Point(432, 55);
            this.IR.Margin = new System.Windows.Forms.Padding(0);
            this.IR.Name = "IR";
            this.IR.NameReg = "IR";
            this.IR.Size = new System.Drawing.Size(165, 15);
            this.IR.TabIndex = 18;
            this.IR.Value = ((ushort)(0));
            // 
            // ADR
            // 
            this.ADR.HexView = false;
            this.ADR.Location = new System.Drawing.Point(432, 115);
            this.ADR.Margin = new System.Windows.Forms.Padding(0);
            this.ADR.Name = "ADR";
            this.ADR.NameReg = "ADR";
            this.ADR.Size = new System.Drawing.Size(165, 15);
            this.ADR.TabIndex = 17;
            this.ADR.Value = ((ushort)(0));
            // 
            // MDR
            // 
            this.MDR.HexView = false;
            this.MDR.Location = new System.Drawing.Point(432, 85);
            this.MDR.Margin = new System.Windows.Forms.Padding(0);
            this.MDR.Name = "MDR";
            this.MDR.NameReg = "MDR";
            this.MDR.Size = new System.Drawing.Size(165, 15);
            this.MDR.TabIndex = 16;
            this.MDR.Value = ((ushort)(0));
            // 
            // R15
            // 
            this.R15.HexView = false;
            this.R15.Location = new System.Drawing.Point(432, 388);
            this.R15.Margin = new System.Windows.Forms.Padding(0);
            this.R15.Name = "R15";
            this.R15.NameReg = "R15";
            this.R15.Size = new System.Drawing.Size(165, 15);
            this.R15.TabIndex = 15;
            this.R15.Value = ((ushort)(0));
            // 
            // R14
            // 
            this.R14.HexView = false;
            this.R14.Location = new System.Drawing.Point(432, 373);
            this.R14.Margin = new System.Windows.Forms.Padding(0);
            this.R14.Name = "R14";
            this.R14.NameReg = "R14";
            this.R14.Size = new System.Drawing.Size(165, 15);
            this.R14.TabIndex = 14;
            this.R14.Value = ((ushort)(0));
            // 
            // R13
            // 
            this.R13.HexView = false;
            this.R13.Location = new System.Drawing.Point(432, 358);
            this.R13.Margin = new System.Windows.Forms.Padding(0);
            this.R13.Name = "R13";
            this.R13.NameReg = "R13";
            this.R13.Size = new System.Drawing.Size(165, 15);
            this.R13.TabIndex = 13;
            this.R13.Value = ((ushort)(0));
            // 
            // R12
            // 
            this.R12.HexView = false;
            this.R12.Location = new System.Drawing.Point(432, 343);
            this.R12.Margin = new System.Windows.Forms.Padding(0);
            this.R12.Name = "R12";
            this.R12.NameReg = "R12";
            this.R12.Size = new System.Drawing.Size(165, 15);
            this.R12.TabIndex = 12;
            this.R12.Value = ((ushort)(0));
            // 
            // R11
            // 
            this.R11.HexView = false;
            this.R11.Location = new System.Drawing.Point(432, 328);
            this.R11.Margin = new System.Windows.Forms.Padding(0);
            this.R11.Name = "R11";
            this.R11.NameReg = "R11";
            this.R11.Size = new System.Drawing.Size(165, 15);
            this.R11.TabIndex = 11;
            this.R11.Value = ((ushort)(0));
            // 
            // R10
            // 
            this.R10.HexView = false;
            this.R10.Location = new System.Drawing.Point(432, 313);
            this.R10.Margin = new System.Windows.Forms.Padding(0);
            this.R10.Name = "R10";
            this.R10.NameReg = "R10";
            this.R10.Size = new System.Drawing.Size(165, 15);
            this.R10.TabIndex = 10;
            this.R10.Value = ((ushort)(0));
            // 
            // R9
            // 
            this.R9.HexView = false;
            this.R9.Location = new System.Drawing.Point(432, 298);
            this.R9.Margin = new System.Windows.Forms.Padding(0);
            this.R9.Name = "R9";
            this.R9.NameReg = "R9";
            this.R9.Size = new System.Drawing.Size(165, 15);
            this.R9.TabIndex = 9;
            this.R9.Value = ((ushort)(0));
            // 
            // R8
            // 
            this.R8.HexView = false;
            this.R8.Location = new System.Drawing.Point(432, 283);
            this.R8.Margin = new System.Windows.Forms.Padding(0);
            this.R8.Name = "R8";
            this.R8.NameReg = "R8";
            this.R8.Size = new System.Drawing.Size(165, 15);
            this.R8.TabIndex = 8;
            this.R8.Value = ((ushort)(0));
            // 
            // R7
            // 
            this.R7.HexView = false;
            this.R7.Location = new System.Drawing.Point(432, 268);
            this.R7.Margin = new System.Windows.Forms.Padding(0);
            this.R7.Name = "R7";
            this.R7.NameReg = "R7";
            this.R7.Size = new System.Drawing.Size(165, 15);
            this.R7.TabIndex = 7;
            this.R7.Value = ((ushort)(0));
            // 
            // R6
            // 
            this.R6.HexView = false;
            this.R6.Location = new System.Drawing.Point(432, 253);
            this.R6.Margin = new System.Windows.Forms.Padding(0);
            this.R6.Name = "R6";
            this.R6.NameReg = "R6";
            this.R6.Size = new System.Drawing.Size(165, 15);
            this.R6.TabIndex = 6;
            this.R6.Value = ((ushort)(0));
            // 
            // R5
            // 
            this.R5.HexView = false;
            this.R5.Location = new System.Drawing.Point(432, 238);
            this.R5.Margin = new System.Windows.Forms.Padding(0);
            this.R5.Name = "R5";
            this.R5.NameReg = "R5";
            this.R5.Size = new System.Drawing.Size(165, 15);
            this.R5.TabIndex = 5;
            this.R5.Value = ((ushort)(0));
            // 
            // R4
            // 
            this.R4.HexView = false;
            this.R4.Location = new System.Drawing.Point(432, 223);
            this.R4.Margin = new System.Windows.Forms.Padding(0);
            this.R4.Name = "R4";
            this.R4.NameReg = "R4";
            this.R4.Size = new System.Drawing.Size(165, 15);
            this.R4.TabIndex = 4;
            this.R4.Value = ((ushort)(0));
            // 
            // R3
            // 
            this.R3.HexView = false;
            this.R3.Location = new System.Drawing.Point(432, 208);
            this.R3.Margin = new System.Windows.Forms.Padding(0);
            this.R3.Name = "R3";
            this.R3.NameReg = "R3";
            this.R3.Size = new System.Drawing.Size(165, 15);
            this.R3.TabIndex = 3;
            this.R3.Value = ((ushort)(0));
            // 
            // R2
            // 
            this.R2.HexView = false;
            this.R2.Location = new System.Drawing.Point(432, 193);
            this.R2.Margin = new System.Windows.Forms.Padding(0);
            this.R2.Name = "R2";
            this.R2.NameReg = "R2";
            this.R2.Size = new System.Drawing.Size(165, 15);
            this.R2.TabIndex = 2;
            this.R2.Value = ((ushort)(0));
            // 
            // R1
            // 
            this.R1.HexView = false;
            this.R1.Location = new System.Drawing.Point(432, 178);
            this.R1.Margin = new System.Windows.Forms.Padding(0);
            this.R1.Name = "R1";
            this.R1.NameReg = "R1";
            this.R1.Size = new System.Drawing.Size(165, 15);
            this.R1.TabIndex = 1;
            this.R1.Value = ((ushort)(0));
            // 
            // R0
            // 
            this.R0.HexView = false;
            this.R0.Location = new System.Drawing.Point(432, 163);
            this.R0.Margin = new System.Windows.Forms.Padding(0);
            this.R0.Name = "R0";
            this.R0.NameReg = "R0";
            this.R0.Size = new System.Drawing.Size(165, 15);
            this.R0.TabIndex = 0;
            this.R0.Value = ((ushort)(0));
            // 
            // cpuSchema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.memOp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Alu_op);
            this.Controls.Add(this.RbusView);
            this.Controls.Add(this.SbusView);
            this.Controls.Add(this.DbusView);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ALU);
            this.Controls.Add(this.IVR);
            this.Controls.Add(this.Flag);
            this.Controls.Add(this.T);
            this.Controls.Add(this.SP);
            this.Controls.Add(this.PC);
            this.Controls.Add(this.IR);
            this.Controls.Add(this.ADR);
            this.Controls.Add(this.MDR);
            this.Controls.Add(this.R15);
            this.Controls.Add(this.R14);
            this.Controls.Add(this.R13);
            this.Controls.Add(this.R12);
            this.Controls.Add(this.R11);
            this.Controls.Add(this.R10);
            this.Controls.Add(this.R9);
            this.Controls.Add(this.R8);
            this.Controls.Add(this.R7);
            this.Controls.Add(this.R6);
            this.Controls.Add(this.R5);
            this.Controls.Add(this.R4);
            this.Controls.Add(this.R3);
            this.Controls.Add(this.R2);
            this.Controls.Add(this.R1);
            this.Controls.Add(this.R0);
            this.Controls.Add(this.shapeContainer1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "cpuSchema";
            this.Size = new System.Drawing.Size(737, 501);
            this.Load += new System.EventHandler(this.cpuSchema_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ALU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RegComp R0;
        private RegComp R1;
        private RegComp R2;
        private RegComp R3;
        private RegComp R4;
        private RegComp R5;
        private RegComp R6;
        private RegComp R7;
        private RegComp R8;
        private RegComp R9;
        private RegComp R10;
        private RegComp R11;
        private RegComp R12;
        private RegComp R13;
        private RegComp R14;
        private RegComp R15;
        private RegComp MDR;
        private RegComp ADR;
        private RegComp PC;
        private RegComp SP;
        private RegComp T;
        private RegComp Flag;
        private RegComp IVR;
        private System.Windows.Forms.PictureBox ALU;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape SBUS;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape DBUS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape RBUS_right;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape RBUS_horiz;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private RegComp DbusView;
        private RegComp SbusView;
        private RegComp RbusView;
        private Microsoft.VisualBasic.PowerPacks.LineShape issREG_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issADR_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issMDR_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issREG_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issMDR_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issADR_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldREG;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldADR;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldMDR;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldIR;
        private Microsoft.VisualBasic.PowerPacks.LineShape issIR_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issIR_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldFlag;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldIVR;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldT;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldSP;
        private Microsoft.VisualBasic.PowerPacks.LineShape ldPC;
        private Microsoft.VisualBasic.PowerPacks.LineShape issT_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issFlag_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issIVR_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issSP_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issPC_d;
        private Microsoft.VisualBasic.PowerPacks.LineShape issFlag_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issIVR_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issT_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issSP_s;
        private Microsoft.VisualBasic.PowerPacks.LineShape issPC_s;
        private System.Windows.Forms.Label Alu_op;
        private RegComp IR;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape12;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape11;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label memOp;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape13;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape16;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape15;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape14;
    }
}
