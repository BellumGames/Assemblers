﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;

namespace uProcessorSimulator
{
    public partial class CpuShema : UserControl
    {
        public CpuShema()
        {
            InitializeComponent();
        }
        /// <summary>
        /// to do implementation
        /// </summary>
        #region properties
        public ushort IR
        {
            get {return 0; }
            set {; }
        }
        public ushort PC
        {
            get { return 0; }
            set {; }
        }
        public ushort ADR
        {
            get { return 0; }
            set {; }
        }
        public ushort SP
        {
            get { return 0; }
            set {; }
        }
        public ushort Acumulator
        {
            get { return 0; }
            set {; }
        }
        public ushort Temp
        {
            get { return 0; }
            set {; }
        }
        #endregion
        #region View Control Methods

        #endregion
        public void debug()
        {
            this.R0regComp.Value = 0x55aa;
        }
    }
}
