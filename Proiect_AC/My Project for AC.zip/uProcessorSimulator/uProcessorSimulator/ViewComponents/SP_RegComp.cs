﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.ViewComponents
{
    public partial class SP_RegComp : UserControl
    {
        public SP_RegComp()
        {
            InitializeComponent();
        }


        #region fields
        private ushort _value;
        public bool _hexView;
        #endregion

        #region properties
        /// <summary>
        /// reprezentation of the register value in hex
        /// </summary>
        public bool HexView
        {
            set {
                this._hexView = value;
                this.DisplayValue(this._value);
                }
            get { return this._hexView; }
        }

        public ushort Value
        {
            get { return this._value; }
            set
            {
                this._value = value;
                this.DisplayValue(value);
            }
        }

        /*
        public string RegisterName
        {
            set
            {
                this.RegName.Text = value;
            }
            get
            {
                return this.RegName.Text;
            }
        }*/
        #endregion

        #region methods
        private void DisplayValue(ushort value)
        {
            if (!this._hexView)
            {
                string val = "";
                for (int i = 0; i < 16; i++)
                {
                    val = (0x0001 & value).ToString() + val;
                    value = (ushort)(value >> 1);
                }
                this.RegValue.Text = val;
            }
            else
            {
                this.RegValue.Text = String.Format("{0:x}", value);
            }
        }

        public void inc()
        {
            this.Value += 2;
        }

        public void dec()
        {
            this.Value -= 2;
        }

        #endregion

    }
}
