﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uProcessorSimulator.Tools
{
    using uProcessorSimulator.CpuModel;
    public partial class uInstrEditorComp : UserControl
    {
        string sbus;
        string dbus;
        string rbus;
        string alu;
        string other;
        string mem;
        string ifjmp;
        byte? uadr;

        public uInstrEditorComp()
        {
            InitializeComponent();
            this.Sbus.DataSource = Enum.GetValues(typeof(SbusSrc));
            this.Dbus.DataSource = Enum.GetValues(typeof(DbusSrc));
            this.Alu.DataSource = Enum.GetValues(typeof(AluOP));
            this.Rbus.DataSource = Enum.GetValues(typeof(RbusDst));
            this.Other.DataSource = Enum.GetValues(typeof(Other));
            this.Mem.DataSource = Enum.GetValues(typeof(Mem));
            this.Ifjmp.DataSource = Enum.GetValues(typeof(IF_JMP));
            this.uAdr.DataSource = Enum.GetValues(typeof(uADR));
            this.uAdr.SelectedIndexChanged += new System.EventHandler(this.uAdr_SelectedIndexChanged);
            this.IndexLabel.Text = "0";
            this.sbus = this.Sbus.Text;
            this.dbus = this.Dbus.Text;
            this.alu = this.Alu.Text;
            this.rbus = this.Rbus.Text;
            this.other = this.Other.Text;
            this.mem = this.Mem.Text;
            this.ifjmp = this.Ifjmp.Text;
            this.uadr = 0;
        }
        public uInstrEditorComp(int index)
        {
            InitializeComponent();
            this.Sbus.DataSource = Enum.GetValues(typeof(SbusSrc));
            this.Dbus.DataSource = Enum.GetValues(typeof(DbusSrc));
            this.Alu.DataSource = Enum.GetValues(typeof(AluOP));
            this.Rbus.DataSource = Enum.GetValues(typeof(RbusDst));
            this.Other.DataSource = Enum.GetValues(typeof(Other));
            this.Mem.DataSource = Enum.GetValues(typeof(Mem));
            this.Ifjmp.DataSource = Enum.GetValues(typeof(IF_JMP));
            this.uAdr.DataSource = Enum.GetValues(typeof(uADR));
            this.uAdr.SelectedIndexChanged += new System.EventHandler(this.uAdr_SelectedIndexChanged);
            this.IndexLabel.Text = index.ToString("X");
            this.sbus = this.Sbus.Text;
            this.dbus = this.Dbus.Text;
            this.alu = this.Alu.Text;
            this.rbus = this.Rbus.Text;
            this.other = this.Other.Text;
            this.mem = this.Mem.Text;
            this.ifjmp = this.Ifjmp.Text;
            this.uadr = 0;
        }

        public void init(string line)
        {
            string[] fields = line.Split(new string[] { ", ",":\t",},StringSplitOptions.RemoveEmptyEntries);
            int k = 0;
            if(fields.Length > 8)
            {
                this.Label.Text = fields[k++];
            }
            try { this.Sbus.SelectedItem = (SbusSrc)Enum.Parse(typeof(SbusSrc),fields[k++]);  } catch (Exception) {; }
            try { this.Dbus.SelectedItem = (DbusSrc)Enum.Parse(typeof(DbusSrc), fields[k++]); } catch (Exception) {; }
            try { this.Alu.SelectedItem = (AluOP)Enum.Parse(typeof(AluOP), fields[k++]); } catch (Exception) {; }
            try { this.Rbus.SelectedItem = (RbusDst)Enum.Parse(typeof(RbusDst), fields[k++]); } catch (Exception) {; }
            try { this.Other.SelectedItem = (Other)Enum.Parse(typeof(Other), fields[k++]); } catch (Exception) {; }
            try { this.Mem.SelectedItem = (Mem)Enum.Parse(typeof(Mem), fields[k++]); } catch (Exception) {; }
            try { this.Ifjmp.SelectedItem = (IF_JMP)Enum.Parse(typeof(IF_JMP), fields[k++]); } catch (Exception) {; }
            try { this.uAdr.SelectedItem = (uADR)Enum.Parse(typeof(uADR), fields[k]);  }
            catch (Exception) {this.uAdr.Text = fields[k]; }
        }

        public string GetuInstr()
        {
            string ret = "";
            if (this.Label.Text.Any())
            {
                ret = ret + this.Label.Text + ":\t";
            }
            else
            {
                ret = ret + "\t\t";
            }

            if (sbus.Any()) { ret = ret + sbus + ", "; }
            else { throw new Exception("null field"); }

            if (dbus.Any()) { ret = ret + dbus + ", "; }
            else { throw new Exception("null field"); }

            if (alu.Any()) { ret = ret + alu + ", "; }
            else { throw new Exception("null field"); }

            if (rbus.Any()) { ret = ret + rbus + ", "; }
            else { throw new Exception("null field"); }

            if (other.Any()) { ret = ret + other + ", "; }
            else { throw new Exception("null field"); }

            if (mem.Any()) { ret = ret + mem + ", "; }
            else { throw new Exception("null field"); }

            if (ifjmp.Any()) { ret = ret + ifjmp + ", "; }
            else { throw new Exception("null field"); }

            if (this.uAdr.SelectedIndex > -1)
            {
                ret = ret + this.uAdr.SelectedItem.ToString();
            }
            else if (uadr==0)
            {
                ret = ret + uadr;
            }
            else
            { 
                
                //throw new Exception("null field"); 
            }

            return ret;
        }

        #region handlers
        private void Sbus_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Sbus.Text = this.Sbus.SelectedItem.ToString();
            this.sbus = this.Sbus.Text;
            
        }

        private void Dbus_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Dbus.Text = this.Dbus.SelectedItem.ToString();
            this.dbus = this.Dbus.Text;
        }

        private void Alu_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Alu.Text = this.Alu.SelectedItem.ToString();
            this.alu = this.Alu.Text;
        }

        private void Rbus_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Rbus.Text = this.Rbus.SelectedItem.ToString();
            this.rbus = this.Rbus.Text;
        }

        private void Other_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Other.Text = this.Other.SelectedItem.ToString();
            this.other = this.Other.Text;
        }

        private void Mem_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Mem.Text = this.Mem.SelectedItem.ToString();
            this.mem = this.Mem.Text;
        }

        private void Ifjmp_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Ifjmp.Text = this.Ifjmp.SelectedItem.ToString();
            this.ifjmp = this.Ifjmp.Text;
        }

        private void uAdr_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(this.uAdr.SelectedIndex > -1)
            {
                this.uadr = (byte)((uADR)this.uAdr.SelectedItem);
                return;
            }
            try
            {
                //this.uadr = Convert.ToByte(this.uAdr.SelectedItem.ToString());
                this.uadr = Convert.ToByte(this.uAdr.Text, 16);
            }
            catch (FormatException)
            {
                MessageBox.Show("unknown format");
            }
        }

        #endregion
    }
}
