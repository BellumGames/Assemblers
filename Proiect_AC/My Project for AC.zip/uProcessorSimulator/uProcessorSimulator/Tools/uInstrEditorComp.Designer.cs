﻿namespace uProcessorSimulator.Tools
{
    partial class uInstrEditorComp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label = new System.Windows.Forms.TextBox();
            this.Sbus = new System.Windows.Forms.ComboBox();
            this.Dbus = new System.Windows.Forms.ComboBox();
            this.Alu = new System.Windows.Forms.ComboBox();
            this.Rbus = new System.Windows.Forms.ComboBox();
            this.Other = new System.Windows.Forms.ComboBox();
            this.Mem = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Ifjmp = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.uAdr = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.IndexLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Label
            // 
            this.Label.Location = new System.Drawing.Point(50, 26);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(100, 20);
            this.Label.TabIndex = 0;
            // 
            // Sbus
            // 
            this.Sbus.FormattingEnabled = true;
            this.Sbus.Location = new System.Drawing.Point(157, 26);
            this.Sbus.Name = "Sbus";
            this.Sbus.Size = new System.Drawing.Size(79, 21);
            this.Sbus.TabIndex = 1;
            this.Sbus.SelectedIndexChanged += new System.EventHandler(this.Sbus_SelectedIndexChanged);
            // 
            // Dbus
            // 
            this.Dbus.FormattingEnabled = true;
            this.Dbus.Location = new System.Drawing.Point(242, 26);
            this.Dbus.Name = "Dbus";
            this.Dbus.Size = new System.Drawing.Size(79, 21);
            this.Dbus.TabIndex = 2;
            this.Dbus.SelectedIndexChanged += new System.EventHandler(this.Dbus_SelectedIndexChanged);
            // 
            // Alu
            // 
            this.Alu.FormattingEnabled = true;
            this.Alu.Location = new System.Drawing.Point(327, 26);
            this.Alu.Name = "Alu";
            this.Alu.Size = new System.Drawing.Size(79, 21);
            this.Alu.TabIndex = 3;
            this.Alu.SelectedIndexChanged += new System.EventHandler(this.Alu_SelectedIndexChanged);
            // 
            // Rbus
            // 
            this.Rbus.FormattingEnabled = true;
            this.Rbus.Location = new System.Drawing.Point(412, 26);
            this.Rbus.Name = "Rbus";
            this.Rbus.Size = new System.Drawing.Size(79, 21);
            this.Rbus.TabIndex = 4;
            this.Rbus.SelectedIndexChanged += new System.EventHandler(this.Rbus_SelectedIndexChanged);
            // 
            // Other
            // 
            this.Other.FormattingEnabled = true;
            this.Other.Location = new System.Drawing.Point(497, 26);
            this.Other.Name = "Other";
            this.Other.Size = new System.Drawing.Size(79, 21);
            this.Other.TabIndex = 5;
            this.Other.SelectedIndexChanged += new System.EventHandler(this.Other_SelectedIndexChanged);
            // 
            // Mem
            // 
            this.Mem.FormattingEnabled = true;
            this.Mem.Location = new System.Drawing.Point(582, 26);
            this.Mem.Name = "Mem";
            this.Mem.Size = new System.Drawing.Size(79, 21);
            this.Mem.TabIndex = 6;
            this.Mem.SelectedIndexChanged += new System.EventHandler(this.Mem_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Label";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(154, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "SBUS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(239, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "DBUS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(324, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "ALU";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(409, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "RBUS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(497, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "OTHER";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(582, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "MEM";
            // 
            // Ifjmp
            // 
            this.Ifjmp.FormattingEnabled = true;
            this.Ifjmp.Location = new System.Drawing.Point(668, 26);
            this.Ifjmp.Name = "Ifjmp";
            this.Ifjmp.Size = new System.Drawing.Size(152, 21);
            this.Ifjmp.TabIndex = 14;
            this.Ifjmp.SelectedIndexChanged += new System.EventHandler(this.Ifjmp_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(664, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "IF_JMP";
            // 
            // uAdr
            // 
            this.uAdr.FormattingEnabled = true;
            this.uAdr.Location = new System.Drawing.Point(826, 26);
            this.uAdr.Name = "uAdr";
            this.uAdr.Size = new System.Drawing.Size(94, 21);
            this.uAdr.TabIndex = 16;
            //this.uAdr.SelectedIndexChanged += new System.EventHandler(this.uAdr_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(825, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "uADR";
            // 
            // IndexLabel
            // 
            this.IndexLabel.AutoSize = true;
            this.IndexLabel.Location = new System.Drawing.Point(3, 29);
            this.IndexLabel.Name = "IndexLabel";
            this.IndexLabel.Size = new System.Drawing.Size(41, 13);
            this.IndexLabel.TabIndex = 18;
            this.IndexLabel.Text = "label10";
            // 
            // uInstrEditorComp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.IndexLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.uAdr);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Ifjmp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Mem);
            this.Controls.Add(this.Other);
            this.Controls.Add(this.Rbus);
            this.Controls.Add(this.Alu);
            this.Controls.Add(this.Dbus);
            this.Controls.Add(this.Sbus);
            this.Controls.Add(this.Label);
            this.Name = "uInstrEditorComp";
            this.Size = new System.Drawing.Size(933, 51);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Label;
        private System.Windows.Forms.ComboBox Sbus;
        private System.Windows.Forms.ComboBox Dbus;
        private System.Windows.Forms.ComboBox Alu;
        private System.Windows.Forms.ComboBox Rbus;
        private System.Windows.Forms.ComboBox Other;
        private System.Windows.Forms.ComboBox Mem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Ifjmp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox uAdr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label IndexLabel;
    }
}
